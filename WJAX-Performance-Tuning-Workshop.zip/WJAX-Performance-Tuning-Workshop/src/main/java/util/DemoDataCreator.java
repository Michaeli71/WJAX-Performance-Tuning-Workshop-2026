package util;

import java.util.*;

public class DemoDataCreator {

    private static final Random RANDOM = new Random();

    // --------------------------------------------------
    // INTEGER ARRAYS
    // --------------------------------------------------

    public static int[] generateAscSortedSizedIntArray(int size) {
        if (size < 0) {
            throw new IllegalArgumentException(
                    "Grösse darf nicht negativ sein"
            );
        }

        int[] array = new int[size];

        for (int i = 0; i < size; i++) {
            array[i] = i;
        }

        return array;
    }

    public static int[] generateDescSortedSizedIntArray(int size) {
        if (size < 0) {
            throw new IllegalArgumentException(
                    "Grösse darf nicht negativ sein"
            );
        }

        int[] array = new int[size];

        for (int i = 0; i < size; i++) {
            array[i] = size - 1 - i;
        }

        return array;
    }

    public static int[] generateRandomlyPopulatedIntArray(int size) {
        int[] array = generateAscSortedSizedIntArray(size);

        shuffle(array);

        return array;
    }

    // --------------------------------------------------
    // INTEGER LISTS
    // --------------------------------------------------

    public static List<Integer> generateAscSortedSizedIntList(int size) {
        if (size < 0) {
            throw new IllegalArgumentException(
                    "Grösse darf nicht negativ sein"
            );
        }

        List<Integer> list = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            list.add(i);
        }

        return list;
    }

    public static List<Integer> generateDescSortedSizedIntList(int size) {
        if (size < 0) {
            throw new IllegalArgumentException(
                    "Grösse darf nicht negativ sein"
            );
        }

        List<Integer> list = new ArrayList<>();

        for (int i = size - 1; i >= 0; i--) {
            list.add(i);
        }

        return list;
    }

    public static List<Integer> generateRandomlyPopulatedIntList(int size) {
        List<Integer> list = generateAscSortedSizedIntList(size);

        shuffle(list);

        return list;
    }

    // --------------------------------------------------
    // FISHER-YATES SHUFFLE
    // --------------------------------------------------

    public static void shuffle(int[] array) {
        Objects.requireNonNull(array);

        for (int i = array.length - 1; i > 0; i--) {
            int j = RANDOM.nextInt(i + 1);

            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }

    public static <T> void shuffle(List<T> list) {
        Collections.shuffle(list);
    }

    public static <T> void shuffle(List<T> list, Random random) {
        Collections.shuffle(list, random);
    }

    // --------------------------------------------------
    // STRINGS
    // --------------------------------------------------

    private static final String DEFAULT_CHARACTERS =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789";

    public static String generateRandomString(int length) {
        return generateRandomString(length, DEFAULT_CHARACTERS);
    }

    public static String generateRandomString(int length, String characters) {
        if (length < 0) {
            throw new IllegalArgumentException("Grösse darf nicht negativ sein");
        }
        Objects.requireNonNull(characters);

        if (length > 0 && characters.isEmpty()) {
            throw new IllegalArgumentException("Character set darf nicht leer sein");
        }

        StringBuilder result = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int index = RANDOM.nextInt(characters.length());
            result.append(characters.charAt(index));
        }

        return result.toString();
    }

    // --------------------------------------------------
    // STRING LISTS
    // --------------------------------------------------

    public static List<String> generateRandomStrings(int count, int stringLength) {
        if (count < 0) {
            throw new IllegalArgumentException("Grösse darf nicht negativ sein");
        }
        if (stringLength < 0) {
            throw new IllegalArgumentException("Grösse darf nicht negativ sein");
        }

        List<String> strings = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            strings.add(generateRandomString(stringLength));
        }

        return strings;
    }


    static void main() {

        System.out.println("=== INTEGER ARRAYS ===");

        System.out.println(Arrays.toString(
                DemoDataCreator.generateAscSortedSizedIntArray(10)));

        System.out.println(Arrays.toString(
                DemoDataCreator.generateDescSortedSizedIntArray(10)));

        System.out.println(Arrays.toString(
                DemoDataCreator.generateRandomlyPopulatedIntArray(10)));

        System.out.println("\n=== INTEGER LISTS ===");

        System.out.println(
                DemoDataCreator.generateAscSortedSizedIntList(10));

        System.out.println(
                DemoDataCreator.generateDescSortedSizedIntList(10));

        System.out.println(
                DemoDataCreator.generateRandomlyPopulatedIntList(10));

        System.out.println("\n=== STRINGS ===");

        System.out.println(
                DemoDataCreator.generateRandomString(30));

        System.out.println(
                DemoDataCreator.generateRandomString(20, "ABC123"));

        System.out.println("\n=== STRING LISTS ===");

        System.out.println(
                DemoDataCreator.generateRandomStrings(5, 10));
    }
}