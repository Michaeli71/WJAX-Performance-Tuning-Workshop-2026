package util;

import java.util.Random;

public class DemoDataCreatorV1 {

    public static int[] generateAscSortedSizedIntArray(int size) {
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = i;
        }
        return array;
    }

    public static int[] generateDescSortedSizedIntArray(int size) {
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = size - 1 - i;
        }
        return array;
    }

    public static int[] generateRandomlyPopulatedIntArray(int size) {
        int[] array = generateAscSortedSizedIntArray(size);

        shuffle(array);

        return array;
    }

    /// Basiert auf Fisher Yates
    public static void shuffle(int[] array) {
        Random random = new Random();

        for (int i = array.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);

            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }
}
