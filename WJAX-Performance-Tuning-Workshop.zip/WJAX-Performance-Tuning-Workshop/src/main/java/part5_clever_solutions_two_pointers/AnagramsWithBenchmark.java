
package part5_clever_solutions_two_pointers;

import java.util.*;
import java.util.function.BiPredicate;

/// - Brute Force: O(n²) – wird bei großen Eingaben schnell unpraktikabel.
/// - HashMap: O(n) – zusätzlicher Speicherbedarf, relativ hoher Objekt- und Boxing-Overhead.
/// - Sorting: O(n log n) – benötigt keinen zusätzlichen HashMap-Speicher und kann durch primitive Arrays sehr effizient sein.
///
/// Interessant ist gerade, dass O(n) nicht automatisch bedeutet, dass eine Implementierung in der Praxis immer schneller ist als O(n log n).
public class AnagramsWithBenchmark {

    static boolean isAnagramBruteForce(String word1, String word2) {

        if (word1.length() != word2.length())
            return false;

        word1 = word1.toLowerCase(Locale.ROOT);
        word2 = word2.toLowerCase(Locale.ROOT);

        char[] chars = word2.toCharArray();
        boolean[] used = new boolean[chars.length];

        for (int i = 0; i < word1.length(); i++) {
            boolean found = false;

            for (int j = 0; j < chars.length; j++) {
                if (!used[j] && word1.charAt(i) == chars[j]) {
                    used[j] = true;
                    found = true;
                    break;
                }
            }

            if (!found)
                return false;
        }

        return true;
    }

    // O(n)
    static boolean isAnagram(String word1, String word2) {

        if (word1.length() != word2.length())
            return false;

        var frequencies1 = new HashMap<Character, Integer>();
        var frequencies2 = new HashMap<Character, Integer>();

        for (char c : word1.toLowerCase(Locale.ROOT).toCharArray())
            frequencies1.merge(c, 1, Integer::sum);

        for (char c : word2.toLowerCase(Locale.ROOT).toCharArray())
            frequencies2.merge(c, 1, Integer::sum);

        return frequencies1.equals(frequencies2);
    }

    // O(n log n)
    static boolean isAnagramUsingSorting(String word1, String word2) {

        if (word1.length() != word2.length())
            return false;

        char[] chars1 = word1.toLowerCase(Locale.ROOT).toCharArray();
        char[] chars2 = word2.toLowerCase(Locale.ROOT).toCharArray();

        Arrays.sort(chars1);
        Arrays.sort(chars2);

        return Arrays.equals(chars1, chars2);
    }

    // --------------------------------------------------
    // BENCHMARK
    // --------------------------------------------------

    record Algorithm(
            String name,
            BiPredicate<String, String> function
    ) {}

    static volatile long blackhole;

    static final List<Algorithm> ALGORITHMS = List.of(
            new Algorithm("Brute Force", AnagramsWithBenchmark::isAnagramBruteForce),
            new Algorithm("HashMap", AnagramsWithBenchmark::isAnagram),
            new Algorithm("Sorting", AnagramsWithBenchmark::isAnagramUsingSorting)
    );

    static final int WARMUP_ROUNDS = 3;
    static final int MEASUREMENT_ROUNDS = 7;

    static int iterationsFor(int size) {
        if (size <= 100) return 1000;
        if (size <= 500) return 100;
        if (size <= 1000) return 20;
        if (size <= 2000) return 5;
        if (size <= 100_000) return 3;
        return 1;
    }

    static void benchmark(int size) {

        // Identische Zeichenhäufigkeiten, unterschiedliche Reihenfolge
        int a = size / 3;
        int b = size / 3;
        int c = size - a - b;

        String word1 = "a".repeat(a) + "b".repeat(b) + "c".repeat(c);
        String word2 = "c".repeat(c) + "b".repeat(b) + "a".repeat(a);

        // Brute Force nur bei kleineren Eingaben
        List<Algorithm> algorithms = ALGORITHMS;

        int iterations = iterationsFor(size);

        // Korrektheit überprüfen
        for (var algorithm : algorithms) {
            if (!algorithm.function.test(word1, word2))
                throw new AssertionError(algorithm.name + " liefert falsches Ergebnis!");
        }

        // Warmup
        for (int round = 0; round < WARMUP_ROUNDS; round++) {
            for (var algorithm : algorithms) {
                blackhole ^= algorithm.function.test(word1, word2) ? 1 : 0;
            }
        }

        // Messungen
        double[][] results = new double[algorithms.size()][MEASUREMENT_ROUNDS];

        Random random = new Random(42);

        for (int round = 0; round < MEASUREMENT_ROUNDS; round++) {

            List<Algorithm> order = new ArrayList<>(algorithms);
            Collections.shuffle(order, random);

            for (var algorithm : order) {

                int index = algorithms.indexOf(algorithm);
                long checksum = 0;

                long start = System.nanoTime();

                for (int i = 0; i < iterations; i++) {
                    if (algorithm.function.test(word1, word2))
                        checksum++;
                }

                long elapsed = System.nanoTime() - start;

                blackhole = checksum;

                results[index][round] =
                        elapsed / (double) iterations / 1_000_000.0;
            }
        }

        // Auswertung
        double[] medians = new double[algorithms.size()];
        double[] averages = new double[algorithms.size()];

        for (int i = 0; i < algorithms.size(); i++) {

            double[] values = results[i].clone();
            Arrays.sort(values);

            medians[i] = values[values.length / 2];

            averages[i] = Arrays.stream(results[i])
                    .average()
                    .orElse(0);
        }

        double fastest = Arrays.stream(medians)
                .min()
                .orElseThrow();

        // Ausgabe
        System.out.printf("%n=== %s Zeichen ===%n", String.format("%,d", size));

        System.out.printf(
                "%-18s %13s %13s %13s%n",
                "Algorithmus", "Median (ms)", "Mittel (ms)", "Faktor"
        );

        System.out.println("-".repeat(62));

        for (int i = 0; i < algorithms.size(); i++) {

            System.out.printf(
                    "%-18s %13.4f %13.4f %12.2fx%n",
                    algorithms.get(i).name,
                    medians[i],
                    averages[i],
                    medians[i] / fastest
            );
        }
    }

    static void main() {

        int[] sizes = {
                100,
                500,
                1_000,
                5_000,
                10_000,
                50_000,
                100_000,
                500_000
        };

        for (int size : sizes)
            benchmark(size);
    }
}
