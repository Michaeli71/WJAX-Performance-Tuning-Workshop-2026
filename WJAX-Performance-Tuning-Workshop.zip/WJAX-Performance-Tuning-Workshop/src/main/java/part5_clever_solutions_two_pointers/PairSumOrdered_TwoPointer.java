package part5_clever_solutions_two_pointers;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;


public class PairSumOrdered_TwoPointer {

    record IndexPair(int i, int j) {
        @Override
        public String toString() {
            return "(" + i + ", " + j + ")";
        }
    }

    // O(n^2)
    static IndexPair pairSumOrderedBruteForce(List<Integer> values, int k) {
        for (int i = 0; i < values.size(); i++)
            for (int j = i + 1; j < values.size(); j++)
                if (values.get(i) + values.get(j) == k)
                    return new IndexPair(i, j);

        return new IndexPair(-1, -1);
    }

    // O(n)
    static IndexPair pairSumOrderedOptimized(List<Integer> values, int k) {
        int left = 0;
        int right = values.size() - 1;

        while (left < right) {
            int sum = values.get(left) + values.get(right);

            if (sum < k)
                left = left + 1;
            else if (sum > k)
                right = right - 1;
            else // if sum == k:
                return new IndexPair(left, right);
        }

        return new IndexPair(-1, -1);

    }

    public static void main(String[] args) {

        var values = List.of(-5, -1, 2, 7, 11);
        System.out.println(pairSumOrderedBruteForce(values, 13));
        System.out.println(pairSumOrderedBruteForce(values, 1));
        System.out.println(pairSumOrderedBruteForce(values, 8));

        System.out.println("--------------------------");
        // für den Wert 5 potenziell zwei Kombinationen
        values = List.of(-10, -6, -5, -2, 1, 2, 3, 4, 7, 11, 21, 34, 55);
        System.out.println(pairSumOrderedBruteForce(values, 13));
        System.out.println(pairSumOrderedBruteForce(values, 0));
        System.out.println(pairSumOrderedBruteForce(values, 5));
        System.out.println(pairSumOrderedBruteForce(values, 17));
        System.out.println(pairSumOrderedBruteForce(values, -7));
        System.out.println(pairSumOrderedBruteForce(values, -5));
        System.out.println("---------------------------");
        System.out.println(pairSumOrderedOptimized(values, 13));
        System.out.println(pairSumOrderedOptimized(values, 0));
        System.out.println(pairSumOrderedOptimized(values, 5));
        System.out.println(pairSumOrderedOptimized(values, 17));
        System.out.println(pairSumOrderedOptimized(values, -7));
        System.out.println(pairSumOrderedOptimized(values, -5));


        for (int size : new int[] {10_000, 100_000, 1_000_000, 10_000_000})
        {
            measurePairSumOrderedOptimized(size);
        }
    }

    private static void measurePairSumOrderedOptimized(int endExclusive) {
        System.out.println("pairSumOrderedOptimized for length = " + endExclusive);
        List<Integer> values = IntStream.range(0, endExclusive).boxed().toList();

        long start = System.currentTimeMillis();
        System.out.println(pairSumOrderedOptimized(values, -42));
        long end = System.currentTimeMillis();

        System.out.println("Took " + (end - start) + " ms");
    }
}