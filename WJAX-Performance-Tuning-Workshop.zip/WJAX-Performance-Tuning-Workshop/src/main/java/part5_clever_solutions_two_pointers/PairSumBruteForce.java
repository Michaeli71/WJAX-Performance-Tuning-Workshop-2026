package part5_clever_solutions_two_pointers;

import java.util.List;
import java.util.stream.IntStream;

public class PairSumBruteForce {
    record IndexPair(int left, int right) {
        IndexPair {
            if (left > right) {
                throw new IllegalArgumentException("left must not be greater than right");
            }
        }
    }

    static IndexPair pairSumOrderedBruteForce(List<Integer> values, int k) {
        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                if (values.get(i) + values.get(j) == k) {
                    return new IndexPair(i, j);
                }
            }
        }
        return new IndexPair(-1, -1);
    }

    static void main() {
        List<Integer> values = List.of(1, 2, 4, 6, 7, 8, 9, 10);;

        IO.println(pairSumOrderedBruteForce(values, 13));


        List<Integer> values2 = List.of(1, 3, 4, 6, 8, 11);;
        IO.println(pairSumOrderedBruteForce(values2, 11));
        IO.println(pairSumOrderedBruteForce(values2, 10));


        for (int size : new int[] {10_000, 100_000, 1_000_000, 10_000_000})
        {
            measurePairSumOrdered(size);
        }
    }

    private static void measurePairSumOrdered(int endExclusive) {
        System.out.println("pairSumOrderedBruteForce for length = " + endExclusive);
        List<Integer> values = IntStream.range(0, endExclusive).boxed().toList();

        long start = System.currentTimeMillis();
        System.out.println(pairSumOrderedBruteForce(values, -42));
        long end = System.currentTimeMillis();

        System.out.println("Took " + (end - start) + " ms");   // 25 ms
    }
}
