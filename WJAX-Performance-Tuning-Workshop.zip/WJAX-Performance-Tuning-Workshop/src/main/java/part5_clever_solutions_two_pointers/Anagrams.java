package part5_clever_solutions_two_pointers;

import java.util.HashMap;
import java.util.Map;


public class Anagrams {

    static boolean isAnagramBruteForce(String word1, String word2) {

        if (word1.length() != word2.length())
            return false;

        word1 = word1.toLowerCase();
        word2 = word2.toLowerCase();
        // modifiable
        var word2_with_strike_through = word2.toCharArray();

        for (int i = 0; i < word1.length(); i++) {
            boolean letter_found = false;
            for (int j = 0; j < word2_with_strike_through.length; j++) {
                if (word1.charAt(i) == word2_with_strike_through[j]) {
                    letter_found = true;
                    word2_with_strike_through[j] = '-';
                    break;
                }
            }
            if (!letter_found)
                return false;
        }

        // IO.println(Arrays.toString(word2_with_strike_through));
        return true;
    }


    static boolean isAnagram(String word1, String word2) {

        if (word1.length() != word2.length())
            return false;

        var lower_word1 = word1.toLowerCase();
        var lower_word2 = word2.toLowerCase();

        var char_frequencies1 = calcFrequencies(lower_word1);
        var char_frequencies2 = calcFrequencies(lower_word2);

        return char_frequencies1.equals(char_frequencies2);
    }

    // O(n)
    static Map<Character, Long> calcFrequencies(String word) {
        var charFrequencies = new HashMap<Character, Long>();

        for (var letter : word.toCharArray()) {
            charFrequencies.putIfAbsent(letter, 0L);
            charFrequencies.computeIfPresent(letter, (key, val) -> val + 1L);
        }
        return charFrequencies;
    }


    // hier werden zuerste die Buchstaben der Worte sortiert, dann verglichen
    //  O(n log n) fürs Sortieren +
    //  O(n) für Vergleich
    static boolean isAnagramUsingSorting(String word1, String word2) {
        if (word1.length() != word2.length())
            return false;

        var sorted_list1 = word1.toLowerCase().chars().sorted().boxed().toList();
        var sorted_list2 = word2.toLowerCase().chars().sorted().boxed().toList();

        return sorted_list1.equals(sorted_list2);
    }


    static void main() {
        System.out.println(isAnagramBruteForce("Otto", "otto"));
        System.out.println(isAnagramBruteForce("racecar", "carrace"));
        System.out.println(isAnagramBruteForce("Michael", "Andreas"));
        // https://www.anagrammy.com/anagrams/faq6.html
        System.out.println(isAnagramBruteForce("thermonastically", "hematocrystallin"));

        System.out.println("LONG STRINGS");
        System.out.println("Start 1 for length = 1500");
        System.out.println(isAnagramBruteForce("aa".repeat(500) + "bb".repeat(500) + "ccc".repeat(500),
                                               "ccc".repeat(500) + "bb".repeat(500) + "aa".repeat(500)));

        // Java ist verdammt schnell => 6 Sekunden, Faktor 1000 in der Eingabe im Vergleich zu Python
        System.out.println("Start 2 for length = 12000");
        System.out.println(isAnagramBruteForce("aa".repeat(50000) + "bb".repeat(40000) + "ccc".repeat(30000) + "X",
                                               "ccc".repeat(30000) + "bb".repeat(40000) + "aa".repeat(50000) + "Y"));

        System.out.println("Start 2b for length = 12000");
        System.out.println(isAnagram("aa".repeat(50000) + "bb".repeat(40000) + "ccc".repeat(30000) + "X",
                                     "ccc".repeat(30000) + "bb".repeat(40000) + "aa".repeat(50000) + "Y"));

        System.out.println("Start 2c for length = 12000");
        System.out.println(isAnagramUsingSorting("aa".repeat(50000) + "bb".repeat(40000) + "ccc".repeat(30000) + "X",
                                                 "ccc".repeat(30000) + "bb".repeat(40000) + "aa".repeat(50000) + "Y"));
    }
}
