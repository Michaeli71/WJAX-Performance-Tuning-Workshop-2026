package exercises.part5_clever_solutions_two_pointers;

public class Exercise3_Anagrams {
    static void main() {
        var word1 = "Ampel";
        var word2 = "Palme";
        var word3 = "Lampe";

        IO.println(isAnagramBruteForce(word1, word2));
        IO.println(isAnagramBruteForce(word2, word3));
    }


    static boolean isAnagramBruteForce(String word1, String word2) {
        if (word1.length() != word2.length())
            return false;

        word1 = word1.toLowerCase();
        word2 = word2.toLowerCase();
        char[] availableChars = word2.toCharArray();

        for (int i = 0; i < word1.length(); i++) {
            boolean found = false;
            for (int j = 0; j < availableChars.length; j++) {
                if (word1.charAt(i) == availableChars[j]) {
                    found = true;
                    availableChars[j] = '\0'; // bereits verwendet, durchstreichen
                    break;
                }
            }
            if (!found)
                return false;
        }
        return true;
    }
}
