package exercises.part5_clever_solutions_two_pointers;

public class Exercise1b_TwoSumUnsorted {

    record SearchResult(int pos1, int pos2, boolean found) {}

    static void main() {

        int[] values = new int[] {1, 2,  17, 11, 7, 4, 10};

        SearchResult sum15Found = hasPairWithSumBruteForce(values, 15);
        IO.println("sum 15? " + sum15Found);
    }

    static SearchResult hasPairWithSumBruteForce(int[] values, int k) {
        for (int i = 0; i < values.length; i++) {
            for (int j = i + 1; j < values.length; j++) {
                if (values[i] + values[j] == k) {
                    return new SearchResult(i, j, true);
                }
            }
        }
        return new SearchResult(-1, -1, false);
    }
}
