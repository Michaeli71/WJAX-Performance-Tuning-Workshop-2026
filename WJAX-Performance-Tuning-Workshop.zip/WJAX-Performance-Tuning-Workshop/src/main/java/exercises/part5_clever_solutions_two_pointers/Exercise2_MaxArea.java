package exercises.part5_clever_solutions_two_pointers;

import java.util.Arrays;
import java.util.List;

public class Exercise2_MaxArea {
    static void main() {
        List<Integer> values = Arrays.asList(3, 7, 5, 2, 6, 4, 8, 1, 6, 2);

        PosHeightArea maxArea = largestAreaBruteForce(values);
        IO.print("max area: " + maxArea);
    }

    record PosHeightArea(int left, int right, int height, long area) {}

    static PosHeightArea largestAreaBruteForce(List<Integer> values) {
        PosHeightArea best = new PosHeightArea(0, 0, 0, 0);
        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                int width = j - i;
                int minHeight = Math.min(values.get(i), values.get(j));
                long area = (long) width * minHeight;
                if (area > best.area()) {
                    best = new PosHeightArea(i, j, minHeight, area);
                }
            }
        }
        return best;
    }
}
