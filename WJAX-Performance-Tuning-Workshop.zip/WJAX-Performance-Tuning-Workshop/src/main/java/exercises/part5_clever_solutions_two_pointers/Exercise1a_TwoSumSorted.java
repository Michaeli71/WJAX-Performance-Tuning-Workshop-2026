package exercises.part5_clever_solutions_two_pointers;

public class Exercise1a_TwoSumSorted {
    static void main() {

        int[] values = new int[] {1, 2, 4, 7, 10, 11, 17};

        boolean sum15Found = hasPairWithSumBruteForce(values, 15);
        IO.println("sum 15? " + sum15Found);
    }

    static boolean hasPairWithSumBruteForce(int[] values, int k) {
        for (int i = 0; i < values.length; i++) {
            for (int j = i + 1; j < values.length; j++) {
                if (values[i] + values[j] == k) {
                    return true;
                }
            }
        }
        return false;
    }

}
