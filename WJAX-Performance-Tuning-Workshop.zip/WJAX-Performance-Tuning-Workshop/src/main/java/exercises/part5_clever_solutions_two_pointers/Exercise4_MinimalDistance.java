package exercises.part5_clever_solutions_two_pointers;

import java.util.List;

public class Exercise4_MinimalDistance {

    record MinDifferenceResult(
            long difference, int index1, int index2) {
    }

    static MinDifferenceResult findMinDifferenceBruteForce(
            List<Integer> values) {

        MinDifferenceResult best = new MinDifferenceResult(Long.MAX_VALUE, -1, -1);

        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                long difference = Math.abs((long) values.get(i) - values.get(j));

                if (difference < best.difference()) {
                    best = new MinDifferenceResult(difference, i, j);
                }
            }
        }

        return best;
    }

    static void main() {
        List<Integer> values = List.of(99, 1, 22, 33, 42, 55, 6, 77, 83, 100, 111, 122, 144);

        System.out.println(findMinDifferenceBruteForce(values));
        // MinDifferenceResult[difference=1, index1=0, index2=9]
    }
}
