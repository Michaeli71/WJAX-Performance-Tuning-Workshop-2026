package exercises.part3_datastructures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Exercise2_WordCount {

    record WordCount(String word, int count) {}

    static List<WordCount> countNaive(List<String> words) {
        List<WordCount> result = new ArrayList<>();
        for (String word : words) {
            int index = -1;
            for (int i = 0; i < result.size(); i++) {
                if (result.get(i).word().equalsIgnoreCase(word)) {
                    index = i;
                    break;
                }
            }
            if (index >= 0) {
                WordCount old = result.get(index);
                result.set(index, new WordCount(word.toLowerCase(), old.count() + 1));
            } else {
                result.add(new WordCount(word, 1));
            }
        }
        return result;
    }

    static void main() {
        var text = """
                   Das ist eine kleine Geschichte über zwei Freunde. Es geht um Tim und Tom. 
                   Tim und Tom sind beste Freunde. Tim und Tom haben viele Abenteuer erlebt.  
                   Es war für Tim und Tom spannend. Es war eine tolle Geschichte. Es gibt  
                   viel zu erzählen. Das war die Geschichte von Tim und Tom. 
                   """.split(" |\\.|\\n");

        IO.println("Übersicht der Wörter: " + countNaive(Arrays.asList(text)));
    }
}
