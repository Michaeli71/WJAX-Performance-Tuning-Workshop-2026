package exercises.part3_datastructures.exercise3;

import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

class LinkedListBasedQueue<T> {
    private final Deque<T> values = new LinkedList<>();
 
    public void enqueue(T value) {
        values.addLast(value);
    }
 
    public T dequeue() {
        if (values.isEmpty()) 
            return null;

        return values.removeFirst();
    }
 
    public boolean isEmpty() {
        return values.isEmpty();
    }
}
