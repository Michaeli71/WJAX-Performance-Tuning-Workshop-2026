package exercises.part6_prefix_sums;

import java.util.Objects;

public final class Exercise3_ForestPrefixSums2d {

    // forest[r][c] = 1 für 1 Baum, 2 für 2 Bäume, n für n Bäume, 0 für freie Fläche.
    public static int[][]  calculateForestPrefixSums(int[][] forest) {
        Objects.requireNonNull(forest);
        
        int rows = forest.length;
        int cols = rows == 0 ? 0 : forest[0].length;

        // TODO
        return new int[][] {};
    }

    // Inklusive Grenzen: row1..row2 und col1..col2.
    public static long sumRegion(final int[][] prefix, int row1, int col1, int row2, int col2) {
        int rows = prefix.length;
        int cols = rows == 0 ? 0 : prefix[0].length;

        if (row1 < 0 || col1 < 0 || row2 < row1 || col2 < col1 || row2 >= rows || col2 >= cols) {
            throw new IndexOutOfBoundsException("Ungültiges Rechteck");
        }

        // TODO

        return 0;
    }


    private static final int[][] FOREST = {
            {12, 15,  8,  4,  6, 18, 20, 17,  3,  5,  7,  9, 11, 14, 16},
            {10, 13,  7,  5,  8, 16, 19, 21,  4,  6,  8, 10, 12, 15, 17},
            {11, 14,  9,  6,  7, 17, 22, 20,  5,  7,  9, 11, 13, 16, 18},
            { 8, 12,  6,  3,  5, 15, 18, 23,  2,  4,  6,  8, 10, 13, 15},
            { 9, 11,  8,  4,  6, 19, 21, 24,  3,  5,  7,  9, 11, 14, 16},
            {20, 22, 18, 15, 17,  5,  3,  4, 21, 23, 19, 16, 18, 20, 22},
            {21, 24, 19, 16, 18,  4,  2,  5, 22, 25, 20, 17, 19, 21, 23},
            {19, 23, 17, 14, 16,  3,  1,  4, 20, 24, 18, 15, 17, 19, 21},
            {22, 25, 20, 17, 19,  6,  4,  3, 23, 26, 21, 18, 20, 22, 24},
            {18, 21, 16, 13, 15,  5,  2,  3, 19, 22, 17, 14, 16, 18, 20},
            { 2,  3,  4,  5,  3,  8,  9,  7,  4,  3,  2,  5,  4,  3,  2},
            { 3,  4,  2,  6,  4,  7, 10,  8,  3,  4,  3,  6,  5,  2,  3},
            { 4,  5,  3,  4,  2,  9, 11,  6,  5,  2,  4,  3,  6,  4,  5},
            { 2,  3,  5,  3,  4,  6,  8,  5,  2,  3,  5,  4,  3,  5,  4},
            { 3,  2,  4,  5,  3,  7,  9,  6,  3,  4,  2,  5,  4,  3,  2}
    };

    private static void bonusMaxMinTreeArea() {

        int areaSize = 10;

        // 1. Berechne die 2D-Prefix-Sum-Matrix


        // 2. Initialisiere Minimum und Maximum


        // 3. Iteriere über alle möglichen 10x10-Rechtecke


        // 4. Berechne die jeweilige Rechtecksumme in O(1)


        // 5. Aktualisiere Minimum und Maximum


        // 6. Gib die Ergebnisse inklusive Koordinaten aus

    }
}
