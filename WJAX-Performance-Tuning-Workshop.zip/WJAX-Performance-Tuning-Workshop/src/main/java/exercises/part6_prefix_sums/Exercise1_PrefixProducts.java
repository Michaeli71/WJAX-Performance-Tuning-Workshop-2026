package exercises.part6_prefix_sums;

import java.util.Arrays;

public class Exercise1_PrefixProducts {

    public static int[] prefixProducts(int[] values) {
        int[] result = new int[values.length];
        int current = 1;

        for (int i = 0; i < values.length; i++) {
            // TODO: vorheriges Präfixprodukt fortschreiben
        }

        return result;
    }

    static long[] prefixProducts(long[] values) {
        long[] result = new long[values.length];
        if (values.length == 0)
            return result;

        result[0] = values[0];
        for (int i = 1; i < values.length; i++) {
            // TODO: vorheriges Präfixprodukt fortschreiben
        }
        return result;
    }


    static void main() {
        int[] werte = {2, 3, 4, 5, 6, 10};
        int[] ergebnis = prefixProducts(werte);

        IO.println(Arrays.toString(ergebnis));

        long[] werte2 = {2, 3, 4, 5, 6, 10};
        long[] ergebnis2 = prefixProducts(werte2);

        IO.println(Arrays.toString(ergebnis2));
    }
}