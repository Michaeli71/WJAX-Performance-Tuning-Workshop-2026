package exercises.part6_prefix_sums;


public class Exercise2_TemperatureMonitoring {


    private record TemperaturePeriod(int sum, int startDay, int endDay, int days) {
    }

    private static int[] calculateTemperaturePrefixSums(int[] temperatures) {
        return new int[0];
    }

    private static int sumTemperatureRange(int[] prefix, int start, int end) {
        return 0;
    }

    private static TemperaturePeriod findWarmestWeek(int[] prefix) {
        // TODO
        return new TemperaturePeriod(0, 0, 0, 0);
    }

    private static TemperaturePeriod findColdestWeek(int[] prefix) {
        // TODO
        return new TemperaturePeriod(0, 0, 0, 0);
    }


    private static final int[] TEMPERATURES = {
            12, 15, 18, 14, 11, 9, 8, 13, 17, 20,
            22, 19, 16, 14, 12, 10, 7, 9, 13, 18,
            21, 24, 23, 19, 16, 14, 11, 8, 10, 15
    };

    static void main() {

        int[] prefix = calculateTemperaturePrefixSums(TEMPERATURES);

        TemperaturePeriod warmest = findWarmestWeek(prefix);
        TemperaturePeriod coldest = findColdestWeek(prefix);

        System.out.println("=== WÄRMSTE WOCHE ===");
        System.out.println(warmest);

        System.out.println("=== KÄLTESTE WOCHE ===");
        System.out.println(coldest);
    }
}
