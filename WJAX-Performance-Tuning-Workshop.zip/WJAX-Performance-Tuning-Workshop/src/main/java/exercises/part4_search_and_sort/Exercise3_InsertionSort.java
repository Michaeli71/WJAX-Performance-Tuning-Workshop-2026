package exercises.part4_search_and_sort;

import java.util.ArrayList;
import java.util.List;

public class Exercise3_InsertionSort {
    static int move_to_insertion_pos(List<Integer> values, int i) {
        int insertion_pos = i;

        // Origialwert nach links durchreichen, solange der Wert links davon grösser
        while (insertion_pos > 0 && values.get(insertion_pos - 1) > values.get(insertion_pos)) {
            var tmp = values.get(insertion_pos - 1);
            values.set(insertion_pos - 1, values.get(insertion_pos));
            values.set(insertion_pos, tmp);
            insertion_pos -= 1;
        }
        return insertion_pos;
    }

    static void insertion_sort(List values) {
        // Durchlaufe die anderen Positionen
        for (int i = 1; i < values.size(); i++)
            move_to_insertion_pos(values, i);
    }


    static void main() {
        var values = new ArrayList<>(List.of(11, 2, 7, 15, 6, 3, 4, 5, 1, 8, 10, 9, 12, 14, 13));

        insertion_sort(values);
        System.out.println(values);
    }
}
