package exercises.part2_o_notation;

public class Exercise2_Exponentation {
    static void main() {
        IO.println("2^10: " + exponentiationBruteForce(2, 10));
        IO.println("2^11: " + exponentiationBruteForce(2, 11));
        IO.println("2^12: " + exponentiationBruteForce(2, 12));

        IO.println("4^20: " + exponentiationBruteForce(4, 20));
        IO.println("4^21: " + exponentiationBruteForce(4, 21));
        IO.println("2^42: " + exponentiationBruteForce(2, 42));
        IO.println("2^42: " + exponentiationBruteForce(2, 42));
    }

    static long exponentiationBruteForce(long x, int n) {
        long result = 1;
        for (int i = 0; i < n; i++) {
            result *= x;
        }
        return result;
    }

}
