package exercises.part8_recursion;

import java.util.Arrays;

public class Exercise3_EditDistance {

    static int editDistanceMemo(String a, String b) {
        int[][] memo = new int[a.length() + 1][b.length() + 1];

        // -1 bedeutet: noch nicht berechnet
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }

        return editDistanceRecursive(a, b, a.length(), b.length(), memo);
    }

    private static int editDistanceRecursive(
            String a, String b, int i, int j, int[][] memo) {

        // Basisfälle
        if (i == 0) {
            return j;
        }

        if (j == 0) {
            return i;
        }

        // Bereits berechnet?
        if (memo[i][j] != -1) {
            return memo[i][j];
        }

        // TODO

        return memo[i][j];
    }


    static int editDistance(String a, String b) {

        int[][] dp = new int[a.length() + 1][b.length() + 1];

        // Basisfälle: leere Präfixe
        // TODO

        // Alle übrigen Teilprobleme berechnen
        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {

                // TODO
            }
        }

        return dp[a.length()][b.length()];
    }

    static void main() {
        String a = "HAUS";
        String b = "MAUS";

        System.out.println(editDistanceMemo(a, b)); // 1
        System.out.println(editDistance(a, b));     // 1

        String cheese1 = "LEERDAMMER";
        String cheese2 = "EMMENTALER";
        System.out.println(editDistanceMemo(cheese1, cheese2)); // 7
        System.out.println(editDistance(cheese1, cheese2));     // 7
    }
}
