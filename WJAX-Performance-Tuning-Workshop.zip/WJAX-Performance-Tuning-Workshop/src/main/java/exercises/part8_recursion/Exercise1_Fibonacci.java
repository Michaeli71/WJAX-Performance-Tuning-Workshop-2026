package exercises.part8_recursion;

public class Exercise1_Fibonacci {
    static long fibRecursive(int n) {
        if (n <= 1)
            return n;

        return fibRecursive(n - 1) + fibRecursive(n - 2);
    }

    static long fibMemo(int n, long[] memo) {
        if (n <= 1)
            return n;
        if (memo[n] != -1)
            return memo[n];

        return memo[n] = fibMemo(n - 1, memo)  + fibMemo(n - 2, memo);
    }

    static long fibIterative(int n) {
        if (n <= 1)
            return n;

        long a = 0, b = 1;
        for (int i = 2; i <= n; i++) {
            long next = a + b;
            a = b;
            b = next;
        }
        return b;
    }
}
