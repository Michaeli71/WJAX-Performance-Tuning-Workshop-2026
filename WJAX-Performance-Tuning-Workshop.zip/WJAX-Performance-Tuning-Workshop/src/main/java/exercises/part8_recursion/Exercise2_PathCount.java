package exercises.part8_recursion;

import java.util.Arrays;

public class Exercise2_PathCount {
    static int countPaths(int row, int col, int[][] memo) {
        if (row == 0 || col == 0)
            return 1;
        if (memo[row][col] != -1)
            return memo[row][col];
        // TODO: Wege von oben und links kombinieren
        return 0;
    }

    static void main() {
        int rows = 4;
        int cols = 5;

        int[][] memo = new int[rows][cols];

        // Alle Felder mit -1 initialisieren
        for (int r = 0; r < rows; r++) {
            Arrays.fill(memo[r], -1);
        }

        int result = countPaths(rows - 1, cols - 1, memo);

        IO.println("Anzahl Wege: " + result);
    }
}
