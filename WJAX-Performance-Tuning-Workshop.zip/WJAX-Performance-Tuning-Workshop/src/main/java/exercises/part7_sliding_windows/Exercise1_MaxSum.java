package exercises.part7_sliding_windows;

/// values = {3, 8, 2, 5, 7, 6, 1}, k = 3	18
/// values = {1, 2, 3, 4, 5}, k = 2	9
/// values = {5, 1, 1, 1, 5}, k = 3 7
/// values = {4, 4, 4, 4}, k = 2	8
/// values = {1, 2, 3}, k = 3	6
public class Exercise1_MaxSum {
    static int maxSumNaive(int[] values, int k) {
        int best = Integer.MIN_VALUE;

        for (int start = 0; start <= values.length - k; start++) {
            int currentSum = 0;

            for (int i = start; i < start + k; i++) {
                currentSum += values[i];
            }

            if (currentSum > best) {
                best = currentSum;
            }
        }

        return best;
    }

    static void main() {
        IO.println(maxSumNaive(new int[] {3, 8, 2, 5, 7, 6, 1}, 3));
        IO.println(maxSumNaive(new int[] {1, 2, 3, 4, 5}, 2));
        IO.println(maxSumNaive(new int[] {5, 1, 1, 1, 5}, 3));
        IO.println(maxSumNaive(new int[] {4, 4, 4, 4}, 2));
    }
}
