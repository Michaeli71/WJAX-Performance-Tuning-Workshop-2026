package exercises.part7_sliding_windows;


public class Exercise2_MaxAverage {
    static double findMaxAverageNaive(int[] values, int k) {
        double best = Double.NEGATIVE_INFINITY;

        for (int start = 0; start <= values.length - k; start++) {
            int sum = 0;

            for (int i = start; i < start + k; i++) {
                sum += values[i];
            }

            double average = (double) sum / k;
            if (average > best) {
                best = average;
            }
        }

        return best;
    }

    static void main() {
        IO.println(findMaxAverageNaive(new int[] {3, 8, 2, 5, 7, 6, 1}, 3));
        IO.println(findMaxAverageNaive(new int[] {1, 2, 3, 4, 5}, 2));
        IO.println(findMaxAverageNaive(new int[] {5, 1, 1, 1, 5}, 3));
        IO.println(findMaxAverageNaive(new int[] {4, 4, 4, 4}, 2));
    }
}
