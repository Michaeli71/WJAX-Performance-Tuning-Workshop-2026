package exercises.part7_sliding_windows;

public class Exercise4_GoodProductionPeriod {

    private record ProductionPeriod(int start, int end, int length) {
        @Override
        public String toString() {
            return """
                    Startposition: %d
                    Endposition: %d
                    Länge: %d Werkstücke
                    """.formatted(start, end, length);
        }
    }

    private static ProductionPeriod findLongestProductionPeriodNaive(int[] production, int k) {
        if (k < 0) {
            throw new IllegalArgumentException("k darf nicht negativ sein");
        }

        ProductionPeriod best = new ProductionPeriod(-1, -1, 0);

        for (int start = 0; start < production.length; start++) {

            int errors = 0;

            for (int end = start; end < production.length; end++) {

                if (production[end] == 0) {
                    errors++;
                }

                if (errors > k) {
                    break;
                }

                int currentLength = end - start + 1;

                if (currentLength > best.length) {
                    best = new ProductionPeriod(start, end, currentLength);
                }
            }
        }

        return best;
    }


    static void main() {
        int[] production = {
                1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1
        };

        IO.println(findLongestProductionPeriodNaive(production, 2));
        IO.println(findLongestProductionPeriodNaive(production, 3));
        IO.println(findLongestProductionPeriodNaive(production, 4));
    }
}
