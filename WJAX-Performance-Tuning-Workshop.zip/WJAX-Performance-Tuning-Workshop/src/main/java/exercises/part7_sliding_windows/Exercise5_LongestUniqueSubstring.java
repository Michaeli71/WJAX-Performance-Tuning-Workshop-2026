package exercises.part7_sliding_windows;

import java.util.HashSet;
import java.util.Set;

public class Exercise5_LongestUniqueSubstring {
    static String longestUniqueSubstringNaive(String text) {
        String best = "";
        for (int start = 0; start < text.length(); start++) {
            for (int end = start + 1; end <= text.length(); end++) {
                String candidate = text.substring(start, end);
                if (containsOnlyUniqueChars(candidate) && candidate.length() > best.length()) {
                    best = candidate;
                }
            }
        }
        return best;
    }

    static boolean containsOnlyUniqueChars(String value) {
        Set<Character> seen = new HashSet<>();
        for (int i = 0; i < value.length(); i++) {
            if (!seen.add(value.charAt(i)))
                return false;
        }
        return true;
    }

    static void main() {
        String[] tests = {"abcabcbb",
                          "bbbbb",
                          "pwwkew",
                          "abcdef",
                          "",
                          "abba"
        };

        for (String text : tests) {
            IO.println("Eingabe: '" + text + "'");
            IO.println("Naiv: '" + longestUniqueSubstringNaive(text) + "'");
            // IO.println("Sliding Window: " + longestSubstring(text));
            IO.println();
        }
    }
}
