package exercises.part7_sliding_windows;

public class Exercise3_CosyWeatherPeriod {

    private record TemperatureStreak(
            int startDay,
            int endDay,
            int days
    ) {
        @Override
        public String toString() {
            return """
                    Starttag: %d
                    Endtag: %d
                    Dauer: %d Tage
                    """.formatted(startDay, endDay, days);
        }
    }

    private static TemperatureStreak findLongestComfortablePeriodNaive(int[] temperatures,
                                                                       int maxColdDays
    ) {
        int maxLength = 0;
        int bestStart = 0;
        int bestEnd = -1;

        for (int start = 0; start < temperatures.length; start++) {

            int coldDays = 0;

            for (int end = start; end < temperatures.length; end++) {

                if (temperatures[end] <= 15) {
                    coldDays++;
                }

                if (coldDays > maxColdDays) {
                    break;
                }

                int currentLength = end - start + 1;

                if (currentLength > maxLength) {
                    maxLength = currentLength;
                    bestStart = start;
                    bestEnd = end;
                }
            }
        }

        return new TemperatureStreak(bestStart, bestEnd, maxLength);
    }

    static void main() {
        int[] temperatures = {16, 18, 12, 17, 19, 14, 20, 21, 13, 22, 24, 18};
        TemperatureStreak result = findLongestComfortablePeriodNaive(temperatures, 1);
        System.out.println(result);

        int[] temperatures2 = {10, 12, 22, 11, 29, 24, 20, 26, 21, 22, 24, 7};
        TemperatureStreak result2 = findLongestComfortablePeriodNaive(temperatures2, 1);
        System.out.println(result2);
    }
}
