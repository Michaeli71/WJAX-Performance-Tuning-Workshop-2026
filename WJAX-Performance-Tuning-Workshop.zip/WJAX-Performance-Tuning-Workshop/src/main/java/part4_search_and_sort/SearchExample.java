package part4_search_and_sort;

import java.util.ArrayList;
import java.util.List;

public class SearchExample {
    static void main() {

        List<Long> values = generateInitialDataSet(10_000_000);

        linearSearch(values, 72971);
        binarySearchIter(values, 72971);
        binarySearchIterWithCompareCount(values, 72971);
    }

    private static List<Long> generateInitialDataSet(int size) {
        List<Long> originalValues = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            originalValues.add((long) i);
        }

        originalValues.set((int) (size * 0.75f), 42L);

        return originalValues;
    }

    static int linearSearch(List<Long> values, long target) {
        int compareCount = 0;

        for (int i = 0; i < values.size(); i++) {
            compareCount++;
            if (values.get(i).equals(target)) {
                IO.println("Found " + target + " within " + compareCount + " steps");
                return i;
            }
        }
        return -1;
    }


    static int binarySearchRecV1(List<Long> values, int target) {
        if (values.isEmpty()) return -1;
        int mid = (values.size() - 1) / 2;
        if (values.get(mid) == target)
            return mid;
        else if (values.get(mid) < target)
            return binarySearchRecV1(values.subList(mid + 1, values.size()), target);
        else
            return binarySearchRecV1(values.subList(0, mid), target);
    }

    static int binarySearchRecV2(List<Long> values, int target) {
        return binarySearchRecV2Helper(values, target, 0, values.size() - 1);
    }

    static int binarySearchRecV2Helper(List<Long> values, int target, int left, int right) {
        if (left > right) return -1;
        int mid = (left + right) / 2;
        if (values.get(mid) == target)
            return mid;
        else if (values.get(mid) < target)
            return binarySearchRecV2Helper(values, target, mid + 1, right);
        else // if (values.get(mid) > target)
            return binarySearchRecV2Helper(values, target, left, mid - 1);
    }

    static int binarySearchIter(List<Long> values, int target) {
        int left = 0;
        int right = values.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (values.get(mid) == target)
                return mid;
            else if (values.get(mid) < target)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return -1;
    }

    static int binarySearchIterWithCompareCount(List<Long> values, int target) {
        int compareCount = 0;

        int left = 0;
        int right = values.size() - 1;

        while (left <= right) {
            compareCount++;

            int mid = left + (right - left) / 2;

            if (values.get(mid) == target) {
                IO.println("Found " + target + " within " + compareCount + " steps");
                return mid;
            } else if (values.get(mid) < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1;
    }
}
