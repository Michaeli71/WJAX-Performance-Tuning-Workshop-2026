package part4_search_and_sort;

import java.util.List;
import java.util.stream.LongStream;

public class LinearSearchPerformanceExample {

    static int linearSearch(List<Long> values, long target) {
        for (int i = 0; i < values.size(); i++) {
            if (values.get(i) == target) {
                return i;
            }
        }
        return -1;
    }

    static void main() {

        var values = LongStream.range(0, 71).boxed().toList();

        System.out.println("linear search 1");
        System.out.println(linearSearch(values, 42));
        System.out.println(linearSearch(values, 84));

        values = LongStream.range(0, 100_000_000).boxed().toList();
        System.out.println(linearSearch(values, 42));
        System.out.println(linearSearch(values, 12345678901234567L));

        values = LongStream.range(0, 1_000_000_000).boxed().toList();
        System.out.println(linearSearch(values, 42));
        System.out.println(linearSearch(values, 12345678901234567L));
    }
}