package solutions.part9_tries.exercise1_ranking;

import java.util.Comparator;
import java.util.List;

public class Trie {
    private final TrieNode root = new TrieNode(null);

    public void insert(String word) {
        insert(word, 1);
    }

    public void insert(String word, int rankingOffset) {
        TrieNode current = root;

        for (char c : word.toCharArray()) {
            current.createChildIfAbsent(c);
            current = current.childFor(c);
        }

        current.word = word;
        current.ranking += rankingOffset;
    }

    private boolean containsCharSequence(String prefix) {
        return findNodeForCharSequence(prefix) != null;
    }

    public boolean contains(String word) {
        TrieNode current = findNodeForCharSequence(word);
        if (current == null)
            return false;

        return current.isWord();
    }

    private TrieNode findNodeForCharSequence(String prefix) {
        TrieNode current = root;

        for (char ch : prefix.toCharArray()) {
            current = current.childFor(ch);
            if  (current == null)
                return null;
        }

        return current;
    }


    public void printTrie() {
        root.printNode(0);
    }


    public List<String> complete(String prefix) {
        TrieNode current = findNodeForCharSequence(prefix);
        if (current == null)
            return List.of();

        return current.complete();
    }


    public List<WordAndRanking> completeBasedOnRanking(String prefix) {
        return completeBasedOnRanking(prefix, Integer.MAX_VALUE);
    }

    public List<WordAndRanking> completeBasedOnRanking(String prefix, int maxResults) {
        TrieNode current = findNodeForCharSequence(prefix);
        if (current == null)
            return List.of();

        var rankingTuples = current.completeBasedOnRanking();

        var byRankingDescWordAsc = Comparator.comparing(
                                              WordAndRanking::ranking).reversed().
                                              thenComparing(WordAndRanking::word);

        return rankingTuples.stream().
                             sorted(byRankingDescWordAsc).
                             limit(maxResults).
                             toList();
    }


    static void main() {

        var trie = new Trie();
        trie.insert("beet", 42);
        trie.insert("beere", 35);
        trie.insert("berg", 28);
        trie.insert("bett", 19);
        trie.insert("besen", 13);
        //
        trie.insert("bereits", 27);
        trie.insert("bettgestell", 11);;
        trie.insert("berggipfel", 7);
        trie.insert("bergretter", 5);
        trie.insert("beerig", 5);
        trie.insert("bestie", 3);
        trie.insert("bestialisch", 6);
        trie.printTrie();

        IO.println(trie.complete("be"));
        IO.println(trie.completeBasedOnRanking("be"));
        IO.println(trie.completeBasedOnRanking("be", 3));

        IO.println(trie.complete("bee"));
        IO.println(trie.completeBasedOnRanking("bee"));

    }
}


