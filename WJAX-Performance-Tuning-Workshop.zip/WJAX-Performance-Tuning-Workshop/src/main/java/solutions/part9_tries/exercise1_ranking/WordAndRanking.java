package solutions.part9_tries.exercise1_ranking;

record WordAndRanking(String word, int ranking) {
    @Override
    public String toString() {
        return word + " (" + ranking + ")";
    }
}