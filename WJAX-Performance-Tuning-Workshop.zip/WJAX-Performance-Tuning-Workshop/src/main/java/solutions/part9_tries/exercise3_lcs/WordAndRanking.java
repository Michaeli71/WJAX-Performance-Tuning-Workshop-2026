package solutions.part9_tries.exercise3_lcs;

record WordAndRanking(String word, int ranking){
    @Override
    public String toString() {
        return word + " (" + ranking + ")";
    }
}