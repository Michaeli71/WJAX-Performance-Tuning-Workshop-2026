package solutions.part9_tries.exercise3_lcs;

import java.util.*;

public class Trie {
    private TrieNode root = new TrieNode(null);

    // ...
    public void insert(String word) {
        insert(word, 1);
    }

    public void insert(String word, int rankingOffset) {
        TrieNode current = root;

        for (char ch : word.toCharArray()) {
            current.createChildIfAbsent(ch);
            current = current.childFor(ch);
        }

        current.word = word;
        current.ranking += rankingOffset;
    }

    private boolean containsCharSequence(String prefix) {
        return findNodeForCharSequence(prefix) != null;
    }

    public boolean contains(String word) {
        TrieNode current = findNodeForCharSequence(word);
        if (current == null)
            return false;

        return current.isWord();
    }

    private TrieNode findNodeForCharSequence(String prefix) {
        TrieNode current = root;

        for (char ch : prefix.toCharArray()) {
            current = current.childFor(ch);
            if  (current == null)
                return null;
        }

        return current;
    }

    public void printTrie() {
        root.printNode(0);
    }

    public List<String> complete(String prefix) {
        TrieNode current = findNodeForCharSequence(prefix);
        if (current == null)
            return List.of();

        return current.complete();
    }

    private List<TrieNode> findNodePathForCharSequence(String prefix) {
        TrieNode current = root;

        List<TrieNode> path = new ArrayList<>();
        for (char ch : prefix.toCharArray()) {
            current = current.childFor(ch);
            if  (current == null)
                return Collections.emptyList();

            path.add(current);
        }

        return path;
    }

    public List<WordAndRanking> completeBasedOnRanking(String prefix) {
        return completeBasedOnRanking(prefix, Integer.MAX_VALUE);
    }

    public List<WordAndRanking> completeBasedOnRanking(String prefix, int maxResults) {
        TrieNode current = findNodeForCharSequence(prefix);
        if (current == null)
            return List.of();

        var rankingTuples = current.completeBasedOnRanking();

        var byRankingDescWordAsc = Comparator.comparing(
                        WordAndRanking::ranking).reversed().
                thenComparing(WordAndRanking::word);

        return rankingTuples.stream().
                sorted(byRankingDescWordAsc).
                limit(maxResults).
                toList();
    }

    public boolean simpleDelete(String word) {
        TrieNode current = findNodeForCharSequence(word);
        if (current == null)
            return false;

        current.word = null;
        return true;
    }

    public boolean delete(String word) {
        boolean deleted = simpleDelete(word);

        List<TrieNode> path = findNodePathForCharSequence(word);

        // "move up" mit Trick über die Zeichen von hinten
        int index = path.size() - 1;
        while (index >= 0) {
            var child = path.get(index);

            // Wenn ein Wortknoten gefunden wird, Löschvorgang beenden
            if (child.isWord())
                break;

            // Leere Blattknoten entfernen
            if (child.isLeaf()) {
                var parent = index > 0 ? path.get(index - 1) : root;
                parent.deleteChildFor(child.ch);
            }
            index--;
        }

        return deleted;
    }

    public String longestCommonPrefix() {
        TrieNode current = root;

        String result = "";
        while (current.childCount() == 1 && !current.isWord()) {
            current = current.firstChild();
            result += current.ch;
        }
        return result;
    }

    static void main() {
        Trie trie = createTrieFor("stopping", "stopped", "stopwatch");
        var result = trie.longestCommonPrefix();
        IO.println("prefix: '" + result + "'");

        trie = createTrieFrom(List.of("air", "airflow"));
        result = trie.longestCommonPrefix();
        IO.println("prefix: '" + result + "'");

        trie = createTrieFor("leerdammer", "emmentaler");
        result = trie.longestCommonPrefix();
        IO.println("prefix: '" + result + "'");
    }

    public static Trie createTrieFor(String... words) {
        Trie trie = new Trie();
        for (String word:  words) {
            trie.insert(word);
        }
        return trie;
    }

    public static Trie createTrieFrom(Collection<String> wordsIterable)
    {
        return createTrieFor(wordsIterable.toArray(new String[0]));
    }
}


