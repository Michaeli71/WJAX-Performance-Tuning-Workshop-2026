package solutions.part9_tries.exercise2_delete;

record WordAndRanking(String word, int ranking) {
    @Override
    public String toString() {
        return word + " (" + ranking + ")";
    }
}