package solutions.part2_o_notation;

import java.util.*;

public class Exercise4_DemoDataCreator {

    private static final Random RANDOM = new Random();


    public static int[] generateAscSortedSizedIntArray(int size) {
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = i;
        }
        return array;
    }

    public static int[] generateDescSortedSizedIntArray(int size) {
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = size - 1 - i;
        }
        return array;
    }

    public static int[] generateRandomlyPopulatedIntArray(int size) {
        int[] array = generateAscSortedSizedIntArray(size);

        shuffle(array);

        return array;
    }

    // --------------------------------------------------
    // INTEGER LISTS
    // --------------------------------------------------

    public static List<Integer> generateAscSortedSizedIntList(int size) {

        List<Integer> list = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            list.add(i);
        }

        return list;
    }

    public static List<Integer> generateDescSortedSizedIntList(int size) {

        List<Integer> list = new ArrayList<>();

        for (int i = size - 1; i >= 0; i--) {
            list.add(i);
        }

        return list;
    }

    public static List<Integer> generateRandomlyPopulatedIntList(int size) {
        List<Integer> list = generateAscSortedSizedIntList(size);

        shuffle(list);

        return list;
    }

    // --------------------------------------------------
    // FISHER-YATES SHUFFLE
    // --------------------------------------------------

    public static void shuffle(int[] array) {
        Random random = new Random();

        for (int i = array.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);

            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }

    public static <T> void shuffle(List<T> list) {
        Collections.shuffle(list);
    }

    public static <T> void shuffle(List<T> list, Random random) {
        Collections.shuffle(list, random);
    }

    // --------------------------------------------------
    // STRINGS
    // --------------------------------------------------

    private static final String DEFAULT_CHARACTERS =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789";

    public static String generateRandomString(int length) {
        return generateRandomString(length, DEFAULT_CHARACTERS);
    }

    public static String generateRandomString(int length, String characters) {

        Objects.requireNonNull(characters);

        if (length > 0 && characters.isEmpty()) {
            throw new IllegalArgumentException("Character set darf nicht leer sein");
        }

        StringBuilder result = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int index = RANDOM.nextInt(characters.length());
            result.append(characters.charAt(index));
        }

        return result.toString();
    }

    // --------------------------------------------------
    // STRING LISTS
    // --------------------------------------------------

    public static List<String> generateRandomStrings(int count, int stringLength) {

        List<String> strings = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            strings.add(generateRandomString(stringLength));
        }

        return strings;
    }
}
