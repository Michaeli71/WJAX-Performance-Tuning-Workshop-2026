package solutions.part2_o_notation;

import java.util.HashSet;
import java.util.Set;

public class Exercise3_DuplicateCheckCodeToMeasure {

    static boolean hasDuplicatesNaive(int[] values) {
        for (int i = 0; i < values.length; i++) {
            for (int j = i + 1; j < values.length; j++) {
                if (values[i] == values[j])
                    return true;
            }
        }
        return false;
    }

    static boolean hasDuplicatesHashSet(int[] values) {
        Set<Integer> seen = new HashSet<>();
        for (int value : values) {
            if (!seen.add(value))
                return true;
        }
        return false;
    }

}
