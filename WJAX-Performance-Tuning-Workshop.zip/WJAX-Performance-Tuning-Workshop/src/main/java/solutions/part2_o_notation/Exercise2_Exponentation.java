package solutions.part2_o_notation;

public class Exercise2_Exponentation {
    static void main() {
        performExponentationBruteForce();
        performExponentationTricky();
    }

    private static void performExponentationBruteForce() {
        IO.println("2^10: " + exponentiationBruteForce(2, 10));
        IO.println("2^11: " + exponentiationBruteForce(2, 11));
        IO.println("2^12: " + exponentiationBruteForce(2, 12));

        IO.println("4^20: " + exponentiationBruteForce(4, 20));
        IO.println("4^21: " + exponentiationBruteForce(4, 21));
        IO.println("2^42: " + exponentiationBruteForce(2, 42));
        IO.println("2^42: " + exponentiationBruteForce(2, 43));
    }

    private static void performExponentationTricky() {
        IO.println("2^10: " + exponentiationTricky(2, 10));
        IO.println("2^11: " + exponentiationTricky(2, 11));
        IO.println("2^12: " + exponentiationTricky(2, 12));

        IO.println("4^20: " + exponentiationTricky(4, 20));
        IO.println("4^21: " + exponentiationTricky(4, 21));
        IO.println("2^42: " + exponentiationTricky(2, 42));
        IO.println("2^42: " + exponentiationTricky(2, 43));

        IO.println("4^20: " + exponentiation_v2(4, 20));
        IO.println("4^21: " + exponentiation_v2(4, 21));
        IO.println("2^42: " + exponentiation_v2(2, 42));
        IO.println("2^42: " + exponentiation_v2(2, 43));
    }

    static long exponentiationBruteForce(long x, int n) {
        long result = 1;
        for (int i = 0; i < n; i++) {
            result *= x;
        }
        return result;
    }

    static long exponentiation_v2(long x, int n) {
        if (n == 0)
            return 1L;

        if (n % 2 == 0)
            return exponentiation_v2(x * x, n / 2);
        else
            return exponentiation_v2(x * x, n / 2) * x;
    }

    static long exponentiationTricky(long x, int n) {
        long result = 1;

        while (n > 0) {
            if (n % 2 == 1) {
                result *= x;
            }

            x *= x;
            n /= 2;
        }

        return result;
    }
}
