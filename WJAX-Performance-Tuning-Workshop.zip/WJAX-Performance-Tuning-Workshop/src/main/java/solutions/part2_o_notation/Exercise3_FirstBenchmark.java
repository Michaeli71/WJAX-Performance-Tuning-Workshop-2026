package solutions.part2_o_notation;

import util.DemoDataCreator;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import static solutions.part2_o_notation.Exercise3_DuplicateCheckCodeToMeasure.hasDuplicatesHashSet;
import static solutions.part2_o_notation.Exercise3_DuplicateCheckCodeToMeasure.hasDuplicatesNaive;

public class Exercise3_FirstBenchmark {

    static long measureNanos(Runnable task, int warmups, int repetitions) {
        for (int i = 0; i < warmups; i++)
            task.run(); // einfaches Warm-up

        long start = System.nanoTime();
        for (int i = 0; i < repetitions; i++)
            task.run();

        return (System.nanoTime() - start) / repetitions;
    }

    static long measureNanos(Runnable task) {
        long start = System.nanoTime();
        task.run();
        return System.nanoTime() - start;
    }


    private static volatile boolean result;

    static void main() {

        int[] values = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        performMeausrement(values);

        int[] values2 = DemoDataCreator.generateAscSortedSizedIntArray(10_000);
        IO.println(Arrays.toString(values2));
        performMeausrement(values2);

        int[] values3 = DemoDataCreator.generateDescSortedSizedIntArray(10_000);
        performMeausrement(values3);

        int[] values4 = DemoDataCreator.generateAscSortedSizedIntArray(100_000);
        performMeausrement(values4);

        int[] values5 = DemoDataCreator.generateDescSortedSizedIntArray(100_000);
        performMeausrement(values5);

        int[] values6 = DemoDataCreator.generateAscSortedSizedIntArray(1_000_000);
        performMeausrement(values6);

        int[] values7 = DemoDataCreator.generateDescSortedSizedIntArray(1_000_000);
        performMeausrement(values7);
    }

    private static void performMeausrement(int[] values) {
        int repetitions = 3;
        long naiveTime = measureNanos(() -> result = hasDuplicatesNaive(values), 1, repetitions);
        long setTime = measureNanos(() -> result = hasDuplicatesHashSet(values), 1, repetitions);

        long naiveMicros = TimeUnit.NANOSECONDS.toMicros(naiveTime);
        long setMicros = TimeUnit.NANOSECONDS.toMicros(setTime);
        double speedup = setTime > 0 ? (double) naiveTime / setTime : Double.NaN;

        System.out.printf("n=%d | Naiv: %d µs | HashSet: %d µs | Speedup: %.2fx%n",
                          values.length, naiveMicros, setMicros, speedup
        );
    }
}
