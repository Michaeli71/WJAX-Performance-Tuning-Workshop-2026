package solutions.part7_sliding_windows;

public class Exercise4_GoodProcutionPeriod {

    private record ProductionPeriod(
            int start,
            int end,
            int length
    ) {
        @Override
        public String toString() {
            return """
                    Startposition: %d
                    Endposition: %d
                    Länge: %d Werkstücke
                    """.formatted(start, end, length);
        }
    }

    private static ProductionPeriod findLongestProductionPeriod(
            int[] production,
            int k
    ) {
        if (k < 0) {
            throw new IllegalArgumentException("k darf nicht negativ sein");
        }

        int left = 0;
        int errors = 0;

        ProductionPeriod best = new ProductionPeriod(-1, -1, 0);

        for (int right = 0; right < production.length; right++) {

            if (production[right] == 0) {
                errors++;
            }

            while (errors > k) {
                if (production[left] == 0) {
                    errors--;
                }
                left++;
            }

            int currentLength = right - left + 1;

            if (currentLength > best.length()) {
                best = new ProductionPeriod(left, right, currentLength);
            }
        }

        return best;
    }


    static void main() {
        int[] production = {
                1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1
        };

        IO.println(findLongestProductionPeriod(production, 2));
        IO.println(findLongestProductionPeriod(production, 3));
        IO.println(findLongestProductionPeriod(production, 4));
    }
}
