package solutions.part7_sliding_windows;

import java.util.HashSet;
import java.util.Set;

public class Exercise5_LongestUniqueSubstring {
    static String longestUniqueSubstringNaive(String text) {
        String best = "";
        for (int start = 0; start < text.length(); start++) {
            for (int end = start + 1; end <= text.length(); end++) {
                String candidate = text.substring(start, end);
                if (containsOnlyUniqueChars(candidate) && candidate.length() > best.length()) {
                    best = candidate;
                }
            }
        }
        return best;
    }

    static boolean containsOnlyUniqueChars(String value) {
        Set<Character> seen = new HashSet<>();
        for (int i = 0; i < value.length(); i++) {
            if (!seen.add(value.charAt(i)))
                return false;
        }
        return true;
    }

    static String longestUniqueSubstring(String text) {

        Set<Character> seen = new HashSet<>();

        int left = 0;
        int maxLength = 0;
        int bestStart = 0;

        for (int right = 0; right < text.length(); right++) {

            char current = text.charAt(right);

            while (seen.contains(current)) {
                seen.remove(text.charAt(left));
                left++;
            }

            seen.add(current);

            int currentLength = right - left + 1;

            if (currentLength > maxLength) {
                maxLength = currentLength;
                bestStart = left;
            }
        }

        return text.substring(bestStart, bestStart + maxLength);
    }

    public static void main(String[] args) {
        String[] tests = {"abcabcbb",
                          "bbbbb",
                          "pwwkew",
                          "abcdef",
                          "",
                          "abba"
        };

        for (String text : tests) {
            IO.println("Eingabe: '" + text + "'");
            IO.println("Naiv: '" + longestUniqueSubstringNaive(text) + "'");
            IO.println("Sliding Window: " + longestUniqueSubstring(text));
            IO.println();
        }
    }
}
