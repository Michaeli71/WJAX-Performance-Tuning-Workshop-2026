package solutions.part7_sliding_windows;

public class Exercise3_CosyWeatherPeriod {

    private record TemperatureStreak(
            int startDay,
            int endDay,
            int days
    ) {
        @Override
        public String toString() {
            return """
                    Starttag: %d
                    Endtag: %d
                    Dauer: %d Tage
                    """.formatted(startDay, endDay, days);
        }
    }

    private static TemperatureStreak findLongestComfortablePeriod(int[] temperatures, int maxColdDays) {
        int left = 0;
        int coldDays = 0;

        TemperatureStreak best = new TemperatureStreak(0, -1, 0);

        for (int right = 0; right < temperatures.length; right++) {

            if (temperatures[right] <= 15) {
                coldDays++;
            }

            while (coldDays > maxColdDays) {
                if (temperatures[left] <= 15) {
                    coldDays--;
                }
                left++;
            }

            int currentLength = right - left + 1;
            if (currentLength > best.days()) {
                best = new TemperatureStreak(left, right, currentLength);
            }
        }

        return best;
    }

    static void main() {
        int[] temperatures = {16, 18, 12, 17, 19, 14, 20, 21, 13, 22, 24, 18};
        TemperatureStreak result = findLongestComfortablePeriod(temperatures, 1);
        System.out.println(result);

        int[] temperatures2 = {10, 12, 22, 11, 29, 24, 20, 26, 21, 22, 24, 7};
        TemperatureStreak result2 = findLongestComfortablePeriod(temperatures2, 1);
        System.out.println(result2);
    }
}
