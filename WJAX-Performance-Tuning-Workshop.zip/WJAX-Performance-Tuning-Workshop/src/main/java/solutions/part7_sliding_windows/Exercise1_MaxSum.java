package solutions.part7_sliding_windows;

public class Exercise1_MaxSum {
    static int maxSumNaive(int[] values, int k) {

        int best = Integer.MIN_VALUE;

        for (int start = 0; start <= values.length - k; start++) {

            int currentSum = 0;

            for (int i = start; i < start + k; i++) {
                currentSum += values[i];
            }

            if (currentSum > best) {
                best = currentSum;
            }
        }

        return best;
    }

    static int maxSumSlidingWindow(int[] values, int k) {
        int sum = 0;
        for (int i = 0; i < k; i++) {
            sum += values[i];
        }
        int max = sum;
        for (int i = k; i < values.length; i++) {
            sum += values[i] - values[i - k];
            max = Math.max(max, sum);
        }
        return max;
    }


    static void main() {
        IO.println(maxSumNaive(new int[] {3, 8, 2, 5, 7, 6, 1}, 3));
        IO.println(maxSumSlidingWindow(new int[] {3, 8, 2, 5, 7, 6, 1}, 3));
        IO.println(maxSumNaive(new int[] {1, 2, 3, 4, 5}, 2));
        IO.println(maxSumSlidingWindow(new int[] {1, 2, 3, 4, 5}, 2));
        IO.println(maxSumNaive(new int[] {5, 1, 1, 1, 5}, 3));
        IO.println(maxSumSlidingWindow(new int[] {5, 1, 1, 1, 5}, 3));
        IO.println(maxSumNaive(new int[] {4, 4, 4, 4}, 2));
        IO.println(maxSumSlidingWindow(new int[] {4, 4, 4, 4}, 2));
    }
}
