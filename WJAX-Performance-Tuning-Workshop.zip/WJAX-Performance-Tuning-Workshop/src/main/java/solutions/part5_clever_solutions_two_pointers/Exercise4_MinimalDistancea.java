package solutions.part5_clever_solutions_two_pointers;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Exercise4_MinimalDistancea {

    record MinDifferenceResult(long difference, int index1, int index2) {
    }

    static MinDifferenceResult findMinDifferenceBruteForce(List<Integer> values) {

        MinDifferenceResult best = new MinDifferenceResult(Long.MAX_VALUE, -1, -1);

        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                long difference = Math.abs((long) values.get(i) - values.get(j));

                if (difference < best.difference()) {
                    best = new MinDifferenceResult(difference, i, j);
                }
            }
        }

        return best;
    }

    record IndexedValue(int value, int originalIndex) {
    }

    static MinDifferenceResult findMinDifference(List<Integer> values) {

        if (values.size() < 2) {
            throw new IllegalArgumentException("Die Liste muss mindestens zwei Werte enthalten.");
        }

        List<IndexedValue> sorted = new ArrayList<>();

        for (int i = 0; i < values.size(); i++) {
            sorted.add(new IndexedValue(values.get(i), i));
        }

        sorted.sort(Comparator.comparingInt(IndexedValue::value));

        MinDifferenceResult best = new MinDifferenceResult(Long.MAX_VALUE, -1, -1);

        for (int i = 1; i < sorted.size(); i++) {
            IndexedValue previous = sorted.get(i - 1);
            IndexedValue current = sorted.get(i);

            long difference = (long) current.value() - previous.value();

            if (difference < best.difference()) {
                best = new MinDifferenceResult(difference, previous.originalIndex(), current.originalIndex());
            }
        }

        return best;
    }


    static void main() {
        List<Integer> values = List.of(99, 1, 22, 33, 42, 55, 6, 77, 83, 100, 111, 122, 144);

        System.out.println(findMinDifferenceBruteForce(values));
        System.out.println(findMinDifference(values));
    }
}
