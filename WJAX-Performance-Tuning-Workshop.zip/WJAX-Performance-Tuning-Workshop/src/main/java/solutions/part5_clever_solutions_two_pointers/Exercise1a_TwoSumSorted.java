package solutions.part5_clever_solutions_two_pointers;

public class Exercise1a_TwoSumSorted {
    static void main() {

        int[] values = new int[] {1, 2, 4, 7, 10, 11, 17};
        checkBothImplementations(values, 15);

        int[] values2 = new int[] {1, 2, 4, 7, 10, 11, 13, 17, 19, 23, 27, 42, 55, 71};
        checkBothImplementations(values2, 55);

        int[] values3 = new int[] {1, 2, 5, 6, 7};
        checkBothImplementations(values3, 4);

        int[] values4 = new int[] {1, 2, 3, 5, 6, 7};
        checkBothImplementations(values4, 4);

    }

    private static void checkBothImplementations(int[] values, int k) {
        boolean sumFound = hasPairWithSumBruteForce(values, k);
        IO.println("sum " + k + "? " + sumFound);

        boolean sumFound2 = hasPairWithSumTwoPointer(values, k);
        IO.println("sum " + k + "? " + sumFound2);
    }

    static boolean hasPairWithSumBruteForce(int[] values, int k) {
        for (int i = 0; i < values.length; i++) {
            for (int j = i + 1; j < values.length; j++) {
                if (values[i] + values[j] == k) {
                    return true;
                }
            }
        }
        return false;
    }


    static boolean hasPairWithSumTwoPointer(int[] values, int k) {
        int left = 0;
        int right = values.length - 1;

        while (left < right) {
            int sum = values[left] + values[right];
            if (sum == k)
                return true;

            if (sum < k)
                left++;

            if (sum > k)
                right--;
        }

        return false;
    }
}
