package solutions.part5_clever_solutions_two_pointers;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Exercise3_Anagrams {
    static void main() {
        var word1 = "Ampel";
        var word2 = "Palme";
        var word3 = "Lampe";
        var word4 = "Maple";

        IO.println("Brute Force");
        IO.println(isAnagramBruteForce(word1, word2));
        IO.println(isAnagramBruteForce(word2, word3));
        IO.println(isAnagramBruteForce(word3, word4));

        IO.println("Using Sorting");
        IO.println(isAnagramUsingUsingSorting(word1, word2));
        IO.println(isAnagramUsingUsingSorting(word2, word3));
        IO.println(isAnagramUsingUsingSorting(word3, word4));

        IO.println("Using HashMap Char Frequency");
        IO.println(isAnagramUsingUsingHashMapCharFrequency(word1, word2));
        IO.println(isAnagramUsingUsingHashMapCharFrequency(word2, word3));
        IO.println(isAnagramUsingUsingHashMapCharFrequency(word3, word4));

    }

    static boolean isAnagramBruteForce(String word1, String word2) {
        if (word1.length() != word2.length())
            return false;

        word1 = word1.toLowerCase();
        word2 = word2.toLowerCase();
        char[] availableChars = word2.toCharArray();

        for (int i = 0; i < word1.length(); i++) {
            boolean found = false;
            for (int j = 0; j < availableChars.length; j++) {
                if (word1.charAt(i) == availableChars[j]) {
                    found = true;
                    availableChars[j] = '\0'; // bereits verwendet, durchstreichen
                    break;
                }
            }
            if (!found)
                return false;
        }
        return true;
    }

    static boolean isAnagramUsingUsingSorting(String word1, String word2) {
        if (word1.length() != word2.length())
            return false;

        var word1Chars = word1.toLowerCase().toCharArray();
        var word2Chars = word2.toLowerCase().toCharArray();

        Arrays.sort(word1Chars);
        Arrays.sort(word2Chars);

        return Arrays.compare(word1Chars, word2Chars) == 0;
    }

    private static Object isAnagramUsingUsingHashMapCharFrequency(String word1, String word2) {
        if (word1.length() != word2.length())
            return false;

        var word1Chars = word1.toLowerCase().toCharArray();
        var word2Chars = word2.toLowerCase().toCharArray();

        Map<Character, Integer> charFrequencies1 = new HashMap<>();
        Map<Character, Integer> charFrequencies2 = new HashMap<>();

        for (char ch : word1Chars) {
            int currentCount = charFrequencies1.getOrDefault(ch, 0);
            charFrequencies1.put(ch, currentCount + 1);
        }

        for (char ch : word2Chars) {
            int currentCount = charFrequencies2.getOrDefault(ch, 0);
            charFrequencies2.put(ch, currentCount + 1);
        }

        return charFrequencies1.equals(charFrequencies2);
    }
}
