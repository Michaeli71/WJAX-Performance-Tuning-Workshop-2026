
package solutions.part5_clever_solutions_two_pointers;

import java.util.*;
import java.util.function.Function;

public class Exercise4_MinimalDistance {

    record MinDifferenceResult(long difference, int index1, int index2) {
    }

    record IndexedValue(int value, int originalIndex) {
    }

    // --------------------------------------------------
    // ALGORITHMS
    // --------------------------------------------------

    // O(n²)

    static MinDifferenceResult findMinDifferenceBruteForce(List<Integer> values) {

        MinDifferenceResult best = new MinDifferenceResult(Long.MAX_VALUE, -1, -1);

        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                long difference = Math.abs((long) values.get(i) - values.get(j));

                if (difference < best.difference()) {
                    best = new MinDifferenceResult(difference, i, j);
                }
            }
        }

        return best;
    }

    // O(n log n)
    static MinDifferenceResult findMinDifference(List<Integer> values) {

        if (values.size() < 2) {
            throw new IllegalArgumentException("Die Liste muss mindestens zwei Werte enthalten.");
        }

        List<IndexedValue> sorted = new ArrayList<>();

        for (int i = 0; i < values.size(); i++) {
            sorted.add(new IndexedValue(values.get(i), i));
        }

        sorted.sort(Comparator.comparingInt(IndexedValue::value));

        MinDifferenceResult best = new MinDifferenceResult(Long.MAX_VALUE, -1, -1);

        for (int i = 1; i < sorted.size(); i++) {
            IndexedValue previous = sorted.get(i - 1);
            IndexedValue current = sorted.get(i);

            long difference = (long) current.value() - previous.value();

            if (difference < best.difference()) {
                best = new MinDifferenceResult(difference, previous.originalIndex(), current.originalIndex());
            }
        }

        return best;
    }


    // --------------------------------------------------
    // BENCHMARK CONFIGURATION
    // --------------------------------------------------

    private record Algorithm(
            String name,
            Function<List<Integer>, MinDifferenceResult> function
    ) {}

    private static final List<Algorithm> ALGORITHMS = List.of(
            new Algorithm(
                    "Brute Force",
                    Exercise4_MinimalDistance::findMinDifferenceBruteForce
            ),
            new Algorithm(
                    "Sorting",
                    Exercise4_MinimalDistance::findMinDifference
            )
    );

    private static final int WARMUP_ROUNDS = 2;
    private static final int MEASUREMENT_ROUNDS = 5;

    // Brute Force bei größeren Eingaben überspringen
    private static final int BRUTE_FORCE_LIMIT = 500_000;

    private static volatile long blackhole;

    // --------------------------------------------------
    // TEST DATA
    // --------------------------------------------------

    private static List<Integer> createTestData(int size) {

        List<Integer> values = new ArrayList<>(size);

        // Eindeutige Werte erzeugen
        for (int i = 0; i < size; i++) {
            values.add(i);
        }

        // Reproduzierbare zufällige Reihenfolge
        Collections.shuffle(values, new Random(42));

        return values;
    }

    // --------------------------------------------------
    // BENCHMARK
    // --------------------------------------------------

    private static void benchmark(int size) {

        List<Integer> values = createTestData(size);

        List<Algorithm> algorithms = size <= BRUTE_FORCE_LIMIT
                ? ALGORITHMS
                : ALGORITHMS.subList(1, 2);

        System.out.println();
        System.out.println("=".repeat(76));
        System.out.printf(
                " MINIMAL DISTANCE | %,d ELEMENTS%n", size
        );
        System.out.println("=".repeat(76));

        // Referenzergebnis
        MinDifferenceResult expected = findMinDifference(values);

        System.out.printf(
                "Expected minimum difference: %d%n",
                expected.difference()
        );

        // Warmup
        for (int round = 0; round < WARMUP_ROUNDS; round++) {
            for (Algorithm algorithm : algorithms) {
                consume(algorithm.function.apply(values));
            }
        }

        // Messwerte speichern
        Map<String, double[]> results = new LinkedHashMap<>();

        for (Algorithm algorithm : algorithms) {
            results.put(
                    algorithm.name(),
                    new double[MEASUREMENT_ROUNDS]
            );
        }

        Random random = new Random(42);

        // Messungen
        for (int round = 0; round < MEASUREMENT_ROUNDS; round++) {

            List<Algorithm> order = new ArrayList<>(algorithms);
            Collections.shuffle(order, random);

            for (Algorithm algorithm : order) {

                long start = System.nanoTime();

                MinDifferenceResult result =
                        algorithm.function.apply(values);

                long elapsed = System.nanoTime() - start;

                // Ergebnis überprüfen
                if (result.difference() != expected.difference()) {
                    throw new AssertionError(
                            algorithm.name() + " liefert falsches Ergebnis!"
                    );
                }

                consume(result);

                results.get(algorithm.name())[round] =
                        elapsed / 1_000_000.0;
            }
        }

        printResults(results);
    }

    // --------------------------------------------------
    // RESULT EVALUATION
    // --------------------------------------------------

    private static void consume(MinDifferenceResult result) {

        blackhole ^= result.difference()
                + result.index1()
                + result.index2();
    }

    private static void printResults(
            Map<String, double[]> results) {

        System.out.println();

        System.out.printf(
                "%-20s %12s %12s %12s%n",
                "Algorithmus",
                "Median (ms)",
                "Avg (ms)",
                "Faktor"
        );

        System.out.println("-".repeat(62));

        Map<String, Double> medians = new LinkedHashMap<>();

        for (var entry : results.entrySet()) {

            double[] times = entry.getValue().clone();
            Arrays.sort(times);

            double median = times[times.length / 2];

            medians.put(entry.getKey(), median);
        }

        double fastest = medians.values().stream()
                .mapToDouble(Double::doubleValue)
                .min()
                .orElseThrow();

        for (var entry : results.entrySet()) {

            double[] times = entry.getValue();

            double median = medians.get(entry.getKey());

            double average = Arrays.stream(times)
                    .average()
                    .orElse(0);

            System.out.printf(
                    "%-20s %12.3f %12.3f %11.2fx%n",
                    entry.getKey(),
                    median,
                    average,
                    median / fastest
            );
        }

        System.out.println("-".repeat(62));
        System.out.println("Alle Messwerte in Millisekunden.");
    }

    // --------------------------------------------------
    // MAIN
    // --------------------------------------------------

    static void main() {

        int[] sizes = {
                1_000,
                5_000,
                10_000,
                50_000,
                100_000,
                500_000
        };

        System.out.println();
        System.out.println("MINIMAL DISTANCE");
        System.out.println("Algorithm Benchmark");
        System.out.println("Warmup: " + WARMUP_ROUNDS + " rounds");
        System.out.println("Measurements: " + MEASUREMENT_ROUNDS + " rounds");

        for (int size : sizes) {
            benchmark(size);
        }

        System.out.println();
        System.out.println("Benchmark completed.");
    }
}
