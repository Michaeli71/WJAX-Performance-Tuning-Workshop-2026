package solutions.part5_clever_solutions_two_pointers;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/// Trick: komplementärwert berechnen und danach suchen
///
/// Alle Werte, die man schon besucht hat, in einem HashSet `alreadySeen` speichern
/// Für jede aktuelle Zahl, den Komplementärwert ermitteln und in `alreadySeen`
/// nachschauen.
///
/// Weil wir Positionen zurückgeben wollen, benötigen wir eine `HashMap`.
///
/// Einschränkung: Duplikate werden nicht unterstützt
/// Besonderheit im Daten bestand 1, 2, 3, 7, 5, k = 2, darf nicht an gleicher Psotion sein*
public class Exercise1b_TwoSumUnsorted {

    record SearchResult(int pos1, int pos2, boolean found) {}

    static void main() {

        int[] values = new int[] {1, 2,  17, 11, 7, 4, 10};
        performSearch(values, 15);

        int[] values2 = new int[] {1, 2, 6, 7, 5};
        performSearch(values2, 4);

        int[] values3 = new int[] {1, 3, 2, 6, 7, 5};
        performSearch(values3, 4);
    }

    private static void performSearch(int[] values, int k) {
        SearchResult sumFound1 = hasPairWithSumBruteForce(values, k);
        IO.println("sum " + k + "? " + sumFound1);

        SearchResult sumFound2 = hasPairWithSumUnsortedByComplement(values, k);
        IO.println("sum " + k + "? " + sumFound2);

        boolean sumFound3 = hasPairWithSumUnsortedByComplementSimple(values, k);
        IO.println("sum " + k + "? " + sumFound3);
    }

    private static SearchResult hasPairWithSumUnsortedByComplement(int[] values, int k) {
        Map<Integer, Integer> alreadySeen = new HashMap<>();

        for (int i = 0; i < values.length; i++) {
            int currentValue = values[i];
            int complement = k - currentValue;

            if (alreadySeen.containsKey(complement)) {
                int complementPos = alreadySeen.get(complement);
                return new SearchResult(complementPos, i, true);
            }
            alreadySeen.put(currentValue, i);
        }

        return new SearchResult(-1, -1, false);
    }

    static SearchResult hasPairWithSumBruteForce(int[] values, int k) {
        for (int i = 0; i < values.length; i++) {
            for (int j = i + 1; j < values.length; j++) {
                if (values[i] + values[j] == k)
                    return new SearchResult(i, j, true);

            }
        }
        return new SearchResult(-1, -1, false);
    }

    private static boolean hasPairWithSumUnsortedByComplementSimple(int[] values, int k) {
        Set<Integer> alreadySeen = new HashSet<>();

        for (int i = 0; i < values.length; i++) {
            int currentValue = values[i];
            int complement = k - currentValue;

            if (alreadySeen.contains(complement))
                return true;

            alreadySeen.add(currentValue);
        }

        return false;
    }
}
