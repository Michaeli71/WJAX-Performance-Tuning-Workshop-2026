package solutions.part5_clever_solutions_two_pointers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;

public class Exercise2_MaxArea {

    record PosHeightArea(int left, int right, int height, long area) {
    }

    static PosHeightArea largestAreaBruteForce(List<Integer> values) {
        PosHeightArea best = new PosHeightArea(0, 0, 0, 0);
        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                int width = j - i;
                int minHeight = Math.min(values.get(i), values.get(j));
                long area = (long) width * minHeight;
                if (area > best.area()) {
                    best = new PosHeightArea(i, j, minHeight, area);
                }
            }
        }
        return best;
    }

    private static PosHeightArea largestAreaTwoPointer(List<Integer> values) {
        PosHeightArea best = new PosHeightArea(0, 0, 0, 0);

        int left = 0;
        int right = values.size() - 1;

        while (left < right) {
            int width = right - left;
            int minHeight = Math.min(values.get(left), values.get(right));
            int area = width * minHeight;
            if (area > best.area()) {
                best = new PosHeightArea(left, right, minHeight, area);
            }

            // Immer den kleineren Pointer verschieben
            if (values.get(left) < values.get(right))
                left++;
            else if (values.get(left) >= values.get(right))
                right--;
        }

        return best;
    }


    static void main() {

        List<Integer> values = Arrays.asList(3, 7, 5, 2, 6, 4, 8, 1, 6, 2);

        PosHeightArea maxArea = largestAreaBruteForce(values);
        IO.println("max area: " + maxArea);

        PosHeightArea maxArea2 = largestAreaTwoPointer(values);
        IO.println("max area: " + maxArea2);

        var values2 = List.of(2, 5, 7, 3, 4);
        System.out.println(largestAreaBruteForce(values));

        values2 = List.of(2, 5, 7, 3, 4, 6);
        System.out.println(largestAreaBruteForce(values));

        values2 = List.of(2, 5, 7, 3, 4, 6, 6, 7);
        System.out.println(largestAreaBruteForce(values));


        for (int size : new int[] {10_000, 100_000, 1_000_000, 10_000_000})
        {
            measureLargestArea(size);
        }

    }

    private static void measureLargestArea(int endExclusive) {
        System.out.println("measurePairSumOrderedOptimized for length = " + endExclusive);

        // "dreieckige Daten aufbauen, mit 0 in der Mitte, rechts etwas tiefer"
        List<Integer> values = new ArrayList<>(IntStream.range(0, endExclusive).boxed().toList());
        Collections.reverse(values);
        values.addAll(IntStream.range(0, endExclusive - 123).boxed().toList());

        long start = System.currentTimeMillis();
        System.out.println(largestAreaBruteForce(values));
        long end = System.currentTimeMillis();

        System.out.println("largestAreaBruteForce() took " + (end - start) + " ms");


        long start2 = System.currentTimeMillis();
        System.out.println(largestAreaTwoPointer(values));
        long end2 = System.currentTimeMillis();

        System.out.println("largestAreaTwoPointer() took " + (end2 - start2) + " ms");
    }
}
