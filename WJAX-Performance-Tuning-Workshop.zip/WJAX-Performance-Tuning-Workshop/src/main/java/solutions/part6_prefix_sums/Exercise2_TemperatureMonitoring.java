package solutions.part6_prefix_sums;

public class Exercise2_TemperatureMonitoring {

    private record TemperaturePeriod(int sum, int startDay, int endDay, int days
    ) {
        @Override
        public String toString() {
            return """
                    Temperatur-Summe: %d °C
                    Zeitraum: Tag %d bis %d
                    Dauer: %d Tage
                    Durchschnitt: %.2f °C
                    """.formatted(sum, startDay, endDay, days, (double) sum / days
            );
        }
    }

    private static int[] calculateTemperaturePrefixSums(int[] temperatures) {
        if (temperatures.length == 0)
            return new int[0];

        int[] prefix = new int[temperatures.length];
        prefix[0] = temperatures[0];

        for (int i = 1; i < temperatures.length; i++) {
            prefix[i] = prefix[i - 1] + temperatures[i];
        }

        return prefix;
    }

    private static int sumTemperatureRange(int[] prefix, int start, int end) {
        int lowerValue = start > 0 ? prefix[start - 1] : 0;

        return prefix[end] - lowerValue;
    }


    private static TemperaturePeriod findWarmestWeek(int[] prefix) {

        if (prefix.length < 7)
            throw new IllegalArgumentException("Prefix length less than 7, need at least one full week");

        int weekSize = 7;

        int initialMaxSum = sumTemperatureRange(prefix, 0, weekSize - 1);

        TemperaturePeriod max = new TemperaturePeriod(initialMaxSum, 0, weekSize - 1, weekSize);

        for (int start = 1; start <= prefix.length - weekSize; start++) {
            int end = start + weekSize - 1;

            int sum = sumTemperatureRange(prefix, start, end);
            if (sum > max.sum()) {
                max = new TemperaturePeriod(sum, start, end, weekSize);
            }
        }

        return max;
    }

    private static TemperaturePeriod findColdestWeek(int[] prefix) {

        int weekSize = 7;

        int minSum = sumTemperatureRange(prefix, 0, weekSize - 1);

        TemperaturePeriod min = new TemperaturePeriod(
                minSum, 0, weekSize - 1, weekSize
        );

        for (int start = 1; start <= prefix.length - weekSize; start++) {

            int end = start + weekSize - 1;

            int sum = sumTemperatureRange(prefix, start, end);

            if (sum < min.sum()) {
                min = new TemperaturePeriod(sum, start, end, weekSize);
            }
        }

        return min;
    }


    private static final int[] TEMPERATURES = {
            12, 15, 18, 14, 11, 9, 8, 13, 17, 20,
            22, 19, 16, 14, 12, 10, 7, 9, 13, 18,
            21, 24, 23, 19, 16, 14, 11, 8, 10, 15
    };

    static void main() {

        int[] prefix = calculateTemperaturePrefixSums(TEMPERATURES);

        TemperaturePeriod warmest = findWarmestWeek(prefix);
        TemperaturePeriod coldest = findColdestWeek(prefix);

        System.out.println("=== WÄRMSTE WOCHE ===");
        System.out.println(warmest);

        System.out.println("=== KÄLTESTE WOCHE ===");
        System.out.println(coldest);
    }
}
