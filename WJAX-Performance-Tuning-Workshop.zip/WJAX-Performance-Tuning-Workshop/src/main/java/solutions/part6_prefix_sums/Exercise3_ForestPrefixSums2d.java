package solutions.part6_prefix_sums;

import java.util.Arrays;
import java.util.Objects;

public final class Exercise3_ForestPrefixSums2d {

    public static int[][] calculatePrefixSums2d(int[][] values2d) {
        Objects.requireNonNull(values2d);

        int rows = values2d.length;
        int cols = rows == 0 ? 0 : values2d[0].length;

        for (int[] row : values2d) {
            if (row == null || row.length != cols) {
                throw new IllegalArgumentException("Matrix muss rechteckig sein");
            }
        }

        int[][] prefix = new int[rows + 1][cols + 1];

        // 1. Spaltenweise aufsummieren
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                prefix[r + 1][c + 1] =
                        prefix[r][c + 1] + values2d[r][c];
            }
        }

        // 2. Zeilenweise aufsummieren
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                prefix[r + 1][c + 1] += prefix[r + 1][c];
            }
        }

        return prefix;
    }

    ///  forest[r][c] = 1 für ein Baum, 2 für 2 Bäume usw., 0 für freie Fläche.
    ///
    /// forest[r][c]	Aktueller Wert
    /// prefix[r][c + 1]	Summe oberhalb
    /// prefix[r + 1][c]	Summe links
    /// - prefix[r][c]	Doppelt gezählten Bereich abziehen
    public static int[][] calculatePrefixSums2dOptimzed(int[][] values2d) {
        Objects.requireNonNull(values2d);

        int rows = values2d.length;
        int cols = rows == 0 ? 0 : values2d[0].length;
        for (int[] row : values2d) {
            if (row == null || row.length != cols) throw new IllegalArgumentException("Matrix muss rechteckig sein");
        }

        // Variante mit zusätzliche 0-Spalte/Zeile
        final int[][] prefix = new int[rows + 1][cols + 1];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {

                // beide Dimensionen gleichzeitig berechnen
                prefix[r + 1][c + 1] = values2d[r][c] +
                        prefix[r][c + 1] + prefix[r + 1][c] - prefix[r][c];
            }
        }
        return prefix;
    }

    // Inklusive Grenzen: row1..row2 und col1..col2.
    public static int sumRegion(final int[][] prefix, int row1, int col1, int row2, int col2) {
        int rows = prefix.length;
        int cols = rows == 0 ? 0 : prefix[0].length;

        if (row1 < 0 || col1 < 0 || row2 < row1 || col2 < col1 || row2 >= rows || col2 >= cols) {
            throw new IndexOutOfBoundsException("Ungültiges Rechteck");
        }

        return prefix[row2 + 1][col2 + 1] - prefix[row1][col2 + 1]
                - prefix[row2 + 1][col1] + prefix[row1][col1];
    }


    static void main() {

        var forest = new int[][] {{3, 1, 5},
                                  {2, 4, 6},
                                  {8, 7, 9}};
        var result = calculatePrefixSums2d(forest);
        IO.println(Arrays.deepToString(result));
        IO.println(sumRegion(result, 1, 1, 2, 2));

        result = calculatePrefixSums2dOptimzed(forest);
        IO.println(Arrays.deepToString(result));
        IO.println(sumRegion(result, 1, 1, 2, 2));

        var forest2 = new int[][] {{1, 2, 3},
                                   {4, 5, 6,},
                                   {7, 8, 9}};
        var result2 = calculatePrefixSums2d(forest2);
        IO.println(Arrays.deepToString(result2));
        IO.println(sumRegion(result2, 1, 1, 2, 2));

        result2 = calculatePrefixSums2dOptimzed(forest2);
        IO.println(Arrays.deepToString(result2));
        IO.println(sumRegion(result2, 1, 1, 2, 2));


        bonusMaxMinTreeArea();
    }


    private static final int[][] FOREST = {
            {12, 15, 8, 4, 6, 18, 20, 17, 3, 5, 7, 9, 11, 14, 16},
            {10, 13, 7, 5, 8, 16, 19, 21, 4, 6, 8, 10, 12, 15, 17},
            {11, 14, 9, 6, 7, 17, 22, 20, 5, 7, 9, 11, 13, 16, 18},
            {8, 12, 6, 3, 5, 15, 18, 23, 2, 4, 6, 8, 10, 13, 15},
            {9, 11, 8, 4, 6, 19, 21, 24, 3, 5, 7, 9, 11, 14, 16},
            {20, 22, 18, 15, 17, 5, 3, 4, 21, 23, 19, 16, 18, 20, 22},
            {21, 24, 19, 16, 18, 4, 2, 5, 22, 25, 20, 17, 19, 21, 23},
            {19, 23, 17, 14, 16, 3, 1, 4, 20, 24, 18, 15, 17, 19, 21},
            {22, 25, 20, 17, 19, 6, 4, 3, 23, 26, 21, 18, 20, 22, 24},
            {18, 21, 16, 13, 15, 5, 2, 3, 19, 22, 17, 14, 16, 18, 20},
            {2, 3, 4, 5, 3, 8, 9, 7, 4, 3, 2, 5, 4, 3, 2},
            {3, 4, 2, 6, 4, 7, 10, 8, 3, 4, 3, 6, 5, 2, 3},
            {4, 5, 3, 4, 2, 9, 11, 6, 5, 2, 4, 3, 6, 4, 5},
            {2, 3, 5, 3, 4, 6, 8, 5, 2, 3, 5, 4, 3, 5, 4},
            {3, 2, 4, 5, 3, 7, 9, 6, 3, 4, 2, 5, 4, 3, 2}
    };

    private record TreeAreaResult(
            int sum,
            int row,
            int col,
            int size
    ) {
        @Override
        public String toString() {
            return """
                Baumbestand: %d
                Startposition: (%d, %d)
                Grösse: %d x %d
                """.formatted(sum, row, col, size, size);
        }
    }

    private static void bonusMaxMinTreeArea() {

        int areaSize = 5;

        int rows = FOREST.length;
        int cols = FOREST[0].length;

        // 1. Prefix-Sum-Matrix berechnen
        int[][] prefix = calculatePrefixSums2d(FOREST);

        // 2. Minimum und Maximum initialisieren
        int initialSum = sumRegion(prefix, 0, 0, areaSize - 1, areaSize - 1);

        TreeAreaResult min = new TreeAreaResult(initialSum, 0, 0, areaSize);
        TreeAreaResult max = min;

        // 3. Alle möglichen Rechtecke untersuchen
        for (int r = 0; r <= rows - areaSize; r++) {
            for (int c = 0; c <= cols - areaSize; c++) {

                // 4. Summe über bestehende Methode berechnen
                int sum = sumRegion(prefix, r, c, r + areaSize - 1, c + areaSize - 1);

                TreeAreaResult current =
                        new TreeAreaResult(sum, r, c, areaSize);

                if (sum < min.sum()) {
                    min = current;
                }

                if (sum > max.sum()) {
                    max = current;
                }
            }
        }

        System.out.println("=== DICHTESTER WALDABSCHNITT ===");
        System.out.println(max);

        System.out.println("\n=== DÜNNSTER WALDABSCHNITT ===");
        System.out.println(min);
    }
}
