package solutions.part6_prefix_sums;

import java.util.Arrays;

public class Exercise1_PrefixProducts {

    public static int[] prefixProducts(int[] values) {
        int[] result = new int[values.length];
        int current = 1;

        for (int i = 0; i < values.length; i++) {
            current *= values[i];
            result[i] = current;
        }

        return result;
    }

    static long[] prefixProducts(long[] values) {
        long[] result = new long[values.length];
        if (values.length == 0)
            return result;

        result[0] = values[0];
        for (int i = 1; i < values.length; i++) {
            result[i] = values[i] * result[i - 1];
        }
        return result;
    }

    static void main() {
        int[] values = {2, 3, 4, 5, 6, 10};
        int[] result = prefixProducts(values);

        IO.println(Arrays.toString(result));

        long[] valuee2 = {2, 3, 4, 5, 6, 10};
        long[] result2 = prefixProducts(valuee2);

        IO.println(Arrays.toString(result2));
    }
}