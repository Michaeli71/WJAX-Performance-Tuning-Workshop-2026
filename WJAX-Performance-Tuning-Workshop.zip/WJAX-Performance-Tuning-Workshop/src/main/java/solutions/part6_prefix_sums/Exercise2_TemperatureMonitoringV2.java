package solutions.part6_prefix_sums;

public class Exercise2_TemperatureMonitoringV2 {

    private record TemperatureAnalysis(
            TemperaturePeriod warmest,
            TemperaturePeriod coldest,
            double averageWeeklyTemperature
    ) {
    }

    private record TemperaturePeriod(int sum, int startDay, int endDay, int days
    ) {
        @Override
        public String toString() {
            return """
                    Temperatur-Summe: %d °C
                    Zeitraum: Tag %d bis %d
                    Dauer: %d Tage
                    Durchschnitt: %.2f °C
                    """.formatted(sum, startDay, endDay, days, (double) sum / days
            );
        }
    }

    private static int[] calculateTemperaturePrefixSums(int[] temperatures) {
        if (temperatures.length == 0)
            return new int[0];

        int[] prefix = new int[temperatures.length];
        prefix[0] = temperatures[0];

        for (int i = 1; i < temperatures.length; i++) {
            prefix[i] = prefix[i - 1] + temperatures[i];
        }

        return prefix;
    }

    private static int sumTemperatureRange(int[] prefix, int start, int end) {
        int lowerValue = start > 0 ? prefix[start - 1] : 0;

        return prefix[end] - lowerValue;
    }

    private static TemperatureAnalysis analyzeTemperatures(int[] prefix) {
        if (prefix.length < 7)
            throw new IllegalArgumentException("Prefix length less than 7, need at least one full week");

        int weekSize = 7;

        // Erste Woche als Initialwert
        int firstSum = sumTemperatureRange(prefix, 0, weekSize - 1);

        TemperaturePeriod warmest = new TemperaturePeriod(firstSum, 0, 6, weekSize);

        TemperaturePeriod coldest = warmest;

        int totalWeeklySums = firstSum;
        int weeks = 1;

        // Alle weiteren Wochen untersuchen
        for (int start = 1; start <= prefix.length - weekSize; start++) {

            int end = start + weekSize - 1;

            int sum = sumTemperatureRange(prefix, start, end);

            TemperaturePeriod current = new TemperaturePeriod(sum, start, end, weekSize);

            if (sum > warmest.sum()) {
                warmest = current;
            }

            if (sum < coldest.sum()) {
                coldest = current;
            }

            totalWeeklySums += sum;
            weeks++;
        }

        double averageWeeklyTemperature =
                (double) totalWeeklySums / weeks / weekSize;

        return new TemperatureAnalysis(warmest, coldest,
                                       averageWeeklyTemperature
        );
    }


    private static final int[] TEMPERATURES = {
            12, 15, 18, 14, 11, 9, 8, 13, 17, 20,
            22, 19, 16, 14, 12, 10, 7, 9, 13, 18,
            21, 24, 23, 19, 16, 14, 11, 8, 10, 15
    };


    /// Beim Durchschnitt gibt es zwei mögliche Interpretationen:
    ///
    /// | Berechnung	| Bedeutung |
    /// |--------------------------------------|------------------------------------------------------|
    /// | Durchschnitt aller Wochenmittelwerte	|  Jede mögliche 7-Tage-Periode wird gleich gewichtet |
    /// | Durchschnitt aller Tageswerte	| Jeder Tag wird genau einmal berücksichtigt |
    ///
    /// Die erste Implementierung berechnet den Durchschnitt aller möglichen 7-Tage-Fenster.
    /// Da sich diese Fenster überlappen, ist das nicht dasselbe wie der Durchschnitt aller Tageswerte.
    static void main() {

        int[] prefix = calculateTemperaturePrefixSums(TEMPERATURES);

        TemperatureAnalysis result = analyzeTemperatures(prefix);

        System.out.println("=== TEMPERATURAUSWERTUNG ===");

        System.out.println("\nWÄRMSTE WOCHE:");
        System.out.println(result.warmest());

        System.out.println("KÄLTESTE WOCHE:");
        System.out.println(result.coldest());

        System.out.printf("Durchschnittliche Wochentemperatur: %.2f °C%n", result.averageWeeklyTemperature()
        );

        double average = (double) prefix[prefix.length - 1] / prefix.length;
        System.out.printf("Durchschnittliche Temperatur: %.2f °C%n", average);


        // BONUS
        TemperatureStreak warmPeriod = findLongestWarmPeriod(TEMPERATURES);

        System.out.println("=== LÄNGSTE WÄRMEPERIODE ===");
        System.out.println(warmPeriod);
    }


    // =================

    private record TemperatureStreak(
            int startDay,
            int endDay,
            int days
    ) {
        @Override
        public String toString() {
            return """
                    Zeitraum: Tag %d bis %d
                    Dauer: %d Tage
                    """.formatted(startDay, endDay, days);
        }
    }

    /// zwei Zähler:
    /// - currentLength: Länge des aktuell untersuchten Zeitraums.
    /// - longest.days(): Länge des bisher längsten Zeitraums.
    /// Sobald eine Temperatur kleiner oder gleich 15 °C ist, wird der aktuelle Zeitraum zurückgesetzt.
    private static TemperatureStreak findLongestWarmPeriod(int[] temperatures) {

        int currentStart = 0;
        int currentLength = 0;

        TemperatureStreak longest = new TemperatureStreak(0, -1, 0);

        for (int i = 0; i < temperatures.length; i++) {

            if (temperatures[i] > 15) {

                if (currentLength == 0) {
                    currentStart = i;
                }

                currentLength++;

                if (currentLength > longest.days()) {
                    longest = new TemperatureStreak(currentStart, i, currentLength);
                }

            } else {
                currentLength = 0;
            }
        }

        return longest;
    }
}
