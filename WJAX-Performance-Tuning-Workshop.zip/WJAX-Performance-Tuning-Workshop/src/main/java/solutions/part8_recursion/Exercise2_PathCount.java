package solutions.part8_recursion;

import java.util.Arrays;

public class Exercise2_PathCount {

    static int countPathsRecursive(int row, int col) {
        // Ausserhalb des Gitters
        if (row < 0 || col < 0) {
            return 0;
        }

        // Startfeld erreicht
        if (row == 0 && col == 0) {
            return 1;
        }

        // Wege von oben und links addieren
        return countPathsRecursive(row - 1, col) + countPathsRecursive(row, col - 1);
    }

    static int countPaths(int rows, int cols) {

        int[][] memo = new int[rows][cols];

        for (int r = 0; r < rows; r++) {
            Arrays.fill(memo[r], -1);
        }

        return countPathsRecursive(rows - 1, cols - 1, memo);
    }

    static int countPathsRecursive(int row, int col, int[][] memo) {

        // Basisfall: oberster oder linker Rand
        if (row == 0 || col == 0) {
            return 1;
        }

        // Ergebnis bereits berechnet?
        if (memo[row][col] != -1) {
            return memo[row][col];
        }

        // Wege von oben und links kombinieren
        memo[row][col] = countPathsRecursive(row - 1, col, memo) + countPathsRecursive(row, col - 1, memo);

        return memo[row][col];
    }

    static int countPathsIterative(int rows, int cols) {

        int[][] dp = new int[rows][cols];

        // Erste Zeile und erste Spalte:
        // jeweils genau ein möglicher Weg
        for (int r = 0; r < rows; r++) {
            dp[r][0] = 1;
        }

        for (int c = 0; c < cols; c++) {
            dp[0][c] = 1;
        }

        // Alle übrigen Felder berechnen
        for (int r = 1; r < rows; r++) {
            for (int c = 1; c < cols; c++) {
                dp[r][c] = dp[r - 1][c] + dp[r][c - 1];
            }
        }

        return dp[rows - 1][cols - 1];
    }

    static void main() {
        int rows = 10; // 15 /  20
        int cols = 20;

        // Aufruf etwas verwirrend durch 0-based Index
        int result = countPathsRecursive(rows - 1, cols - 1);

        IO.println("Anzahl Wege: " + result);

        int result2 = countPaths(rows, cols);

        IO.println("Anzahl Wege: " + result2);

        int result3 = countPathsIterative(rows, cols);

        IO.println("Anzahl Wege: " + result3);


        // ######################

        boolean[][] blocked = new boolean[rows][cols];
        blocked[1][1] = true;
        blocked[2][4] = true;
        blocked[3][2] = true;
        blocked[4][5] = true;
        blocked[7][7] = true;
        int result4 = countPaths(rows, cols, blocked);

        IO.println("Anzahl Wege: " + result4);

    }

    // BONUS
    static int countPaths(int rows, int cols, boolean[][] blocked) {

        int[][] memo = new int[rows][cols];

        for (int r = 0; r < rows; r++) {
            Arrays.fill(memo[r], -1);
        }

        return countPathsRecursive(rows - 1, cols - 1, memo, blocked);
    }

    static int countPathsRecursive(
            int row, int col,
            int[][] memo,
            boolean[][] blocked) {

        // Ausserhalb des Gitters
        if (row < 0 || col < 0) {
            return 0;
        }

        // Blockiertes Feld
        if (blocked[row][col]) {
            return 0;
        }

        // Startfeld erreicht
        if (row == 0 && col == 0) {
            return 1;
        }

        // Ergebnis bereits berechnet?
        if (memo[row][col] != -1) {
            return memo[row][col];
        }

        // Wege von oben und links kombinieren
        memo[row][col] = countPathsRecursive(row - 1, col, memo, blocked) + countPathsRecursive(row, col - 1, memo, blocked);

        return memo[row][col];
    }

    static long countPathsWithObstacles(
            int rows, int cols, boolean[][] blocked) {

        long[][] dp = new long[rows][cols];

        // Startfeld blockiert?
        if (blocked[0][0]) {
            return 0;
        }

        dp[0][0] = 1;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {

                // Blockierte Felder können nicht erreicht werden
                if (blocked[r][c]) {
                    dp[r][c] = 0;
                    continue;
                }

                // Startfeld wurde bereits initialisiert
                if (r == 0 && c == 0) {
                    continue;
                }

                // Wege von oben addieren
                if (r > 0) {
                    dp[r][c] += dp[r - 1][c];
                }

                // Wege von links addieren
                if (c > 0) {
                    dp[r][c] += dp[r][c - 1];
                }
            }
        }

        return dp[rows - 1][cols - 1];
    }

    static long countPathsRecursive(
            int row, int col, boolean[][] blocked) {

        // Ausserhalb des Gitters
        if (row < 0 || col < 0) {
            return 0;
        }

        // Feld ist blockiert
        if (blocked[row][col]) {
            return 0;
        }

        // Startfeld erreicht
        if (row == 0 && col == 0) {
            return 1;
        }

        // Wege von oben und links addieren
        return countPathsRecursive(row - 1, col, blocked) + countPathsRecursive(row, col - 1, blocked);
    }
}
