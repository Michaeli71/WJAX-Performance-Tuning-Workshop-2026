package solutions.part8_recursion;

import java.util.Arrays;

public class Exercise3_EditDistance {

    static int editDistanceMemo(String a, String b) {

        int[][] memo = new int[a.length() + 1][b.length() + 1];

        // -1 bedeutet: noch nicht berechnet
        for (int[] row : memo) {
            Arrays.fill(row, -1);
        }

        return editDistanceRecursive(a, b, a.length(), b.length(), memo);
    }

    private static int editDistanceRecursive(String a, String b, int i, int j, int[][] memo) {

        // Basisfälle
        if (i == 0) {
            return j;
        }

        if (j == 0) {
            return i;
        }

        // Bereits berechnet?
        if (memo[i][j] != -1) {
            return memo[i][j];
        }

        // Letzte Zeichen vergleichen
        if (a.charAt(i - 1) == b.charAt(j - 1)) {
            memo[i][j] = editDistanceRecursive(a, b, i - 1, j - 1, memo);
        } else {
            int insert = editDistanceRecursive(a, b, i, j - 1, memo);
            int delete = editDistanceRecursive(a, b, i - 1, j, memo);
            int replace = editDistanceRecursive(a, b, i - 1, j - 1, memo);

            memo[i][j] = 1 + Math.min(insert, Math.min(delete, replace));
        }

        return memo[i][j];
    }


    static int editDistance(String a, String b) {

        int[][] dp = new int[a.length() + 1][b.length() + 1];

        // Basisfälle: leere Präfixe
        for (int i = 0; i <= a.length(); i++) {
            dp[i][0] = i;
        }

        for (int j = 0; j <= b.length(); j++) {
            dp[0][j] = j;
        }

        // Alle übrigen Teilprobleme berechnen
        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {

                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    int insert = dp[i][j - 1];
                    int delete = dp[i - 1][j];
                    int replace = dp[i - 1][j - 1];

                    dp[i][j] = 1 + Math.min(insert, Math.min(delete, replace));
                }
            }
        }

        return dp[a.length()][b.length()];
    }

    static void main() {
        String a = "HAUS";
        String b = "MAUS";

        System.out.println(editDistanceMemo(a, b)); // 1
        System.out.println(editDistance(a, b));     // 1

        String cheese1 = "LEERDAMMER";
        String cheese2 = "EMMENTALER";
        System.out.println(editDistanceMemo(cheese1, cheese2)); // 7
        System.out.println(editDistance(cheese1, cheese2));     // 7

        String name1 = "MICHAEL";
        String name2 = "CAROLINE";
        String name3 = "MERTEN";
        System.out.println(editDistanceMemo(name1, name2)); // 8
        System.out.println(editDistance(name1, name2));     // 8
        System.out.println(editDistanceMemo(name1, name3)); // 5
        System.out.println(editDistance(name1, name3));     // 5

    }
}
