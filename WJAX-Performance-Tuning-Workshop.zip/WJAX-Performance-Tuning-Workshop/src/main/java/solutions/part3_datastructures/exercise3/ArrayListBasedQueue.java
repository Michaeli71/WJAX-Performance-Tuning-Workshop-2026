package solutions.part3_datastructures.exercise3;

import java.util.ArrayList;
import java.util.List;

class ArrayListBasedQueue<T> {
    private final List<T> values = new ArrayList<>();

    public void enqueue(T value) {
        values.addLast(value);
    }

    public T dequeue() {
        if (values.isEmpty())
            return null;

        // return values.remove(0);
        return values.removeFirst();
    }

    public boolean isEmpty() {
        return values.isEmpty();
    }

    // convenience
    public T peek() {
        return values.getFirst();
    }

    public int size() {
        return values.size();
    }
}
