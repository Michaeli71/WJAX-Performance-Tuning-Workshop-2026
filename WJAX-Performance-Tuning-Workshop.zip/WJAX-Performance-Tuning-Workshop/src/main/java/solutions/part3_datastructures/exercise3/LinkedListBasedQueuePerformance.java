package solutions.part3_datastructures.exercise3;

public class LinkedListBasedQueuePerformance {


    public static void main(String[] args) {
        var queue = new LinkedListBasedQueue<Integer>();

        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);

        System.out.println("Peek");
        System.out.println(queue.peek());

        while (!queue.isEmpty())
            System.out.println(queue.dequeue());

        System.out.println("Populating heavily");
        queue = new LinkedListBasedQueue<Integer>();
        for (int i = 0; i < 10_000; i++)
            queue.enqueue(i);

        System.out.println("De-Populating heavily");
        while (!queue.isEmpty()) {
            var value = queue.dequeue();
            if (value % 1_000 == 0)
                System.out.println(value);
        }

        System.out.println("Populating heavily II");
        long start = System.currentTimeMillis();
        for (int i = 0; i < 1_000_000; i++)
            queue.enqueue(i);

        System.out.println("De-Populating heavily II");
        while (!queue.isEmpty()) {
            var value = queue.dequeue();
            if (value % 100_000 == 0)
                System.out.println(value);
        }
        long end = System.currentTimeMillis();

        System.out.println("enqueue()/dequeue() x 1_000_000 took " + (end - start) + " ms");
        System.out.println("E N D");
    }
}
