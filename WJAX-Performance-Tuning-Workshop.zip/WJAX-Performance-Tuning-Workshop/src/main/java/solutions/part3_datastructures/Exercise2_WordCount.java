package solutions.part3_datastructures;

import java.util.*;

public class Exercise2_WordCount {

    record WordCount(String word, int count) {}

    static Map<String, WordCount> countUsingMap(List<String> words) {
        Map<String, WordCount> result = new HashMap<>();

        for (String word : words) {
            String key = word.toLowerCase();

            result.putIfAbsent(key, new WordCount(key, 1));

            result.computeIfPresent(key, (k, old) ->
                new WordCount(key, old.count() + 1)
            );
        }

        return result;
    }

    static void main() {
        var text = """
                   Das ist eine kleine Geschichte über zwei Freunde. Es geht um Tim und Tom.
                   Tim und Tom sind beste Freunde. Tim und Tom haben viele Abenteuer erlebt. 
                   Es war für Tim und Tom spannend. Es war eine tolle Geschichte. Es gibt 
                   viel zu erzählen. Das war die Geschichte von Tim und Tom.
                   """.split(" |\\.|\\n");

        List<String> words = new ArrayList<>(Arrays.asList(text));
        words.removeIf(str -> str.isEmpty());
        IO.println("Übersicht der Wörter: " + countUsingMap(words));
    }
}
