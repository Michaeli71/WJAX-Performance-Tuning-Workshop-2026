package solutions.part4_search_and_sort;

import java.util.ArrayList;
import java.util.List;

public class Exercsie3_InsertionSort {
    static void move_to_insertion_pos(List<Integer> values, int i) {
        int insertion_pos = i;
        var tmp = values.get(insertion_pos);

        // Origialwert nach links durchreichen, solange der Wert links davon grösser
        while (insertion_pos > 0 && values.get(insertion_pos - 1) > tmp) {
            values.set(insertion_pos, values.get(insertion_pos - 1));
            insertion_pos -= 1;
        }
        values.set(insertion_pos, tmp);
    }

    static void insertion_sort(List<Integer> values) {
        // Durchlaufe die anderen Positionen
        for (int i = 1; i < values.size(); i++)
            move_to_insertion_pos(values, i);
    }


    static void main() {
        var values = new ArrayList<>(List.of(11, 2, 7, 15, 6, 3, 4, 5, 1, 8, 10, 9, 12, 14, 13));

        insertion_sort(values);
        IO.println(values);
    }
}
