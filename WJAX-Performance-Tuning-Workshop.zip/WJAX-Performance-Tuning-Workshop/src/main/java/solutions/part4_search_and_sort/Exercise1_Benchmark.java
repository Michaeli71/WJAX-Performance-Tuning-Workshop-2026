package solutions.part4_search_and_sort;


import util.DemoDataCreatorV1;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static solutions.part4_search_and_sort.Exercise1_CompareInsertionMergeSort.insertionSort;
import static solutions.part4_search_and_sort.Exercise1_CompareInsertionMergeSort.mergeSort;

public class Exercise1_Benchmark {

    static long measureNanos(Runnable task, int warmups, int repetitions) {
        for (int i = 0; i < warmups; i++)
            task.run(); // einfaches Warm-up

        long start = System.nanoTime();
        for (int i = 0; i < repetitions; i++)
            task.run();

        return (System.nanoTime() - start) / repetitions;
    }

    static long measureNanos(Runnable task) {
        long start = System.nanoTime();
        task.run();
        return System.nanoTime() - start;
    }


    private static volatile boolean result;

    static void main() {

        // zufällig gemischter Datenbestand
        IO.println("zufällig gemischter Datenbestand");
        for (int size : new int[] {10, 100, 1_000, 10_000, 100_000, 1_000_000}) {
            final int[] values = DemoDataCreatorV1.generateRandomlyPopulatedIntArray(size);
            final List<Integer> valuesAsList = Arrays.stream(values).boxed().toList();

            long insertionSortMicros = performMeasurement(values, () -> insertionSort(valuesAsList));
            long mergeSortMicros = performMeasurement(values, () -> mergeSort(valuesAsList));

            double speedup = mergeSortMicros > 0 ? (double) insertionSortMicros / mergeSortMicros : Double.NaN;

            System.out.printf("n=%d | InsertionSort: %d µs | MergeSort: %d µs | Speedup: %.2fx%n",
                              values.length, insertionSortMicros, mergeSortMicros, speedup);

        }

        // Insertion Sort best Case: nahezu bzw. vollständig geordnet
        IO.println("Nahezu bzw. vollständig geordnet");
        for (int size : new int[] {10, 100, 1_000, 10_000, 100_000, 1_000_000}) {
            final int[] values = DemoDataCreatorV1.generateAscSortedSizedIntArray(size);
            final List<Integer> valuesAsList = Arrays.stream(values).boxed().toList();

            long insertionSortMicros = performMeasurement(values, () -> insertionSort(valuesAsList));
            long mergeSortMicros = performMeasurement(values, () -> mergeSort(valuesAsList));

            double speedup = mergeSortMicros > 0 ? (double) insertionSortMicros / mergeSortMicros : Double.NaN;

            System.out.printf("n=%d | InsertionSort: %d µs | MergeSort: %d µs | Speedup: %.2fx%n",
                              values.length, insertionSortMicros, mergeSortMicros, speedup);
        }

    }

    private static long performMeasurement(int[] values, Runnable task) {
        long time = measureNanos(task);

        long timeMicros = TimeUnit.NANOSECONDS.toMicros(time);

        return timeMicros;
    }
}
