package solutions.part4_search_and_sort;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Exercise2_CombinedInsertionMergeSort {

    static void main() {

        List<Integer> values = Arrays.asList(3, 7, 5, 2, 1, 4, 6, 9, 8, 10, 12, 11, 14, 13, 17, 15, 19, 18, 16, 20);

        List<Integer> sortedValues = insertionSort(values);
        IO.println(sortedValues);

        List<Integer> sortedValues2 = mergeSort(values);
        IO.println(sortedValues2);

        List<Integer> sortedValues3 = combinedMergeInsertionSort(values);
        IO.println(sortedValues3);
    }

    static List<Integer> insertionSort(List<Integer> values) {

        List<Integer> result = new ArrayList<>();
        for (int current : values) {
            int i = 0;

            // Richtige Position suchen
            while (i < result.size() && result.get(i) <= current) {
                i++;
            }

            // Element an der richtigen Position einfügen
            result.add(i, current);
        }

        return result;
    }

    static void insertionSortInplace(List<Integer> values) {
        for (int i = 1; i < values.size(); i++) {
            int current = values.get(i);
            int j = i - 1;
            while (j >= 0 && values.get(j) > current) {
                values.set(j + 1, values.get(j));
                j--;
            }
            values.set(j + 1, current);
        }
    }

    static List<Integer> combinedMergeInsertionSort(List<Integer> values) {
        if (values.size() <= 15) {
            return insertionSort(values);
        }

        int mid = values.size() / 2;

        List<Integer> left = new ArrayList<>(values.subList(0, mid));
        List<Integer> right = new ArrayList<>(values.subList(mid, values.size()));

        left = mergeSort(left);
        right = mergeSort(right);

        List<Integer> result = merge(left, right);

        return result;
    }


    static List<Integer> mergeSort(List<Integer> values) {

        if (values.size() <= 1) {
            return values;
        }

        int mid = values.size() / 2;

        List<Integer> left = new ArrayList<>(values.subList(0, mid));
        List<Integer> right = new ArrayList<>(values.subList(mid, values.size()));

        left = mergeSort(left);
        right = mergeSort(right);

        List<Integer> result = merge(left, right);

        return result;
    }

    private static List<Integer> merge(List<Integer> left, List<Integer> right) {
        List<Integer> result = new ArrayList<>();

        int i = 0;
        int j = 0;

        while (i < left.size() && j < right.size()) {

            if (left.get(i) <= right.get(j)) {
                result.add(left.get(i));
                i++;
            } else {
                result.add(right.get(j));
                j++;
            }
        }

        while (i < left.size()) {
            result.add(left.get(i));
            i++;
        }

        while (j < right.size()) {
            result.add(right.get(j));
            j++;
        }
        return result;
    }
}
