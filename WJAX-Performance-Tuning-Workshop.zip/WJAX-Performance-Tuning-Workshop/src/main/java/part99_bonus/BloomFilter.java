package part99_bonus;

import java.util.Arrays;
import java.util.List;

public class BloomFilter {
    private final int size;
    private final int[] bits;
    private int addedCount;

    public BloomFilter() {
        this(1000);
    }

    public BloomFilter(int size) {
        if (size < 3 || size > 4096) {
            throw new IllegalArgumentException("Die Größe muss zwischen 3 und 4096 liegen.");
        }
        this.size = size;
        this.bits = new int[size];
    }

    public int getSize() {
        return size;
    }

    public int getAddedCount() {
        return addedCount;
    }

    public int[] getBits() {
        return Arrays.copyOf(bits, bits.length);
    }

    public int getSetBitCount() {
        int count = 0;
        for (int bit : bits) if (bit == 1) count++;
        return count;
    }

    public int hash1(String item) {
        long sum = 0;
        for (int i = 0; i < item.length(); i++) sum += item.charAt(i);
        return (int) (sum % size);
    }

    public int hash2(String item) {
        return item.length() % size;
    }

    public int hash3(String item) {
        return (item.isEmpty() ? 0 : item.charAt(0)) % size;
    }

    public List<Integer> hashes(String item) {
        return List.of(hash1(item), hash2(item), hash3(item));
    }

    public void add(String item) {
        for (int index : hashes(item)) bits[index] = 1;
        addedCount++;
    }

    /**
     * Returns true if the item may be present; false means definitely absent.
     */
    public boolean contains(String item) {
        for (int index : hashes(item)) {
            if (bits[index] == 0)
                return false;
        }
        return true;
    }

    public String visualize() {
        StringBuilder out = new StringBuilder(size);
        for (int bit : bits)
            out.append(bit);
        return out.toString();
    }

    public String visualize2() {
        StringBuilder out = new StringBuilder(size);
        for (int bit : bits)
            out.append(bit == 1 ? '#' : '.');
        return out.toString();
    }
}
