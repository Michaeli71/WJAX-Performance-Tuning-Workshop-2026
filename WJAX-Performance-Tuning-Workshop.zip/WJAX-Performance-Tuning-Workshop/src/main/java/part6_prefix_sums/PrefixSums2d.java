package part6_prefix_sums;

import java.util.Arrays;

public final class PrefixSums2d {

    public static int sum2dNaive(int[][] values, int x1, int y1,
                                 int x2, int y2) {
        int result = 0;

        for (int y = y1; y <= y2; y++) {
            for (int x = x1; x <= x2; x++) {
                result += values[y][x];
            }
        }

        return result;
    }

    public static int[][] prefixSum2dClever(int[][] values) {

        int rows = values.length;
        int cols = values[0].length;

        int[][] prefix = new int[rows + 1][cols + 1];

        for (int y = 1; y <= rows; y++) {
            for (int x = 1; x <= cols; x++) {

                prefix[y][x] =
                        values[y - 1][x - 1]
                                + prefix[y - 1][x]
                                + prefix[y][x - 1]
                                - prefix[y - 1][x - 1];
            }
        }

        return prefix;
    }

    public static int sum2dUsingPrefix(int[][] prefix,
                                       int x1, int y1,
                                       int x2, int y2) {

        return prefix[y2 + 1][x2 + 1]
                - prefix[y1][x2 + 1]
                - prefix[y2 + 1][x1]
                + prefix[y1][x1];
    }

    // Da diese intuitive Variante keine zusätzliche Null-Zeile und Null-Spalte verwendet, sieht die Abfrage etwas anders aus:
    public static int[][] prefixSum2d(int[][] values) {
        int height = values.length;
        int width = values[0].length;
        int[][] result = new int[height][width];

        for (int x = 0; x < width; x++) {
            result[0][x] = values[0][x];

            for (int y = 1; y < height; y++)
                result[y][x] = result[y - 1][x] + values[y][x];
        }

        for (int y = 0; y < height; y++) {
            for (int x = 1; x < width; x++)
                result[y][x] = result[y][x - 1] + result[y][x];
        }

        return result;
    }

    // Da diese intuitive Variante keine zusätzliche Null-Zeile und Null-Spalte verwendet, sieht die Abfrage etwas anders aus:
    public static int sum2dPrefix(int[][] prefix, int x1, int y1, int x2, int y2) {

        int result = prefix[y2][x2];

        if (x1 > 0) {
            result -= prefix[y2][x1 - 1];
        }

        if (y1 > 0) {
            result -= prefix[y1 - 1][x2];
        }

        if (x1 > 0 && y1 > 0) {
            result += prefix[y1 - 1][x1 - 1];
        }

        return result;
    }

    static void main() {
        int[][] values = {
                {0, 0, 2, 1, 2},
                {0, 1, 3, 5, 6},
                {1, 4, 2, 7, 0},
                {2, 5, 4, 0, 2},
                {0, 1, 0, 1, 1}
        };

        record Region(int startX, int startY, int endX, int endY) {
        }

        for (Region region : new Region[] {new Region(1, 1, 3, 3),
                                           new Region(0, 0, 1, 4),
                                           new Region(3, 1, 4, 3)}) {
            System.out.println(sum2dNaive(values, region.startX, region.startY, region.endX, region.endY));

            int[][] prefix = prefixSum2dClever(values);
            IO.println(Arrays.deepToString(prefix));
            System.out.println(sum2dUsingPrefix(prefix, region.startX, region.startY, region.endX, region.endY));

            int[][] prefix2 = prefixSum2d(values);
            IO.println(Arrays.deepToString(prefix2));
            System.out.println(sum2dPrefix(prefix2, region.startX, region.startY, region.endX, region.endY));
        }
    }
}

