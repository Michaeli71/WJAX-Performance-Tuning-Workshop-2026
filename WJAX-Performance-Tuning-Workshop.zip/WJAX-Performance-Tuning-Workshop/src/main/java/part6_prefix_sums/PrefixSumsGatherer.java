package part6_prefix_sums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Gatherers;

public class PrefixSumsGatherer {
    public static long[] prefixSums(int[] values) {
        return Arrays.stream(values)
                     .asLongStream()
                     .boxed()
                     .gather(Gatherers.scan(() -> 0L, Long::sum))
                     .mapToLong(Long::longValue)
                     .toArray();
    }

    public static List<Integer> prefixSums(List<Integer> values) {
        return values.stream()
                     .gather(Gatherers.scan(() -> 0, Integer::sum))
                     .toList();
    }

    static List<Integer> prefixSum(List<Integer> values) {
        List<Integer> result = new ArrayList<>();

        int sum = 0;
        for (int i = 0; i < values.size(); i++) {
            sum += values.get(i);
            result.add(sum);
        }

        return result;
    }

    static void main() {
        IO.println(Arrays.toString(prefixSums(new int[] {3, -2, 5, 1, 4})));
        // [3, 1, 6, 7, 11]

        IO.println(prefixSums(List.of(3, -2, 5, 1, 4)));
    }
}
