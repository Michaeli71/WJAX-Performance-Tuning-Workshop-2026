package part6_prefix_sums;

import java.util.List;

public class SumInRangeNaive {

    static long sumInRange(List<Integer> values, int start, int end_inclusive) {

        long total = 0;
        for (int i = start; i <= end_inclusive; i++) {
            total += values.get(i);
        }

        return total;
    }

    static void main() {
        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9);

        IO.println(sumInRange(values, 0, 2));
        IO.println(sumInRange(values, 2, 4));
    }
}
