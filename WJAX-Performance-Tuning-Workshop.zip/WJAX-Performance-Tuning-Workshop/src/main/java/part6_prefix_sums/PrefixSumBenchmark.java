package part6_prefix_sums;

import java.util.*;
import java.util.stream.Gatherers;

public class PrefixSumBenchmark {

    public static List<Integer> prefixSums(List<Integer> values) {
        return values.stream()
                .gather(Gatherers.scan(() -> 0, Integer::sum))
                .toList();
    }

    public static List<Integer> prefixSum(List<Integer> values) {
        List<Integer> result = new ArrayList<>(values.size());

        int sum = 0;
        for (int i = 0; i < values.size(); i++) {
            sum += values.get(i);
            result.add(sum);
        }

        return result;
    }

    private static long benchmark(
            String name,
            List<Integer> values,
            int iterations,
            boolean stream
    ) {
        // Warmup
        for (int i = 0; i < 3; i++) {
            if (stream) {
                prefixSums(values);
            } else {
                prefixSum(values);
            }
        }

        long start = System.nanoTime();

        for (int i = 0; i < iterations; i++) {
            if (stream) {
                prefixSums(values);
            } else {
                prefixSum(values);
            }
        }

        long elapsed = System.nanoTime() - start;
        long average = elapsed / iterations;

        System.out.printf(
                "%-20s %10.3f ms%n",
                name,
                average / 1_000_000.0
        );

        return average;
    }

    public static void main(String[] args) {
        int[] sizes = {
                100_000,
                1_000_000,
                10_000_000
        };

        Random random = new Random(42);

        for (int size : sizes) {
            List<Integer> values = new ArrayList<>(size);

            for (int i = 0; i < size; i++) {
                values.add(random.nextInt(10));
            }

            int iterations = size >= 10_000_000 ? 2
                           : size >= 1_000_000 ? 5
                           : 10;

            System.out.printf("%n--- %s Elemente ---%n", size);

            long streamTime = benchmark(
                    "Stream + Gatherer", values, iterations, true
            );

            long loopTime = benchmark(
                    "For-Schleife", values, iterations, false
            );

            System.out.printf(
                    "For-Schleife ist %.2fx schneller%n",
                    (double) streamTime / loopTime
            );
        }
    }
}
