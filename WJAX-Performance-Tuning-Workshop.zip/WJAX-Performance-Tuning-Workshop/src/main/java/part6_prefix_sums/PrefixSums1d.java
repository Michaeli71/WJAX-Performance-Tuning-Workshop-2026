package part6_prefix_sums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

// Variante startet mit 0 vorne
public final class PrefixSums1d {
    private PrefixSums1d() {
    }

    // prefix[i] = Summe der ersten i Elemente.
    public static int[] prefixSums(int[] values) {
        Objects.requireNonNull(values);
        int[] prefix = new int[values.length + 1];
        for (int i = 0; i < values.length; i++) {
            prefix[i + 1] = prefix[i] + values[i];
        }
        return prefix;
    }

    // Summe im halboffenen Bereich [fromInclusive, toExclusive).
    public static long rangeSum(int[] prefix, int fromInclusive, int toExclusive) {
        if (fromInclusive < 0 || toExclusive < fromInclusive || toExclusive >= prefix.length) {
            throw new IndexOutOfBoundsException();
        }
        return prefix[toExclusive] - prefix[fromInclusive];
    }

    static List<Integer> prefixSum(List<Integer> values) {
        List<Integer> result = new ArrayList<>();
        int sum = 0;
        for (int i = 0; i < values.size(); i++) {
            sum += values.get(i);
            result.add(sum);
        }
        return result;
    }

    public static long sumInRangeInclusive(List<Integer> prefixSums,
                                           int start, int endInclusive)
    {
        if (start == 0)
            return prefixSums.get(endInclusive);

        return prefixSums.get(endInclusive) - prefixSums.get(start - 1);
    }

    static void main() {
        int[] values = {3, -2, 5, 1, 4};
        int[] expected = {0, 3, 1, 6, 7, 11};

        int[] result = prefixSums(values);
        IO.println(Arrays.toString(result));


        List<Integer> values2 = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Integer> prefixSums = prefixSum(values2);
        IO.println(prefixSums);

        IO.println(sumInRangeInclusive(prefixSums, 0, 2));
        IO.println(sumInRangeInclusive(prefixSums, 2, 4));
    }
}
