package part6_prefix_sums;

import java.util.ArrayList;
import java.util.List;

public class PrefixMultExample {
    static void main() {
        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        IO.println(prefixMult(values));
    }

    static List<Integer> prefixMult(List<Integer> values) {
        List<Integer> result = new ArrayList<>();

        int sum = 0;
        for (int i = 0; i < values.size(); i++) {
            sum += values.get(i);
            result.add(sum);
        }

        return result;
    }
}
