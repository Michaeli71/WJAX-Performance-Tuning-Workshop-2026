
package part11_fireworks;

import java.util.HashMap;
import java.util.Map;

public class Firework5_Fibonacci {

    private static volatile long sink;

    static void main() {
        int n = 45;
        int warmup = 3;
        int repetitions = 5;

        // Warm-up
        for (int i = 0; i < warmup; i++) {
            sink = fib(n);
            sink = fibMemo(n);
            sink = fibFormula(n);
        }

        // Naive Rekursion
        long start = System.nanoTime();
        for (int i = 0; i < repetitions; i++) {
            sink = fib(n);
        }
        long naiveTime = System.nanoTime() - start;

        // Memoization
        start = System.nanoTime();
        for (int i = 0; i < repetitions; i++) {
            sink = fibMemo(n);
        }
        long memoTime = System.nanoTime() - start;

        // Binet-Formel
        start = System.nanoTime();
        for (int i = 0; i < repetitions; i++) {
            sink = fibFormula(n);
        }
        long formulaTime = System.nanoTime() - start;

        printResult("Naiv", naiveTime, repetitions);
        printResult("Memoization", memoTime, repetitions);
        printResult("Binet-Formel", formulaTime, repetitions);

        System.out.printf("Memo-Speed-up: %.2fx%n",
                          (double) naiveTime / memoTime);

        System.out.printf("Formel-Speed-up: %.2fx%n",
                          (double) naiveTime / formulaTime);

        System.out.println("Fibonacci(" + n + ") = " + fibMemo(n));
    }

    static long fib(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("n muss >= 0 sein");
        }
        if (n <= 1) {
            return n;
        }
        return fib(n - 1) + fib(n - 2);
    }

    static long fibMemo(int n, Map<Integer, Long> cache) {
        if (n < 0) {
            throw new IllegalArgumentException("n muss >= 0 sein");
        }
        if (n <= 1) {
            return n;
        }

        if (cache.containsKey(n)) {
            return cache.get(n);
        }

        long result =
                fibMemo(n - 1, cache) + fibMemo(n - 2, cache);

        cache.put(n, result);
        return result;
    }

    static long fibMemo(int n) {
        return fibMemo(n, new HashMap<>());
    }

    // Geschlossene Formel (Binet)
    static long fibFormula(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("n muss >= 0 sein");
        }

        double phi = (1 + Math.sqrt(5)) / 2;
        double psi = (1 - Math.sqrt(5)) / 2;

        return Math.round((Math.pow(phi, n) - Math.pow(psi, n)) / Math.sqrt(5)
        );
    }

    private static void printResult(
            String name, long timeInNs, int repetitions) {

        double timeInMs = timeInNs / 1_000_000.0;
        System.out.printf("%-14s Gesamt: %10.3f ms | Ø: %9.3f ms%n",
                          name, timeInMs, timeInMs / repetitions
        );
    }
}
