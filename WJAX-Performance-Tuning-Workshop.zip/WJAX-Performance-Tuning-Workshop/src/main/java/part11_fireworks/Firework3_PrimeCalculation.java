package part11_fireworks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/// | Variante              | Zeitkomplexität                    | Einschätzung                     |
/// |-----------------------|------------------------------------|----------------------------------|
/// | Naiv                  | O(n^2) als obere Schranke      | Langsam                          |
/// | Optimiert V1          | O(n^2) als obere Schranke      | Etwas schneller                  |
/// | Optimiert V2          | O(n \sqrt{n}) als obere Schranke | Deutlich schneller              |
/// | Sieb des Eratosthenes | O(n log log n)                | Für große \(n\) meist am schnellsten |
public class Firework3_PrimeCalculation {

    private static volatile List<Integer> sink;

    public static void main(String[] args) {
        int n = 100_000;
        int warmup = 100;
        int repetitions = 5;

        System.out.println("Primzahl-Benchmark bis " + n);
        System.out.println("--------------------------------");

        // Warm-up
        for (int i = 0; i < warmup; i++) {
            sink = naiveCalcPrimes(n);
            sink = optimizedCalcPrimesV1(n);
            sink = optimizedCalcPrimesV2(n);
            sink = sieveOfEratosthenes(n);
        }

        // Benchmark 1: Naive Variante
        long start = System.nanoTime();
        for (int i = 0; i < repetitions; i++) {
            sink = naiveCalcPrimes(n);
        }
        long naiveTime = System.nanoTime() - start;

        // Benchmark 2: Optimierung V1
        start = System.nanoTime();
        for (int i = 0; i < repetitions; i++) {
            sink = optimizedCalcPrimesV1(n);
        }
        long v1Time = System.nanoTime() - start;

        // Benchmark 3: Optimierung V2
        start = System.nanoTime();
        for (int i = 0; i < repetitions; i++) {
            sink = optimizedCalcPrimesV2(n);
        }
        long v2Time = System.nanoTime() - start;

        // Benchmark 4: Sieb des Eratosthenes
        start = System.nanoTime();
        for (int i = 0; i < repetitions; i++) {
            sink = sieveOfEratosthenes(n);
        }
        long sieveTime = System.nanoTime() - start;

        System.out.println("Anzahl Durchläufe: " + repetitions);
        System.out.println();

        printResult("Naiv", naiveTime, repetitions);
        printResult("Optimiert V1", v1Time, repetitions);
        printResult("Optimiert V2", v2Time, repetitions);
        printResult("Sieb des Eratosthenes", sieveTime, repetitions);

        System.out.println();
        System.out.println("Gefundene Primzahlen: "
                                   + sieveOfEratosthenes(n).size());
    }

    private static void printResult(
            String name, long time, int repetitions) {

        double totalMs = time / 1_000_000.0;
        double averageMs = totalMs / repetitions;

        System.out.printf(
                "%-24s Gesamt: %9.3f ms | Ø: %8.3f ms%n",
                name, totalMs, averageMs);
    }

    // Ursprüngliche Primzahlprüfung
    static boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }

        for (int d = 2; d < n; d++) {
            if (n % d == 0) {
                return false;
            }
        }
        return true;
    }

    static List<Integer> naiveCalcPrimes(int n) {
        List<Integer> primes = new ArrayList<>();

        for (int i = 2; i <= n; i++) {
            if (isPrime(i)) {
                primes.add(i);
            }
        }
        return primes;
    }

    // Optimierung V1: nur bis n / 2 prüfen
    static boolean isPrimeOptimizedV1(int n) {
        if (n < 2) {
            return false;
        }

        for (int d = 2; d <= n / 2; d++) {
            if (n % d == 0) {
                return false;
            }
        }
        return true;
    }

    static List<Integer> optimizedCalcPrimesV1(int n) {
        List<Integer> primes = new ArrayList<>();

        for (int i = 2; i <= n; i++) {
            if (isPrimeOptimizedV1(i)) {
                primes.add(i);
            }
        }
        return primes;
    }

    // Optimierung V2: nur bis zur Quadratwurzel prüfen
    static boolean isPrimeOptimizedV2(int n) {
        if (n < 2) {
            return false;
        }

        for (int d = 2; d * d <= n; d++) {
            if (n % d == 0) {
                return false;
            }
        }
        return true;
    }

    static List<Integer> optimizedCalcPrimesV2(int n) {
        List<Integer> primes = new ArrayList<>();

        for (int i = 2; i <= n; i++) {
            if (isPrimeOptimizedV2(i)) {
                primes.add(i);
            }
        }
        return primes;
    }

    // Sieb des Eratosthenes
    static List<Integer> sieveOfEratosthenes(int n) {
        if (n < 2) {
            return new ArrayList<>();
        }

        boolean[] isPrime = new boolean[n + 1];
        Arrays.fill(isPrime, true);

        isPrime[0] = false;
        isPrime[1] = false;

        for (int p = 2; p * p <= n; p++) {
            if (isPrime[p]) {
                for (int multiple = p * p;
                     multiple <= n;
                     multiple += p) {
                    isPrime[multiple] = false;
                }
            }
        }

        List<Integer> primes = new ArrayList<>();

        for (int i = 2; i <= n; i++) {
            if (isPrime[i]) {
                primes.add(i);
            }
        }
        return primes;
    }
}
