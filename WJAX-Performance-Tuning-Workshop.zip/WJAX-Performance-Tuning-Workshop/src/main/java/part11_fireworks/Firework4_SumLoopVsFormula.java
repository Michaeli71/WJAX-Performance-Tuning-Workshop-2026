
package part11_fireworks;

/// | Variante          | Zeitkomplexität | Beschreibung                       |
/// |-------------------|-----------------|------------------------------------|
/// | Schleife          | O(n)        | Addiert jede Zahl einzeln          |
/// | Gaußsche Formel   | O(1)        | Berechnet die Summe direkt         |
public class Firework4_SumLoopVsFormula {

    private static volatile long sink;

    static void main() {
        int n = 1_000_000;
        int warmup = 10_000;
        int repetitions = 1_000;

        // Warm-up
        for (int i = 0; i < warmup; i++) {
            sink = sumWithLoop(n);
            sink = sumWithFormula(n);
        }

        // Benchmark: Schleife
        long start = System.nanoTime();

        for (int i = 0; i < repetitions; i++) {
            sink = sumWithLoop(n);
        }

        long loopTime = System.nanoTime() - start;

        // Benchmark: Formel
        start = System.nanoTime();

        for (int i = 0; i < repetitions; i++) {
            sink = sumWithFormula(n);
        }

        long formulaTime = System.nanoTime() - start;

        printResult("Schleife O(n)", loopTime, repetitions);
        printResult("Formel O(1)", formulaTime, repetitions);

        System.out.printf(
                "Speed-up: %.2fx%n",
                (double) loopTime / formulaTime
        );

        System.out.println("Ergebnis: " + sumWithFormula(n));
    }

    static long sumWithLoop(int n) {
        long sum = 0;

        for (int i = 0; i < n; i++) {
            sum += i;
        }

        return sum;
    }

    static long sumWithFormula(int n) {
        return (long) n * (n - 1) / 2;
    }

    private static void printResult(
            String name, long time, int repetitions) {

        System.out.printf(
                "%-16s Gesamt: %9.3f ms | Ø: %10.6f ms%n",
                name,
                time / 1_000_000.0,
                time / 1_000_000.0 / repetitions
        );
    }
}
