package part11_fireworks;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Benchmarking besser mit JMH oder ähnlichen Tools
public class Firework1_StringCopying {

    private static volatile String sink;

    public static void main(String[] args) {
        String[] data = createDate();

        int warmup = 10_000;
        int repetitions = 1_000;

        // Warm-up für die JVM
        for (int i = 0; i < warmup; i++) {
            sink = concatenate(data);
            sink = buildWithStringBuilder(data);
        }

        // Benchmark: String +
        long start1 = System.nanoTime();

        for (int i = 0; i < repetitions; i++) {
            sink = concatenate(data);
        }

        long time1 = System.nanoTime() - start1;

        // Benchmark: StringBuilder
        long start2 = System.nanoTime();

        for (int i = 0; i < repetitions; i++) {
            sink = buildWithStringBuilder(data);
        }

        long time2 = System.nanoTime() - start2;

        System.out.printf("String +:      %.2f ms%n",
                          time1 / 1_000_000.0);
        System.out.printf("StringBuilder: %.2f ms%n",
                          time2 / 1_000_000.0);

        System.out.printf("Verhältnis:    %.2fx%n",
                          (double) time1 / time2);
    }

    private static String[] createDate() {

        String[] data = {
                "Tim", "Tom", "Caro", "Kira", "Lina", "Sophie", "Michael", "Klaus", "Barabara", "Yannis"
        };

        List<String> list = new ArrayList<>();
        for (int i = 0; i < 100; i++)
            list.addAll(Arrays.asList(data));

        return list.toArray(new String[0]);
    }

    private static String concatenate(String[] data) {
        String result = "";

        for (String item : data) {
            result = result + transform(item);
        }

        return result;
    }

    private static String buildWithStringBuilder(String[] data) {
        StringBuilder result = new StringBuilder();

        for (String item : data) {
            result.append(transform(item));
        }

        return result.toString();
    }

    private static String transform(String item) {
        return item.toUpperCase();
    }
}
