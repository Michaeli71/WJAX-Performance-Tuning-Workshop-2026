
package part11_fireworks;

import java.util.ArrayList;
import java.util.List;

public class Firework2_Linear_Binary_Search {

    private static volatile int sink;

    static void main() {
        int size = 1_000_000;
        int warmup = 20;
        int repetitions = 100;

        List<Long> values = initValues(size);

        long target = size - 1L;

        // Warm-up
        for (int i = 0; i < warmup; i++) {
            sink = linearSearch(values, target);
            sink = binarySearchIter(values, target);
        }

        // Benchmark: Lineare Suche
        long start = System.nanoTime();

        for (int i = 0; i < repetitions; i++) {
            sink = linearSearch(values, target);
        }

        long linearTime = System.nanoTime() - start;

        // Benchmark: Binäre Suche
        start = System.nanoTime();

        for (int i = 0; i < repetitions; i++) {
            sink = binarySearchIter(values, target);
        }

        long binaryTime = System.nanoTime() - start;

        printResult("Lineare Suche", linearTime, repetitions);
        printResult("Binäre Suche", binaryTime, repetitions);

        System.out.printf(
                "Speed-up: %.2fx%n",
                (double) linearTime / binaryTime
        );
    }

    private static List<Long> initValues(int size) {
        List<Long> values = new ArrayList<>(size);

        for (long i = 0; i < size; i++) {
            values.add(i);
        }
        return values;
    }

    static int linearSearch(List<Long> values, long target) {
        for (int i = 0; i < values.size(); i++) {
            if (values.get(i) == target) {
                return i;
            }
        }

        return -1;
    }

    static int binarySearchIter(List<Long> values, long target) {
        int left = 0;
        int right = values.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            long value = values.get(mid);

            if (value == target) {
                return mid;
            } else if (value < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1;
    }

    private static void printResult(
            String name, long time, int repetitions) {

        System.out.printf(
                "%-18s Gesamt: %9.3f ms | Ø: %8.4f ms%n",
                name,
                time / 1_000_000.0,
                time / 1_000_000.0 / repetitions
        );
    }
}
