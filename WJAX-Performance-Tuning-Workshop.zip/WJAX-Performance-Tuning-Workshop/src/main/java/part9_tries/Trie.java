package part9_tries;

import java.util.List;

public class Trie {
    private final TrieNode root = new TrieNode(null);

    public void insert(String word) {
        TrieNode current = root;
        for (char ch : word.toCharArray()) {
            current.createChildIfAbsent(ch);
            current = current.childFor(ch);
        }
        current.word = word;
    }

    private boolean containsCharSequence(String prefix) {
        return findNodeForCharSequence(prefix) != null;
    }

    public boolean contains(String word) {
        TrieNode current = findNodeForCharSequence(word);
        if (current == null)
            return false;

        return current.isWord();
    }

    private TrieNode findNodeForCharSequence(String prefix) {
        TrieNode current = root;

        for (char ch : prefix.toCharArray()) {
            current = current.childFor(ch);
            if  (current == null)
                return null;
        }

        return current;
    }


    public void printTrie() {
        root.printNode(0);
    }

    public List<String> complete(String prefix)
    {
        TrieNode current = findNodeForCharSequence(prefix);
        if (current == null)
            return List.of();

        return current.complete();
    }


    public static void main(String[] args) {

        List<String> words = List.of(
                "bear", "bears", "ball", "balls", "ballon", "buy", "buyer",
                "cat", "cats", "catering", "dog", "dogs", "dodge", "dogmatic",
                "hall", "halo", "hell", "hellfire", "hello", "help", "helping",
                "india", "indian", "italy", "italian", "incremental", "incredible",
                "stop", "stopping", "stopped", "stopwatch", "steer", "steering");

        var trie = new Trie();
        for (String word : words) {
            trie.insert(word);
        }
        trie.printTrie();

        // ...

        IO.println(trie.complete("bear"));
        IO.println(trie.complete("bea"));
        IO.println(trie.complete("do"));
        IO.println(trie.complete("ind"));
        IO.println(trie.complete("sto"));
    }
}


