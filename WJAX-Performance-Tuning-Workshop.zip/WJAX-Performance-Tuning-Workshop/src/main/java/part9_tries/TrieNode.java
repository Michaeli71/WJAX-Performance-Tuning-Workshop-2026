package part9_tries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrieNode {
    final Map<Character, TrieNode> children = new HashMap<>();
    final Character ch;
    String word = null;

    public TrieNode(Character ch) {
        this.ch = ch;
    }

    @Override
    public String toString() {
        return ch + (isWord() ?  " => " + word : "");
    }

    public boolean isWord() {
        return word != null;
    }

    public void createChildIfAbsent(char ch) {
        children.putIfAbsent(ch, new TrieNode(ch));
    }

    public TrieNode childFor(Character ch)
    {
        return children.get(ch);
    }

    // ...
    public void printNode(int indent) {
        if (ch != null) {
            IO.println(this);
        }

        // process children recursively
        for (var value : children.values()) {
            IO.print("   ".repeat(indent));
            IO.print("\\--");
            value.printNode(indent + 1);
        }
    }

    public List<String> complete() {
        List<String> result = new ArrayList<>();

        if (isWord())
            result.add(word);

        for (var child : children.values()) {
            result.addAll(child.complete());
        }

        return result;
    }
}





