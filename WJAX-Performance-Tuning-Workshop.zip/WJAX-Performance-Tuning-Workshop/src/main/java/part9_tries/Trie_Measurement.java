package part9_tries;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Trie_Measurement {

    static void main() {
        List<String> words = readWordsFromFiles();

        Trie trie = new Trie();
        for (String word : words) {
            trie.insert(word);
        }

        boolean warmUp = true;
        if (warmUp) {
            // warm up
            IO.println("warm up");
            for (int i = 0; i < 20_000; i++) {
                trie.complete("c");
                trie.complete("co");
            }
        }

        // simuliere eine Eingabe
        IO.println("Start Simulation Inputs");
        measureBruteForceSearchSequence(trie);
    }

    public static List<String> measureSingleSearch(Trie trie, String searchTerm) {
        long start = System.nanoTime();
        List<String> result = trie.complete(searchTerm);
        long end = System.nanoTime();
        long duration = TimeUnit.NANOSECONDS.toMicros(end - start);
        IO.println("single search('" + searchTerm + "') took " + duration + " µs");
        return result;
    }

    public static void measureBruteForceSearchSequence(Trie trie) {
        List<String> searchTerms = List.of("a", "b", "be", "bea", "beac", "beach",
                "beachm", "beachma", "h", "ha", "t", "ti", "tim", "timber",
                "z", "zo", "zoo");

        List<String> result =  new ArrayList<>();
        long start = System.currentTimeMillis();

        for (String prefix : searchTerms) {
            result = measureSingleSearch(trie, prefix);
        }

        long end = System.currentTimeMillis();
        IO.println("result=" + result);
        long duration = end - start;
        IO.println("measureBruteForceSearchSequence() took " + duration + " ms");
    }


    private static List<String> readWordsFromFiles() {
        List<String> words = readWords("words_alpha.txt");
        IO.println("#words: " + words.size());

        List<String> words2 = readWords("wortliste.txt");
        IO.println("#words2: " + words2.size());

        List<String> result = new ArrayList<>(words);
        result.addAll(words2);
        return result;
    }

    private static List<String> readWords(String filename) {
        try {
            return WordImport.readWords(filename);
        } catch (IOException e) {
            e.printStackTrace();
            return List.of();
        }
    }
}


