package part9_tries;

import java.util.List;

public class SimpleHomeBrewnSearchByPrefix {
    public static void main(String[] args) {
        List<String> words = List.of(
                "bear", "bears", "ball", "balls", "ballon", "buy", "buyer",
                "cat", "cats", "catering", "dog", "dogs", "dodge", "dogmatic",
                "hall", "halo", "hell", "hellfire", "hello", "help", "helping",
                "india", "indian", "italy", "italian", "incremental", "incredible",
                "stop", "stopping", "stopped", "stopwatch", "steer", "steering");

        IO.println(searchByPrefix("bear", words));
        IO.println(searchByPrefix("bea", words));
        IO.println(searchByPrefix("do", words));
        IO.println(searchByPrefix("ind", words));
        IO.println(searchByPrefix("sto", words));

    }

    static List<String> searchByPrefix(String prefix, List<String> words) {
        return words.stream().
                     filter(word -> word.startsWith(prefix)).
                     toList();
    }
}