package part9_tries;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class SimpleHomeBrewnSearchByPrefix_Measurement {
    public static void main(String[] args) {
        List<String> words = readWordsFromFiles();
        IO.println("word count: " + words.size());

        // warm up
        boolean warmUp = true;
        if (warmUp)
        {
            IO.println("warm up");
            List<String> result1 = new ArrayList<>();
            List<String> result2 = new ArrayList<>();
            for (int i = 0; i < 20_000; i++) {
                result1 = searchByPrefix("c", words);
                result2 = searchByPrefix("co", words);
            }
            IO.println(result1);
            IO.println(result2);
        }
        // simuliere eine Eingabe
        measureBruteForceSearchSequence(words);
    }

    public static List<String> measureSingleSearch(String searchTerm, List<String> words) {
        long start = System.nanoTime();
        List<String> result = searchByPrefix(searchTerm, words);

        long end = System.nanoTime();
        long duration = TimeUnit.NANOSECONDS.toMicros(end - start);
        IO.println("single search('" + searchTerm + "') took " + duration + " µs");
        IO.println("count: " + result.size());
        return result;
    }

    public static void measureBruteForceSearchSequence(List<String> words) {
        List<String> searchTerms = List.of("a", "b", "be", "bea", "beac", "beach",
                "beachm", "beachma", "h", "ha", "t", "ti", "tim", "timber",
                "z", "zo", "zoo");
        long start = System.currentTimeMillis();

        for (String prefix : searchTerms) {
            List<String> result = measureSingleSearch(prefix, words);
        }

        long end = System.currentTimeMillis();
        long duration = end - start;
        IO.println("measureBruteForceSearchSequence() took " + duration + " ms");
    }


    private static List<String> readWordsFromFiles() {
        List<String> words = readWords("words_alpha.txt");
        IO.println("#words: " + words.size());

        List<String> words2 = readWords("wortliste.txt");
        IO.println("#words2: " + words2.size());

        List<String> result = new ArrayList<>(words);
        result.addAll(words2);
        return result;
    }

    private static List<String> readWords(String filename) {
        try {
            return WordImport.readWords(filename);
        } catch (IOException e) {
            e.printStackTrace();
            return List.of();
        }
    }


    static List<String> searchByPrefix(String prefix, List<String> words) {
        List<String> result = new ArrayList<>();
        for (String word : words) {
            if (word.startsWith(prefix))
                result.add(word);
        }
        return result;
        /*
        return words.stream().
                filter(word -> word.startsWith(prefix)).
                toList();
         */
    }
}