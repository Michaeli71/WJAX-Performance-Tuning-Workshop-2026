package part9_tries;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class WordImport {

    static List<String> readWords(String filename) throws IOException {
        List<String> result = new ArrayList<>();
        Path path = Paths.get("src/main/resources", filename);
        try (Stream<String> stream = Files.lines(path)) {
            stream.forEach(word -> result.add(word));
        }
        return result;
    }
}
