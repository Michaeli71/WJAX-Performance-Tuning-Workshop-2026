package part2_big_o;

public class FindValue {

    static boolean findValue(int[] values, int target) {

        for (int value : values) {
            if (value == target) {
                return true;
            }
        }

        return false;
    }

    static void main() {

        int[] values = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

        int target1 = 30;
        int target2 = 99;

        IO.println(target1 + " gefunden: " + findValue(values, target1));
        IO.println(target2 + " gefunden: " + findValue(values, target2));
    }
}
