package part2_big_o;


import java.util.HashSet;
import java.util.Set;

public class BigO_MotivationMeasurement {

    // Variante A: Verschachtelte Schleifen – O(n²)
    static boolean hasDuplicatesNaive(int[] values) {
        for (int i = 0; i < values.length; i++) {
            for (int j = i + 1; j < values.length; j++) {
                if (values[i] == values[j]) {
                    return true;
                }
            }
        }
        return false;
    }

    // Variante B: HashSet – durchschnittlich O(n)
    static boolean hasDuplicatesHashSet(int[] values) {
        Set<Integer> seen = new HashSet<>();

        for (int value : values) {
            if (!seen.add(value)) {
                return true;
            }
        }
        return false;
    }

    static long measureNanos(Runnable task) {
        long start = System.nanoTime();
        task.run();
        return System.nanoTime() - start;
    }

    public static void main(String[] args) {
        int[] sizes = {1_000, 5_000, 10_000, 50_000, 100_000, 500_000, 1_000_000};

        for (int size : sizes) {
            // Zufällige Werte mit hoher Wahrscheinlichkeit ohne Duplikate.
            // Für den Benchmark garantieren wir: keine Duplikate.
            int[] values = new int[size];
            for (int i = 0; i < size; i++) {
                values[i] = i;
            }

            // Gleiche Aufgabe, gleiche Daten.
            long naiveTime = measureNanos(() -> hasDuplicatesNaive(values));
            long hashSetTime = measureNanos(() -> hasDuplicatesHashSet(values));

            double naiveMs = naiveTime / 1_000_000.0;
            double hashSetMs = hashSetTime / 1_000_000.0;
            double speedup = (double) naiveTime / hashSetTime;

            System.out.printf("n=%8d | Naiv: %10.3f ms | HashSet: %10.3f ms | Speedup: %8.2fx%n",
                              size, naiveMs, hashSetMs, speedup);
        }
    }
}
