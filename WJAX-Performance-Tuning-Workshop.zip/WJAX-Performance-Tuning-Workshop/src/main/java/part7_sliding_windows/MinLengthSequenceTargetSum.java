
package part7_sliding_windows;

import java.util.ArrayList;
import java.util.List;

public class MinLengthSequenceTargetSum {

    public record Result(
            List<Integer> sequence,
            int start,
            int end,
            int length
    ) {
        public Result {
            sequence = List.copyOf(sequence);
        }
    }

    // Brute Force: O(n²)
    public static Result minLengthSequenceSumBruteForce(
            int[] values, long target) {

        validateInputs(values, target);

        Result result = new Result(List.of(), -1, -1, Integer.MAX_VALUE);

        for (int start = 0; start < values.length; start++) {
            long sum = 0;

            for (int end = start; end < values.length; end++) {
                sum += values[end];

                if (sum >= target) {
                    int length = end - start + 1;

                    if (length < result.length()) {
                        result = createResult(values, start, end);
                    }

                    break; // Für diesen Start wird das Teilarray nicht kürzer.
                }
            }
        }

        return result;
    }

    // Sliding Window: O(n)
    public static Result minLengthSequenceSum(
            int[] values, long target) {

        validateInputs(values, target);

        int left = 0;
        long sum = 0;

        Result result = new Result(List.of(), -1, -1, Integer.MAX_VALUE);

        for (int right = 0; right < values.length; right++) {
            sum += values[right];

            while (sum >= target) {

                int length = right - left + 1;

                if (length < result.length()) {
                    result = createResult(values, left, right);
                }

                sum -= values[left++];
            }
        }

        return result;
    }

    // Erstellt das Ergebnis aus einem gefundenen Bereich
    private static Result createResult(
            int[] values, int start, int end) {

        List<Integer> sequence = new ArrayList<>();

        for (int i = start; i <= end; i++) {
            sequence.add(values[i]);
        }

        return new Result(sequence, start, end, values.length);
    }

    // Eingaben validieren
    private static void validateInputs(int[] values, long target) {

        if (values == null) {
            throw new IllegalArgumentException(
                    "values must not be null");
        }

        if (target <= 0) {
            throw new IllegalArgumentException(
                    "target must be positive");
        }

        for (int value : values) {
            if (value < 0) {
                throw new IllegalArgumentException(
                        "values must be non-negative");
            }
        }
    }

    public static void main(String[] args) {

        int[] values = {2, 1, 3, 2, 4, 1, 1, 5};
        int target = 7;

        Result bruteForce = minLengthSequenceSumBruteForce(values, target);

        Result slidingWindow = minLengthSequenceSum(values, target);

        System.out.println("Brute Force:");
        System.out.println(bruteForce);

        System.out.println();

        System.out.println("Sliding Window:");
        System.out.println(slidingWindow);

    }
}
