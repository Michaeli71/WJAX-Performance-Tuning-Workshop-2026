
package part7_sliding_windows;

import java.util.Random;

import static part7_sliding_windows.MinLengthSequenceTargetSum.*;

public class MinLengthSequenceTargetSumBenchmark {

    private static volatile int checksum;

    public static void main(String[] args) {

        int[] sizes = {
                1_000,
                10_000,
                100_000,
                1_000_000,
                10_000_000,
        };

        int[] targets = {
                10,
                100,
                1_000,
                10_000
        };

        System.out.printf(
                "%-12s %-12s %-18s %-20s %-12s%n",
                "Grösse",
                "Zielwert",
                "Brute Force (ms)",
                "Sliding Window (ms)",
                "Speedup"
        );

        System.out.println("-".repeat(70));

        for (int n : sizes) {

            int[] values = generateValues(n);

            for (int target : targets) {

                benchmark(values, target);
            }

            System.out.println();
        }
    }

    private static void benchmark(int[] values, int target) {

        // Ergebnisse vergleichen
        Result bruteResult =
                minLengthSequenceSumBruteForce(values, target);

        Result slidingResult =
                minLengthSequenceSum(values, target);

        if (!bruteResult.equals(slidingResult)) {
            throw new IllegalStateException(
                    "Results are not identical!");
        }

        // Warm-up
        for (int i = 0; i < 3; i++) {
            minLengthSequenceSum(values, target);
        }

        // Brute Force messen
        long start = System.nanoTime();

        Result brute = minLengthSequenceSumBruteForce(
                values, target);

        long bruteTime = System.nanoTime() - start;

        // Sliding Window messen
        start = System.nanoTime();

        Result sliding = minLengthSequenceSum(
                values, target);

        long slidingTime = System.nanoTime() - start;

        checksum += brute.length() + sliding.length();

        double bruteMs = bruteTime / 1_000_000.0;
        double slidingMs = slidingTime / 1_000_000.0;

        double speedup = (double) bruteTime / slidingTime;

        System.out.printf(
                "%-12d %-12d %-18.3f %-18.3f %-12s%n",
                values.length,
                target,
                bruteMs,
                slidingMs,
                String.format("%.2fx", speedup)
        );
    }

    private static int[] generateValues(int n) {

        int[] values = new int[n];
        Random random = new Random(42);

        for (int i = 0; i < n; i++) {
            values[i] = random.nextInt(10) + 1;
        }

        return values;
    }
}
