package part7_sliding_windows;

public class MinLengthSequenceTargetSumSimple {
    public static int minLengthSequenceSumBruteForce(int[] values, int target) {
        if (values == null) {
            throw new IllegalArgumentException("values must not be null");
        }
        if (target <= 0) {
            throw new IllegalArgumentException("target must be positive");
        }

        int minLength = Integer.MAX_VALUE;

        for (int start = 0; start < values.length; start++) {
            int sum = 0;

            for (int end = start; end < values.length; end++) {
                if (values[end] < 0) {
                    throw new IllegalArgumentException("values must be non-negative");
                }

                sum += values[end];

                if (sum >= target) {
                    minLength = Math.min(minLength, end - start + 1);
                    break; // Für diesen Start wird das Teilarray nicht kürzer.
                }
            }
        }

        return minLength == Integer.MAX_VALUE ? 0 : minLength;
    }

    public static int minLengthSequenceSum(int[] values, long target) {
        validateInputs(values, target);

        int left = 0;
        int shortest = Integer.MAX_VALUE;
        long sum = 0;

        for (int right = 0; right < values.length; right++) {
            sum += values[right];
            while (sum >= target) {
                shortest = Math.min(shortest, right - left + 1);
                sum -= values[left++];
            }
        }
        return shortest == Integer.MAX_VALUE ? 0 : shortest;
    }

    private static void validateInputs(int[] values, long target) {
        if (values == null) throw new IllegalArgumentException("values must not be null");
        if (target <= 0) throw new IllegalArgumentException("target must be positive");
        for (int value : values) {
            if (value < 0) throw new IllegalArgumentException("values must be non-negative");
        }
    }

    static void main() {
        var values = new int[] {2, 1, 3, 2, 4, 1, 1, 5};

        IO.println(minLengthSequenceSumBruteForce(values, 7));
        IO.println(minLengthSequenceSum(values, 7));
    }
}
