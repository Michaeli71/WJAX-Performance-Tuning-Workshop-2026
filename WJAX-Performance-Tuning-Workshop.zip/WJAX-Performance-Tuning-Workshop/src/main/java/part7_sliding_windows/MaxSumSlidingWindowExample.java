package part7_sliding_windows;

import java.util.Arrays;
import java.util.Random;

public class MaxSumSlidingWindowExample {
    static void main() {

        int[] numbers = randomNumbers(10);
        IO.println("Zahlen: " + Arrays.toString(numbers));

        IO.println(maxSumNaive(numbers, 3));
        IO.println(maxSumSlidingWindow(numbers, 3));

    }

    static int maxSumNaive(int[] values, int k) {
        int max = Integer.MIN_VALUE;

        for (int i = 0; i <= values.length - k; i++) {
            int sum = 0;

            for (int j = i; j < i + k; j++) {
                sum += values[j];
            }

            max = Math.max(max, sum);
        }

        return max;
    }

    static int maxSumSlidingWindow(int[] values, int k) {
        if (k <= 0 || k > values.length)
            throw new IllegalArgumentException("Invalid window size");

        int sum = 0;
        for (int i = 0; i < k; i++) {
            sum += values[i];
        }

        int max = sum;
        for (int i = k; i < values.length; i++) {
            sum += values[i] - values[i - k];
            max = Math.max(max, sum);
        }

        return max;
    }

    public static int[] randomNumbers(int size) {
        Random random = new Random();
        random.setSeed(23112020);

        int[] array = new int[size];

        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(100); // Werte von 0 bis 99
        }

        return array;
    }

}
