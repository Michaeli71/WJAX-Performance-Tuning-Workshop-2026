package part8_recursion;

import java.util.ArrayList;
import java.util.List;

public class ListFibonacciTrickExample {
    static void main() {
        IO.println("fib(40): " + fibonacci(40));
        IO.println("fib(42): " + fibonacci(42));
        IO.println("fib(45): " + fibonacci(45));

        IO.println("Tabulation-Trick / Dynamic Programming");
        fibonacciTrickTabulation();
    }

    private static void fibonacciTrickTabulation() {
        var fib_numbers = new ArrayList<>(List.of(0, 1));

        for (int i = 0; i < 100; i++) {
            int lastIdx = fib_numbers.size();
            fib_numbers.add(fib_numbers.get(lastIdx - 2) + fib_numbers.get(lastIdx - 1));
        }

        IO.println(fib_numbers);
    }

    static long fibonacci(int n) {
        if (n == 0 || n == 1) {
            return n;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
