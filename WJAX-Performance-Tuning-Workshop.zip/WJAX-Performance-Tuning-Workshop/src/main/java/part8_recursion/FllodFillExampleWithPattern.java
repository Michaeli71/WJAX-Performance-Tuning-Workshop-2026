package part8_recursion;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class FllodFillExampleWithPattern {
    void main() {
        IO.println("Pos 1");
        final char[][] world1 = generateBigWorld();
        final char[][] pattern = generatePattern();

        printArray(world1);
        floodFill(world1, 1, 1, pattern);
        IO.println("------------");
        printArray(world1);

        System.out.println("Pos2");
        final char[][] world2 = generateBigWorld();
        final char[][] pattern2 = generatePattern2();
        floodFill(world2, 9, 5, pattern2);
        IO.println("------------");
        printArray(world2);

    }

    private static void printArray(char[][]  world) {
        for (char[] row : world) {
            for (char c : row)
                IO.print(c);
            IO.println();
        }
    }

    void floodFill(final char[][] values, final int x, final int y,
                   final char[][] pattern) {
        if (x < 0 || y < 0 || y >= values.length || x >= values[y].length)
            return;

        if (values[y][x] == ' ') {
            values[y][x] = findFillChar(x, y, pattern);

            floodFill(values, x, y - 1, pattern);
            floodFill(values, x + 1, y, pattern);
            floodFill(values, x, y + 1, pattern);
            floodFill(values, x - 1, y, pattern);
        }
    }

    private char[][] generateBigWorld() {
        return new char[][] {"           #   |".toCharArray(),
                             "       ##   #   |".toCharArray(),
                             "    #####    #   __".toCharArray(),
                             "       ###   #     |".toCharArray(),
                             " ###    #    #      |".toCharArray(),
                             "    #   #    #     |".toCharArray(),
                             "     # #    #    --".toCharArray(),
                             "      #    #    |".toCharArray(),};
    }

    private char[][] generatePattern() {
        return new char[][] {".||.".toCharArray(),
                             "-/\\-".toCharArray(),
                             "-\\/-".toCharArray(),
                             ".||.".toCharArray(),};
    }


    private char[][] generatePattern2() {
        return new char[][] {".|.".toCharArray(),
                             "-*-".toCharArray(),
                             ".|.".toCharArray(),};
    }

    //

    private char findFillChar(final int x, final int y, final char[][] pattern) {
        final int maxY = pattern.length;
        final int maxX = pattern[0].length;

        final int adjustedX = x % maxX;
        final int adjustedY = y % maxY;

        return pattern[adjustedY][adjustedX];
    }

    private void setAt(final char[][] values, final int x, final int y, final char value) {
        values[y][x] = value;
    }
}
