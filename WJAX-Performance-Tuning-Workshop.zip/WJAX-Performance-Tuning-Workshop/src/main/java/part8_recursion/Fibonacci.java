package part8_recursion;

public class Fibonacci {

    long fibRec(long n) {
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            return fibRec(n - 1) + fibRec(n - 2);
        }
    }

    void main() {
        IO.println("Fibonacci – Rekursive Berechnung");
        IO.println("-".repeat(55));

        IO.println("%-12s %20s %15s"
                           .formatted("n", "Ergebnis", "Zeit (ms)"));

        IO.println("-".repeat(55));

        for (int n : new int[] {20, 42, 47, 52, 57}) {
            measureFibRec(n);
        }
    }

    void measureFibRec(int n) {
        long start = System.nanoTime();

        long result = fibRec(n);

        double elapsed = (System.nanoTime() - start) / 1_000_000.0;

        IO.println("%-12d %,20d %,15.3f".formatted(n, result, elapsed));
    }
}
