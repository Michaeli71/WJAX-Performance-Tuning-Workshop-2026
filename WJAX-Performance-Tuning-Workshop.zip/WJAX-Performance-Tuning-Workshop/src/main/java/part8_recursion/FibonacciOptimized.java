package part8_recursion;

import java.util.HashMap;
import java.util.Map;

public class FibonacciOptimized {

    long fibRec(long n) {
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            return fibRec(n - 1) + fibRec(n - 2);
        }
    }

    static long fibonacciOptimized(int n) {
        if (n <= 0)
            throw new IllegalArgumentException("n must be >= 1");

        return fibonacciMemo(n, new HashMap<>());
    }

    private static long fibonacciMemo(int n, Map<Integer, Long> memo) {
        if (n == 0 || n == 1)
            return n;

        // prüfe in memo
        if (memo.containsKey(n))
            return memo.get(n);

        long result = fibonacciMemo(n - 1, memo) + fibonacciMemo(n - 2, memo);
        memo.put(n, result);

        return result;
    }


    void main() {
        IO.println("Fibonacci – Rekursive Berechnung mit Memoization");
        IO.println("-".repeat(55));

        IO.println("%-12s %20s %15s"
                           .formatted("n", "Ergebnis", "Zeit (ms)"));

        IO.println("-".repeat(55));

        for (int n : new int[] {20, 42, 47, 52, 57}) {
            measureFibMemo(n);
        }
    }

    void measureFibMemo(int n) {
        long start = System.nanoTime();

        long result = fibonacciOptimized(n);

        double elapsed = (System.nanoTime() - start) / 1_000_000.0;

        IO.println("%-12d %,20d %,15.3f".formatted(n, result, elapsed));
    }
}
