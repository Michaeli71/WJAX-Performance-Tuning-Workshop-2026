package part8_recursion;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class FloodFillExample
{
	private FloodFillExample()
	{
	}

	static void main() {
		final char[][] world = generateBigWorld();
		printArray(world);
		// vorderer Teil
		floodFill(world, 1, 1);
		// hinterer Teil
		// floodFill(world, 15, 1);
		IO.println("------------");
		printArray(world);
	}

	static void floodFill(final char[][] values, final int x, final int y) {
		if (x < 0 || y < 0)
			return;

		if (y >= values.length || x >= values[y].length)
			return;

		if (values[y][x] == ' ') {
			values[y][x] = '*';

			// fill in all 4 dirs
			floodFill(values, x, y - 1);
			floodFill(values, x + 1, y);
			floodFill(values, x, y + 1);
			floodFill(values, x - 1, y);
		}
	}

	private static char[][] generateBigWorld() {
		return new char[][] {"           #   |".toCharArray(),
							 "       ##   #   |".toCharArray(),
							 "    #####    #   __".toCharArray(),
							 "       ###   #     |".toCharArray(),
							 " ###    #    #      |".toCharArray(),
							 "    #   #    #     |".toCharArray(),
							 "     # #    #    --".toCharArray(),
							 "      #    #    |".toCharArray(),};
	}

	private static void printArray(char[][]  world) {
		for (char[] row : world) {
			for (char c : row)
				IO.print(c);
			IO.println();
		}
	}
}
