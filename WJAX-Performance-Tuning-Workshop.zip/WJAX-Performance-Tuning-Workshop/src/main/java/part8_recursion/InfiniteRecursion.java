package part8_recursion;


public class InfiniteRecursion {
    void main() {
        f();
    }

    private void f() {
        f();
    }
}
