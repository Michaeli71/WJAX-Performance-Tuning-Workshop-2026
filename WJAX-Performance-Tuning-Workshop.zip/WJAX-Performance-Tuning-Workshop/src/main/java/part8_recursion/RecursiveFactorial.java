package part8_recursion;

public class RecursiveFactorial {
	void main() {
		IO.println(factorial(7));
		IO.println(factorial(14));
		IO.println(factorial(77));

		// IO.println(factorial(-7));
	}

	long factorial(long number) {
		/*
		if (number < 0) {
			IO.println("number must be positive!");
			return -1;
			//throw new IllegalArgumentException("number must be positive!");
		}
		 */

		if (number == 0) {
			return 1;
		} else {
			return number * factorial(number - 1);
		}
	}
}
