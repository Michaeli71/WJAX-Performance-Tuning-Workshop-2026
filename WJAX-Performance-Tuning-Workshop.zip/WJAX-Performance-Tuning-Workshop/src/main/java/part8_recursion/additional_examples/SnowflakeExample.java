package part8_recursion.additional_examples;

import javax.swing.*;
import java.awt.*;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class SnowflakeExample
{
    static void main()
    {
        final JFrame frame = new JFrame("Snowflake");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);

        final JPanel panel = new JPanel()
        {
            @Override
            public void paintComponent(final Graphics g)
            {
                super.paintComponent(g);
                g.setColor(Color.BLUE);
                drawSnowflake(g, 300, 300, 200, 4);
            }
        };
        frame.add(panel);

        frame.setSize(600, 600);
        frame.setVisible(true);
    }

    public static void drawSnowflake(final Graphics graphis, final int startX, final int startY, final int length,
                                     final int depth)
    {
        for (int degree = 0; degree < 360; degree += 60)
        {
            final double rad = degree * Math.PI / 180;
            final int endX = (int) (startX + Math.cos(rad) * length);
            final int endY = (int) (startY + Math.sin(rad) * length);

            graphis.drawLine(startX, startY, endX, endY);

            // rekursiver Abstieg
            if (depth > 0)
            {
                drawSnowflake(graphis, endX, endY, length / 4, depth - 1);
            }
        }
    }
}
