package part8_recursion.additional_examples;

import java.util.Optional;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2020 by Michael Inden
 */
public class Ex09_NQueensProblem {
    private Ex09_NQueensProblem() {
    }

    static void main() {
        solveAndPrint(4);
        solveAndPrint(8);

        final Optional<char[][]> optBoards16 = solveNQueens(16);
        optBoards16.ifPresentOrElse(board_16x16 -> printBoard(board_16x16), () -> System.out.println("No Solution!"));
    }

    private static void solveAndPrint(final int size) {
        final Optional<char[][]> optBoards = solveNQueens(size);

        optBoards.ifPresentOrElse(board -> printBoard(board), () -> System.out.println("No Solution!"));
        optBoards.ifPresentOrElse(board -> printBoardNicely(board), () -> System.out.println("No Solution!"));
    }

    static Optional<char[][]> solveNQueens(final int size) {
        final char[][] board = initializeBoard(size);

        if (solveNQueens(board, 0))
            return Optional.of(board);

        return Optional.empty();
    }

    private static char[][] initializeBoard(final int size) {
        final char[][] board = new char[size][size];

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                board[row][col] = ' ';
            }
        }
        return board;
    }

    static boolean solveNQueens(final char[][] board, final int row) {
        final int maxRow = board.length;
        final int maxCol = board[0].length;

        if (row >= maxRow)
            return true;

        boolean solved = false;
        int col = 0;
        while (!solved && col < maxCol) {
            if (isValidPosition(board, col, row)) {
                placeQueen(board, col, row);

                // rekursiver Abstieg
                solved = solveNQueens(board, row + 1);

                // Backtracking, sofern keine Lösung
                if (!solved)
                    removeQueen(board, col, row);
            }
            col++;
        }

        return solved;
    }

    private static void placeQueen(final char[][] board, final int col, final int row) {
        board[row][col] = 'Q';
    }

    private static void removeQueen(final char[][] board, final int col, final int row) {
        board[row][col] = ' ';
    }

    static boolean isValidPosition(final char[][] board, final int col, final int row) {
        final int maxRow = board.length;
        final int maxCol = board[0].length;

        return checkHorizontally(board, row, maxCol) &&
                // eigentlich NICHT benötigt, da wir ja gerdae die neue Zeile
                // prüfen, für allgemeine Prüfung eines Boards aber sinnvoll
                checkVertically(board, col, maxRow) && checkDiagonallyLO(board, col, row)
                && checkDiagonallyRO(board, col, row, maxCol);
    }

    private static boolean checkHorizontally(final char[][] board, final int row, final int maxX) {
        int x = 0;
        while (x < maxX && board[row][x] == ' ')
            x++;
        return x >= maxX;
    }

    private static boolean checkVertically(final char[][] board, final int col, final int maxY) {
        int y = 0;
        while (y < maxY && board[y][col] == ' ')
            y++;
        return y >= maxY;
    }

    private static boolean checkDiagonallyRO(final char[][] board, final int col, final int row, final int maxX) {
        // Variante mit while
        int x = col;
        int y = row;
        boolean diagRUfree = true;
        while (x < maxX && y >= 0) {
            diagRUfree = diagRUfree && board[y][x] == ' ';
            y--;
            x++;
        }
        return diagRUfree;

    }

    private static boolean checkDiagonallyLO(final char[][] board, final int col, final int row) {
        // prüfen, da wir ja die letzte Zeile sind
        // eine der wenigen Stellen, wo man mal eine doppelte Variablenbelegung in einer
        // for-Schelife gut nutzen kann, ggf. while übersichtlicher
        boolean diagLUfree = true;
        for (int y = row, x = col; y >= 0 && x >= 0; y--, x--) {
            diagLUfree = diagLUfree && board[y][x] == ' ';
        }
        return diagLUfree;
    }

    public static void printBoard(final char[][] values) {
        final String line = "-".repeat(values[0].length * 2 + 1);
        System.out.println(line);
        for (int y = 0; y < values.length; y++) {
            IO.print("|");
            for (int x = 0; x < values[y].length; x++) {
                final Object value = values[y][x];
                IO.print(value + "|");
            }
            IO.println();
            IO.println(line);
        }
    }

    public static void printBoardNicely(final char[][] values) {
        final String RESET = "\u001B[0m";

        final String LIGHT_FIELD = "\u001B[48;5;230m";
        final String DARK_FIELD = "\u001B[48;5;94m";

        final String BLACK_QUEEN = "\u001B[38;5;16m";
        final String WHITE_QUEEN = "\u001B[38;5;255m";

        final String QUEEN = "♛";

        // Spaltenbeschriftung
        IO.print("   ");
        for (int x = 0; x < values[0].length; x++) {
            IO.print(" " + (char) ('a' + x) + "  ");
        }
        IO.println();

        // Obere Begrenzung
        IO.print("  ┌");
        IO.print("───┬".repeat(values[0].length - 1));
        IO.println("───┐");

        for (int y = 0; y < values.length; y++) {
            // Zeilennummer
            IO.print((values.length - y) + " ");

            for (int x = 0; x < values[y].length; x++) {
                final boolean dark = (x + y) % 2 == 1;

                var background = dark ? DARK_FIELD : LIGHT_FIELD;
                var queenColor = dark ? WHITE_QUEEN : BLACK_QUEEN;

                var content = values[y][x] == 'Q' ? queenColor + QUEEN : " ";

                IO.print("│");
                IO.print(background);
                IO.print(" ");
                IO.print(content);
                IO.print(" ");
                IO.print(RESET);
            }

            IO.println("│");

            // Horizontale Trennlinie
            if (y < values.length - 1) {
                IO.print("  ├");
                IO.print("───┼".repeat(values[0].length - 1));
                IO.println("───┤");
            }
        }

        // Untere Begrenzung
        IO.print("  └");
        IO.print("───┴".repeat(values[0].length - 1));
        IO.println("───┘");
    }
}
