package part8_recursion.additional_examples;

/// https://en.wikipedia.org/wiki/ANSI_escape_code?utm_source=chatgpt.com
public class ConsoleColors
{
    // Reset & styles
    public static final String RESET = "\u001B[0m";
    public static final String BOLD = "\u001B[1m";
    public static final String DIM = "\u001B[2m";
    public static final String ITALIC = "\u001B[3m";
    public static final String UNDERLINE = "\u001B[4m";
    public static final String REVERSE = "\u001B[7m";

    // Standard colors
    public static final String BLACK = "\u001B[30m";
    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BLUE = "\u001B[34m";
    public static final String PURPLE = "\u001B[35m";
    public static final String CYAN = "\u001B[36m";
    public static final String WHITE = "\u001B[37m";

    // Bright colors
    public static final String BRIGHT_BLACK = "\u001B[90m";
    public static final String BRIGHT_RED = "\u001B[91m";
    public static final String BRIGHT_GREEN = "\u001B[92m";
    public static final String BRIGHT_YELLOW = "\u001B[93m";
    public static final String BRIGHT_BLUE = "\u001B[94m";
    public static final String BRIGHT_PURPLE = "\u001B[95m";
    public static final String BRIGHT_CYAN = "\u001B[96m";
    public static final String BRIGHT_WHITE = "\u001B[97m";

    // 256-color palette
    public static final String ORANGE = "\u001B[38;5;208m";
    public static final String TURQUOISE = "\u001B[38;5;80m";
    public static final String GOLD = "\u001B[38;5;220m";
    public static final String PINK = "\u001B[38;5;213m";
    public static final String CORAL = "\u001B[38;5;209m";
    public static final String LIME = "\u001B[38;5;118m";
    public static final String MINT = "\u001B[38;5;121m";
    public static final String SKY_BLUE = "\u001B[38;5;117m";
    public static final String ROYAL_BLUE = "\u001B[38;5;63m";
    public static final String VIOLET = "\u001B[38;5;135m";
    public static final String MAGENTA = "\u001B[38;5;201m";
    public static final String SALMON = "\u001B[38;5;210m";

    // Darker 256-color shades
    public static final String DARK_RED = "\u001B[38;5;88m";
    public static final String DARK_GREEN = "\u001B[38;5;22m";
    public static final String DARK_BLUE = "\u001B[38;5;18m";
    public static final String DARK_PURPLE = "\u001B[38;5;54m";
    public static final String DARK_CYAN = "\u001B[38;5;30m";
    public static final String DARK_ORANGE = "\u001B[38;5;130m";
    public static final String DARK_YELLOW = "\u001B[38;5;136m";

    // Grayscale
    public static final String GRAY = "\u001B[38;5;245m";
    public static final String LIGHT_GRAY = "\u001B[38;5;250m";
    public static final String DARK_GRAY = "\u001B[38;5;240m";
    public static final String SILVER = "\u001B[38;5;7m";
}
