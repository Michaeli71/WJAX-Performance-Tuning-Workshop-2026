package part10_real_world_optimization;

/**
 * Simple Aufz�hlung zur Modellierung eines geschlechts
 * 
 * @author Michael Inden
 * 
 * Copyright 2011 by Michael Inden 
 */
public enum Gender {
    MALE, FEMALE
};
