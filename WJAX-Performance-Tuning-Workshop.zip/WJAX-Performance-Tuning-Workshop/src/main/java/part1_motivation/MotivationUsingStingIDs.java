package part1_motivation;

import java.util.*;

public class MotivationUsingStingIDs {

    private static volatile long blackhole;

    public static long performAction(Collection<String> requestedIds, Collection<String> knownIds) {

        long processed = 0;

        for (String id : requestedIds) {
            if (knownIds.contains(id)) {
                process(id);
                processed++;
            }
        }

        return processed;
    }

    private static void process(String id) {
        blackhole += id.hashCode();
    }

    private static double benchmark(Collection<String> requestedIds, Collection<String> knownIds, String name) {

        long start = System.nanoTime();

        long processed = performAction(requestedIds, knownIds);

        long elapsed = System.nanoTime() - start;

        System.out.printf("%s: %d Treffer, %.4f s%n", name, processed, elapsed / 1_000_000_000.0);

        return elapsed / 1_000_000_000.0;
    }

    static void main() {

        int size = 500_000;
        int searchCount = 10_000;

        List<String> knownList = new ArrayList<>(size);

        for (int i = 0; i < size; i++) {
            knownList.add("ID-" + i);
        }

        Set<String> knownSet = new HashSet<>(knownList);

        Random random = new Random(42);

        List<String> requestedIds = new ArrayList<>(searchCount);

        for (int i = 0; i < searchCount; i++) {
            requestedIds.add("ID-" + random.nextInt(size));
        }

        // Aufwärmen der JVM
        performAction(requestedIds, knownList);
        performAction(requestedIds, knownSet);

        IO.println("=== Action Benchmark ===");

        double listTime = benchmark(requestedIds, knownList, "List");
        double setTime = benchmark(requestedIds, knownSet, "Set");

        System.out.printf("%nList: %.4f s%n", listTime);
        System.out.printf("Set:  %.4f s%n", setTime);

        if (setTime > 0) {
            System.out.printf("Speedup: %.1f x%n", listTime / setTime);
        }

        IO.println("Checksum: " + blackhole);
    }
}

