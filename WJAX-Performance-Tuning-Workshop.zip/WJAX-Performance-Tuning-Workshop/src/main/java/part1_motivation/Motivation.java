package part1_motivation;

import java.util.*;

public class Motivation {

    private static final int SIZE = 1_000_000;
    private static final int SEARCH_COUNT = 10_000;

    static int countDesiredNumbers(Collection<Integer> idsToValidate, Collection<Integer> knownIds) {
        int count = 0;
        for (Integer id : idsToValidate) {
            if (knownIds.contains(id)) {
                // process(id);
                count++;
            }
        }
        return count;
    }


    public static double performCountedSearch(Collection<Integer> idsToValidate,
                                              Collection<Integer> knownIds, String dsName) {

        IO.println("Searching in " + dsName);

        long start = System.nanoTime();

        int count = countDesiredNumbers(idsToValidate, knownIds);

        long elapsed = System.nanoTime() - start;

        IO.println("Matches: " + count);

        return elapsed / 1_000_000_000.0;
    }

    static void main() {
        List<Integer> numbersList = new ArrayList<>();
        Set<Integer> numbersSet = new HashSet<>();

        for (int i = 0; i < SIZE; i++) {
            numbersList.add(i);
            numbersSet.add(i);
        }

        Collection<Integer> idsToValidate = createRandomDesiredNumbers();

        // Aufwärmen der JVM
        /*
        IO.println("Warming up ...");
        for (int i = 0; i < 3; i++) {
            countDesiredNumbers(idsToValidate, numbersList);
            countDesiredNumbers(idsToValidate, numbersSet);
        }
        */

        //
        double listTime = performCountedSearch(idsToValidate, numbersList, "List");
        double setTime = performCountedSearch(idsToValidate, numbersSet, "Set");

        System.out.printf("List:   %.4fs%n", listTime);
        System.out.printf("Set:    %.4fs%n", setTime);

        if (setTime > 0) {
            System.out.printf("Factor: %.1fx%n", listTime / setTime);
        }

    }

    private static List<Integer> createRandomDesiredNumbers() {
        Random random = new Random(42);
        List<Integer> desiredNumbers = new ArrayList<>(SEARCH_COUNT);

        for (int i = 0; i < SEARCH_COUNT; i++) {
            desiredNumbers.add(random.nextInt(SIZE));
        }
        return desiredNumbers;
    }
}
