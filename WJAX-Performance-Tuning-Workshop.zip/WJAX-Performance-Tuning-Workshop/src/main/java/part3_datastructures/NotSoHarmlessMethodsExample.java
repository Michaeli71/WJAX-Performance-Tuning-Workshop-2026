package part3_datastructures;

import java.util.*;
import java.util.stream.Stream;

public class NotSoHarmlessMethodsExample {

    /// |    Elemente |    List |     Set |  Faktor |
    /// | ----------: | ------: | ------: | ------: |
    /// |      10.000 |  218 µs |  1.1 µs |    193× |
    /// |   1.000.000 | 3.26 ms | 3.25 µs |  1.003× |
    /// | 100.000.000 |  182 ms |  4.1 µs | 44.559× |
    ///
    /// | Aufruf                 | `contains()` auf | erwartete Komplexität |
    /// | ---------------------- | ---------------- | --------------------: |
    /// | `list.retainAll(list)` | List             |            **O(n·m)** |
    /// | `list.retainAll(set)`  | Set              |              **O(n)** |
    /// | `set.retainAll(list)`  | List             |            **O(n·m)** |
    /// | `set.retainAll(set)`   | Set              |              **O(n)** |
    void main() {

        for (int i : new int[] {10_000, 1_000_000, 100_000_000}) {
            IO.println("Measuring contains() for " + i + " elements");
            containsExample(i);
        }

        /*
        here is the timing for the case when removal is O(1):
            If c.contains(v) finishes in O(1), then retainAll is O(N).
            If contains is O(Log M), then retainAll is O(N*Log M).
            If contains is O(M), then retainAll is O(N*M).
         */
        for (int i : new int[] {1_000, 10_000, 100_000, 1_000_000}) {
            IO.println("Measuring retainAll() for " + i + " elements");
            setOperationsExample(i);
        }
    }

    private void setOperationsExample(int size) {
        // Huge Data Set, 1/2 überlapp
        List<Integer> values1 = new ArrayList<>(createSizedStream(size).toList());
        List<Integer> values2 = new ArrayList<>(createSizedStream(size/2, size + size/2).toList());
        // damit die Werte zufällig kommen
        Collections.shuffle(values2);

        long durationList = measureRetainAll(values1, values2, "retainAll() list");

        Set<Integer> values1AsSet = new HashSet<>(values1);
        Set<Integer> values2AsSet = new HashSet<>(values2);

        long durationSet = measureRetainAll(values1AsSet, values2AsSet, "retainAll() set");

        IO.println("factor: " + Math.round(durationList / durationSet));
    }

    //
    long measureRetainAll(Collection<Integer> values1, Collection<Integer> values2, String info) {
        long startInNanos = System.nanoTime();

        boolean found = values1.retainAll(values2);

        long durationInNanos = System.nanoTime() - startInNanos;

        IO.println(info + " took " + durationInNanos + " nanos");

        return durationInNanos;
    }

    private void containsExample(int size) {
        // Huge Data Set
        List<Integer> values = createSizedStream(size).toList();
        long durationList = measureContains(values, -42, "contains() list");

        Set<Integer> valuesAsSet = new HashSet<>(values);
        long durationSet = measureContains(valuesAsSet, -42, "contains() set");

        IO.println("factor: " + Math.round(durationList / durationSet));
    }

    private static Stream<Integer> createSizedStream(int start, int limit) {
        return Stream.iterate(start, i -> i < start + limit, i -> i + 1);
    }

    private static Stream<Integer> createSizedStream(int limit) {
        return createSizedStream(1, limit);
    }

    //
    long measureContains(Collection<Integer> values, Integer searchFor, String info) {
        long startInNanos = System.nanoTime();

        boolean found = values.contains(searchFor);

        long durationInNanos = System.nanoTime() - startInNanos;

        IO.println(info + " took " + durationInNanos + " nanos");

        return durationInNanos;
    }
}
