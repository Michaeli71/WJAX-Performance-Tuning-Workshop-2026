package part3_datastructures.maps;

import java.util.Map;

public class RomanNumbersExample {

    static Map<Character, Integer> valueMap = Map.of('I', 1, 'V', 5, 'X', 10, 'L', 50, 'C', 100, 'D', 500, 'M', 1000);


    public static int fromRomanNumber(final String romanNumber) {
        int value = 0;
        int lastDigitValue = 0;

        for (int i = romanNumber.length() - 1; i >= 0; i--) {
            final char romanDigit = romanNumber.charAt(i);
            final int digitValue = valueMap.getOrDefault(romanDigit, 0);

            final boolean addMode = digitValue >= lastDigitValue;
            if (addMode) {
                value += digitValue;
                lastDigitValue = digitValue;
            } else {
                value -= digitValue;
            }
        }
        return value;
    }

    static void main()
    {
        IO.println("XI: " + fromRomanNumber("XI"));
        IO.println("IX: " + fromRomanNumber("IX"));
        IO.println("MMDC: " + fromRomanNumber("MMDC"));

        IO.println("XIV: " +fromRomanNumber("XIV"));
        IO.println("LV: " +fromRomanNumber("LV"));

        // nicht ganz robust
        IO.println("XIVII: " +fromRomanNumber("XIVII"));
        IO.println("XIVIIII: " +fromRomanNumber("XIVIIII"));
        IO.println("XIVIIIIIIIIIIIII: " +fromRomanNumber("XIVIIIIIIIIIIIII")); // 27 :-)
    }
}
