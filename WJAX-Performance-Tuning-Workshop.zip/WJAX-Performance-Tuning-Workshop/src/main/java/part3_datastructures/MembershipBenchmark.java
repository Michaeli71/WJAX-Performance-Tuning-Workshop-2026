
package part3_datastructures;

import java.util.*;
import java.util.function.Supplier;

public class MembershipBenchmark {

    private static final int[] SIZES = {
            1_000, 10_000, 100_000, 1_000_000, 10_000_000
    };

    private static final int WARMUP_RUNS = 1;
    private static final int MEASUREMENT_RUNS = 3;
    private static final int CANDIDATE_COUNT = 1_000;

    public static void checkMembership(
            Collection<String> values,
            Collection<String> candidates) {

        for (String candidate : candidates) {
            if (values.contains(candidate)) {
                performAction(candidate);
            }
        }
    }

    public static void performAction(String candidate) {
        System.out.println("Action performed for: " + candidate);
    }

    private static long countMatches(
            Collection<String> values,
            Collection<String> candidates) {

        long matches = 0;

        for (String candidate : candidates) {
            if (values.contains(candidate)) {
                matches++;
            }
        }

        return matches;
    }

    private static double runBenchmark(
            Collection<String> values,
            Collection<String> candidates) {

        long start = System.nanoTime();

        long matches = countMatches(values, candidates);

        long end = System.nanoTime();

        // Korrektheitsprüfung ausserhalb der Messzeit
        if (matches != CANDIDATE_COUNT / 2) {
            throw new IllegalStateException("Falsche Anzahl Treffer!");
        }

        return (end - start) / 1_000_000.0;
    }

    private static double benchmarkCollection(
            Supplier<Collection<String>> factory,
            List<String> candidates,
            int size) {

        // Datenstruktur erzeugen und befüllen
        Collection<String> values = factory.get();

        for (int i = 0; i < size; i++) {
            values.add("value-" + i);
        }

        // Warm-up
        for (int i = 0; i < WARMUP_RUNS; i++) {
            runBenchmark(values, candidates);
        }

        // Messungen
        double[] times = new double[MEASUREMENT_RUNS];

        for (int i = 0; i < MEASUREMENT_RUNS; i++) {
            times[i] = runBenchmark(values, candidates);
        }

        // Median berechnen
        Arrays.sort(times);

        return times[MEASUREMENT_RUNS / 2];
    }

    public static void main(String[] args) {

        List<Supplier<Collection<String>>> implementations = List.of(
                ArrayList::new,
                HashSet::new,
                TreeSet::new
        );

        System.out.printf(
                "%12s | %14s | %14s | %14s | %11s | %11s%n",
                "Elemente",
                "ArrayList (ms)",
                "HashSet (ms)",
                "TreeSet (ms)",
                "HS Speedup",
                "TS Speedup"
        );

        System.out.println("-".repeat(99));

        for (int size : SIZES) {

            List<String> candidates = new ArrayList<>();

            // Hälfte der Kandidaten sind Treffer,
            // die andere Hälfte sind keine Treffer.
            // Treffer werden über die gesamte Sammlung verteilt.
            for (int i = 0; i < CANDIDATE_COUNT / 2; i++) {
                int index = (int) ((long) i * size / (CANDIDATE_COUNT / 2));

                candidates.add("value-" + index);
                candidates.add("missing-" + i);
            }

            double[] times = new double[implementations.size()];

            // Datenstrukturen nacheinander benchmarken
            for (int i = 0; i < implementations.size(); i++) {
                times[i] = benchmarkCollection(
                        implementations.get(i),
                        candidates,
                        size
                );
            }

            double hashSetSpeedup = times[0] / times[1];
            double treeSetSpeedup = times[0] / times[2];

            System.out.printf(
                    Locale.GERMANY,
                    "%12s | %14.3f | %14.3f | %14.3f | %10.2fx | %10.2fx%n",
                    String.format(Locale.GERMANY, "%,d", size),
                    times[0],
                    times[1],
                    times[2],
                    hashSetSpeedup,
                    treeSetSpeedup
            );
        }
    }
}
