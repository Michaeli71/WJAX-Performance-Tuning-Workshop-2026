package part3_datastructures.queue;

import java.util.ArrayDeque;
import java.util.Deque;

public class DequeExample {
    static void main() {
        Deque<String> deque = new ArrayDeque<>();
        deque.addLast("LAST");
        deque.addFirst("FIRST");
        deque.add("AT THE END");

        IO.println(deque);
        IO.println("Take from front: " + deque.removeFirst());
        IO.println("Take from back: " + deque.removeLast());
    }
}
