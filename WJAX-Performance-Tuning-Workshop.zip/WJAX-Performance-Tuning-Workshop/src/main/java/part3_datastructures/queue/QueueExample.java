package part3_datastructures.queue;

import java.util.ArrayDeque;
import java.util.Deque;

public class QueueExample {
    void main() {
        Deque<String> printJobs = new ArrayDeque<String>();

        // Elemente hinzufügen (Enqueue)
        printJobs.offer("Picture A");
        printJobs.offer("Document B");
        printJobs.offer("Document C");

        // Erstes Element ansehen, ohne es zu entfernen
        System.out.println("Next: " + printJobs.peek()); // Ausgabe: Picture A

        // Elemente abarbeiten und entfernen (Dequeue)
        while (!printJobs.isEmpty()) {
            String printJob = printJobs.poll();
            IO.println("Processing: " + printJob);

            if (printJob.equals("Document B")) {
                // Am Ende "neu anstellen" und verarbeiten
                printJobs.offer("Document B V2");
            }
        }
    }
}
