package part3_datastructures.queue;

import java.util.Deque;
import java.util.LinkedList;

public class FirstQueueExample {
    static void main() {
        Deque<String> deque = new LinkedList<>();

        deque.addLast("1");
        deque.addLast("2");
        deque.addLast("3");

        IO.println("Deque after insert");
        IO.println(deque);

        IO.println(deque.removeFirst());
        IO.println(deque.removeLast());

        IO.println(deque);
    }
}
