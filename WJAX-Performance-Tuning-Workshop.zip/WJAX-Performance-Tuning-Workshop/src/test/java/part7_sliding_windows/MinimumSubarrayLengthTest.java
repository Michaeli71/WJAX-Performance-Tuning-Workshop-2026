package part7_sliding_windows;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class MinLengthSequenceTargetSumTest {

    @Test
    void findsShortestWindowBF() {
        assertEquals(3, MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(new int[] {2, 1, 3, 2, 4, 1, 1, 5}, 7));
    }

    @Test
    void returnsZeroWhenNoWindowQualifiesBF() {
        assertEquals(0, MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(new int[] {1, 2, 1}, 10));
    }

    @Test
    void handlesSingleElementAndWholeArrayBF() {
        assertEquals(1, MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(new int[] {8, 1, 1}, 7));
        assertEquals(3, MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(new int[] {1, 2, 3}, 6));
    }

    @Test
    void supportsZerosBF() {
        assertEquals(1, MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(new int[] {0, 0, 5, 0}, 5));
    }

    @Test
    void rejectsNegativeValuesBecauseSlidingWindowWouldNotBeValidBF() {
        assertThrows(IllegalArgumentException.class, () -> MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(new int[] {2, -1, 4}, 4));
    }

    @Test
    void validatesArgumentsBF() {
        assertThrows(IllegalArgumentException.class, () -> MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(null, 4));
        assertThrows(IllegalArgumentException.class, () -> MinLengthSequenceTargetSumSimple.minLengthSequenceSumBruteForce(new int[] {1}, 0));
    }

    @Test
    void findsShortestWindow() {
        assertEquals(3, MinLengthSequenceTargetSumSimple.minLengthSequenceSum(new int[] {2, 1, 3, 2, 4, 1, 1, 5}, 7));
    }

    @Test
    void returnsZeroWhenNoWindowQualifies() {
        assertEquals(0, MinLengthSequenceTargetSumSimple.minLengthSequenceSum(new int[] {1, 2, 1}, 10));
    }

    @Test
    void handlesSingleElementAndWholeArray() {
        assertEquals(1, MinLengthSequenceTargetSumSimple.minLengthSequenceSum(new int[] {8, 1, 1}, 7));
        assertEquals(3, MinLengthSequenceTargetSumSimple.minLengthSequenceSum(new int[] {1, 2, 3}, 6));
    }

    @Test
    void supportsZeros() {
        assertEquals(1, MinLengthSequenceTargetSumSimple.minLengthSequenceSum(new int[] {0, 0, 5, 0}, 5));
    }

    @Test
    void rejectsNegativeValuesBecauseSlidingWindowWouldNotBeValid() {
        assertThrows(IllegalArgumentException.class, () -> MinLengthSequenceTargetSumSimple.minLengthSequenceSum(new int[] {2, -1, 4}, 4));
    }

    @Test
    void validatesArguments() {
        assertThrows(IllegalArgumentException.class, () -> MinLengthSequenceTargetSumSimple.minLengthSequenceSum(null, 4));
        assertThrows(IllegalArgumentException.class, () -> MinLengthSequenceTargetSumSimple.minLengthSequenceSum(new int[] {1}, 0));
    }
}
