package solutions.part6_prefix_sums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ForestPrefixSumsTest {

    @Test
    void prefixSum2d() {
        int[][] forest = {
                {1, 0, 1, 1},
                {1, 1, 0, 2},
                {2, 1, 4, 3}
        };

        int[][] expected = {
                {0, 0, 0, 0, 0},
                {0, 1, 1, 2, 3},
                {0, 2, 3, 4, 7},
                {0, 4, 6, 11, 17}
        };

        int[][] prefixSum2d = Exercise3_ForestPrefixSums2d.calculatePrefixSums2dOptimzed(forest);
        // IO.println(Arrays.deepToString(prefixSum2d));
        assertArrayEquals(expected, prefixSum2d);
    }

    @Test
    void rectangleQueries() {
        int[][] forest = {
                {1, 0, 1, 1},
                {1, 1, 0, 0},
                {0, 1, 1, 0}
        };

        int[][] prefixSum2d = Exercise3_ForestPrefixSums2d.calculatePrefixSums2dOptimzed(forest);

        assertEquals(3, Exercise3_ForestPrefixSums2d.sumRegion(prefixSum2d, 0, 0, 1, 1));
        assertEquals(4, Exercise3_ForestPrefixSums2d.sumRegion(prefixSum2d, 0, 1, 2, 2));
        assertEquals(1, Exercise3_ForestPrefixSums2d.sumRegion(prefixSum2d, 2, 2, 2, 2));
        assertEquals(7, Exercise3_ForestPrefixSums2d.sumRegion(prefixSum2d, 0, 0, 2, 3));
    }
}