package solutions.part7_sliding_windows;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Exercise5_LongestSubstringTest {
    @Test void handlesClassicExamples() {
        assertEquals("abc", Exercise5_LongestUniqueSubstring.longestUniqueSubstring("abcabcbb"));
        assertEquals("b", Exercise5_LongestUniqueSubstring.longestUniqueSubstring("bbbbb"));
        assertEquals("wke", Exercise5_LongestUniqueSubstring.longestUniqueSubstring("pwwkew"));
    }
    @Test void handlesEmptyAndAllUniqueStrings() {
        assertEquals("", Exercise5_LongestUniqueSubstring.longestUniqueSubstring(""));
        assertEquals("abcde", Exercise5_LongestUniqueSubstring.longestUniqueSubstring("abcde"));
    }
    @Test void repeatedCharacterBeforeCurrentWindowDoesNotMoveLeftBackwards() {
        assertEquals("ab", Exercise5_LongestUniqueSubstring.longestUniqueSubstring("abba"));
    }
}
