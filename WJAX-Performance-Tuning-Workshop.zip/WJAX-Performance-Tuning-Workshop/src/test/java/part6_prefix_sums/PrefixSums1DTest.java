package part6_prefix_sums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

class PrefixSums1DTest {
    @Test
    void prefixSum() {
        int[] values = {3, -2, 5, 1, 4};
        int[] expected = {0, 3, 1, 6, 7, 11};

        int[] result = PrefixSums1d.prefixSums(values);

        assertArrayEquals(expected, result);
    }

    @Test
    void prefixRangeQueries() {
        int[] values = {3, -2, 5, 1, 4};
        int[] expected = {0, 3, 1, 6, 7, 11};

        int[] result = PrefixSums1d.prefixSums(values);

        assertEquals(10, PrefixSums1d.rangeSum(result, 2, 5));
        assertEquals(0, PrefixSums1d.rangeSum(result, 2, 2));
    }

    @Test
    void emptyInput() {
        assertArrayEquals(new int[] {0}, PrefixSums1d.prefixSums(new int[0]));
    }
}