package part6_prefix_sums;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PrefixMultExampleTest {

    @Test
    void prefixMult() {
        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        List<Integer> expected = List.of(1, 3, 6, 10, 15, 21, 28, 36, 45, 55);

        List<Integer> result = PrefixMultExample.prefixMult(values);

        assertEquals(expected, result);
    }
}