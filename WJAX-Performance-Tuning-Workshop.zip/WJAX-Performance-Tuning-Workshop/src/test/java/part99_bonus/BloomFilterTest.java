package part99_bonus;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/// | Test | Lernziel |
/// |---|---|
/// | `addMakesWordPossiblyPresent` | Eingefügte Wörter werden als möglicherweise enthalten erkannt. |
/// | `freshFilterDefinitelyRejectsCommonWord` | Ein nicht gesetztes Bit führt zur sicheren Ablehnung. |
/// | `exposesHashPositionsAndVisualization` | Hashpositionen und Bit-Visualisierung sind nachvollziehbar. |
/// | `rejectsInvalidSize` | Ungültige Filtergrößen werden abgelehnt. |
class BloomFilterTest {
    @Test
    void addMakesWordPossiblyPresent() {
        BloomFilter filter = new BloomFilter(128);
        filter.add("apfel");

        assertTrue(filter.contains("apfel"));
    }

    @Test
    void freshFilterDefinitelyRejectsCommonWord() {
        BloomFilter filter = new BloomFilter(128);

        assertFalse(filter.contains("apfel"));
    }

    @Test
    void exposesHashPositionsAndVisualization() {
        BloomFilter filter = new BloomFilter(32);
        assertEquals(3, filter.hashes("kiwi").size());
        assertEquals(32, filter.visualize().length());
        assertEquals(32, filter.visualize2().length());
    }

    @Test
    void rejectsInvalidSize() {
        assertThrows(IllegalArgumentException.class, () -> new BloomFilter(2));
    }
}
